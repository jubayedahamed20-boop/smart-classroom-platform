import React, { useState } from "react";
import { Fingerprint, LogOut, Calendar, ClipboardList, Bell, UserCog, ShieldCheck, Megaphone, UserCircle, Users } from "lucide-react";
import "./styles.css";
import { COLORS } from "./constants/colors";
import { ACCOUNTS, seedLog, ANNOUNCEMENTS } from "./constants/mockData";
import LoginScreen from "./components/LoginScreen";
import SessionPicker from "./components/SessionPicker";
import CaptureAttendance from "./components/CaptureAttendance";
import TeacherRoster from "./components/TeacherRoster";
import ReportsView from "./components/ReportsView";
import WeeklyReportView from "./components/WeeklyReportView";
import NotificationsView from "./components/NotificationsView";
import AccountsView from "./components/AccountsView";
import AuditLogView from "./components/AuditLogView";
import StudentView from "./components/StudentView";
import StudentSchedule from "./components/StudentSchedule";
import AnnouncementsView from "./components/AnnouncementsView";
import TeacherNoticeboard from "./components/TeacherNoticeboard";
import StudentProfile from "./components/StudentProfile";

const NAV = {
  student: [
    { key: "me", label: "Overview", icon: ClipboardList },
    { key: "schedule", label: "Schedule", icon: Calendar },
    { key: "announcements", label: "Announcements", icon: Megaphone },
    { key: "profile", label: "Profile", icon: UserCircle },
  ],
  teacher: [
    { key: "roster", label: "Class roster", icon: Users },
    { key: "schedule", label: "Class schedule", icon: Calendar },
    { key: "noticeboard", label: "Noticeboard", icon: Megaphone },
    { key: "reports", label: "Reports", icon: ClipboardList },
    { key: "notifications", label: "Notifications", icon: Bell },
  ],
  admin: [
    { key: "accounts", label: "Accounts & config", icon: UserCog },
    { key: "audit", label: "Audit log", icon: ShieldCheck },
    { key: "reports", label: "Reports", icon: ClipboardList },
    { key: "notifications", label: "Notifications", icon: Bell },
  ],
};

function SSASApp() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState(null);
  const [accounts, setAccounts] = useState(ACCOUNTS);
  const [records, setRecords] = useState(() => seedLog().map((r, i) => ({ ...r, sessionKey: `seed-${i}` })));
  const [session, setSession] = useState(null);
  const [threshold, setThreshold] = useState(75);
  const [auditLog, setAuditLog] = useState([]);
  const [announcements, setAnnouncements] = useState(ANNOUNCEMENTS);

  const handleLogin = (acc) => {
    setUser(acc);
    setView(acc.role === "student" ? "me" : acc.role === "teacher" ? "roster" : "accounts");
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: acc.name, action: "login", detail: `${acc.role} authenticated` }, ...l]);
  };

  const openSession = (s) => {
    const key = `${s.courseId}-${Date.now()}`;
    setSession({ ...s, key, checkInOpen: false });
    setView("capture");
  };

  const toggleCheckIn = () => {
    setSession((s) => (s ? { ...s, checkInOpen: !s.checkInOpen } : s));
  };

  const onScanResult = (sessionKey, studentId, outcome, score) => {
    setRecords((prev) => [
      ...prev.filter((r) => !(r.sessionKey === sessionKey && r.studentId === studentId)),
      { id: `SES-${Date.now()}`, studentId, courseId: session.courseId, date: "2026-07-07", method: "face", status: outcome === "present" ? "present" : "denied", sessionKey },
    ]);
    const actorName = accounts.find((a) => a.id === studentId)?.name || user?.name || "Self check-in";
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: actorName, action: "scan", detail: `${studentId} · score ${score}% · ${outcome}` }, ...l]);
  };

  const onOverride = (sessionKey, studentId, status, reason) => {
    setRecords((prev) => [
      ...prev.filter((r) => !(r.sessionKey === sessionKey && r.studentId === studentId)),
      { id: `SES-${Date.now()}`, studentId, courseId: session.courseId, date: "2026-07-07", method: "manual", status, sessionKey },
    ]);
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: user.name, action: "override", detail: `${studentId} → ${status}${reason ? " · " + reason : ""}` }, ...l]);
  };

  const addAnnouncement = (post) => {
    const id = `AN-${Date.now()}`;
    const entry = { id, author: user.name, date: new Date().toISOString().slice(0, 10), ...post };
    setAnnouncements((a) => [entry, ...a]);
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: user.name, action: "noticeboard", detail: `posted "${post.title}"${post.courseId ? " · " + post.courseId : " · general"}` }, ...l]);
  };

  const updateAnnouncement = (id, patch) => {
    setAnnouncements((a) => a.map((post) => (post.id === id ? { ...post, ...patch } : post)));
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: user.name, action: "noticeboard", detail: `edited "${patch.title}"` }, ...l]);
  };

  const deleteAnnouncement = (id) => {
    const target = announcements.find((a) => a.id === id);
    setAnnouncements((a) => a.filter((post) => post.id !== id));
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: user.name, action: "noticeboard", detail: `deleted "${target?.title || id}"` }, ...l]);
  };

  const addAccount = (name, role) => {
    const id = `${role[0].toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    setAccounts((a) => [...a, { id, name, role, dept: "CSE", status: "active" }]);
    setAuditLog((l) => [{ time: new Date().toLocaleTimeString(), actor: user.name, action: "config", detail: `created ${role} account ${id}` }, ...l]);
  };

  if (!user) return <LoginScreen onLogin={handleLogin} activeSession={session} onFaceCheckIn={onScanResult} />;

  const roster = session ? accounts.filter((a) => session.students.includes(a.id)) : [];

  return (
    <div className="ssas" style={{ minHeight: "100vh", background: COLORS.paper, display: "flex" }}>
      {/* Sidebar */}
      <div style={{ width: 232, background: COLORS.ink, padding: "22px 16px", display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9, marginBottom: 30, paddingLeft: 4 }}>
          <div style={{ width: 30, height: 30, borderRadius: 7, background: COLORS.gold, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Fingerprint size={16} color={COLORS.ink} />
          </div>
          <span className="ssas-display" style={{ color: "#fff", fontWeight: 800, fontSize: 17 }}>SSAS</span>
        </div>

        <div style={{ background: "#182A47", borderRadius: 10, padding: 12, marginBottom: 20 }}>
          <div style={{ fontSize: 13.5, fontWeight: 700, color: "#fff" }}>{user.name}</div>
          <div className="ssas-mono" style={{ fontSize: 11, color: "#8E9DB5", marginTop: 2 }}>{user.id} · {user.role}</div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 3, flex: 1 }}>
          {NAV[user.role].map((n) => {
            const Icon = n.icon;
            const active = view === n.key;
            return (
              <button
                type="button"
                key={n.key}
                onClick={() => setView(n.key)}
                className="focus-ring"
                style={{
                  display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 8,
                  background: active ? "#182A47" : "transparent", border: "none", cursor: "pointer",
                  color: active ? COLORS.gold : "#C7CEDA", fontSize: 13.5, fontWeight: 600, textAlign: "left",
                }}
              >
                <Icon size={16} /> {n.label}
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => setUser(null)}
          className="focus-ring"
          style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 8, background: "transparent", border: "none", cursor: "pointer", color: "#8E9DB5", fontSize: 13, fontWeight: 600 }}
        >
          <LogOut size={15} /> Sign out
        </button>
      </div>

      {/* Main */}
      <div style={{ flex: 1, padding: "28px 32px", overflowY: "auto" }}>
        {user.role === "student" && view === "me" && (
          <StudentView student={user} records={records} session={session} onScanResult={onScanResult} threshold={threshold} />
        )}
        {user.role === "student" && view === "schedule" && <StudentSchedule student={user} />}
        {user.role === "student" && view === "announcements" && <AnnouncementsView student={user} announcements={announcements} />}
        {user.role === "student" && view === "profile" && <StudentProfile student={user} records={records} threshold={threshold} />}

        {user.role === "teacher" && view === "roster" && (
          <TeacherRoster teacher={user} accounts={accounts} records={records} onOpenSession={openSession} />
        )}
        {user.role === "teacher" && view === "schedule" && <SessionPicker onPick={openSession} />}
        {user.role === "teacher" && view === "noticeboard" && (
          <TeacherNoticeboard
            teacher={user}
            announcements={announcements}
            onAddAnnouncement={addAnnouncement}
            onUpdateAnnouncement={updateAnnouncement}
            onDeleteAnnouncement={deleteAnnouncement}
          />
        )}
        {user.role === "teacher" && view === "capture" && session && (
          <CaptureAttendance
            session={session}
            roster={roster}
            records={records}
            onScanResult={onScanResult}
            onOverride={onOverride}
            onEndSession={() => { setSession(null); setView("schedule"); }}
            onToggleCheckIn={toggleCheckIn}
          />
        )}
        {user.role === "teacher" && view === "reports" && <WeeklyReportView teacher={user} records={records} threshold={threshold} />}
        {user.role === "admin" && view === "reports" && <ReportsView records={records} />}
        {(view === "notifications") && <NotificationsView records={records} threshold={threshold} />}

        {user.role === "admin" && view === "accounts" && (
          <AccountsView accounts={accounts} onAddAccount={addAccount} threshold={threshold} setThreshold={setThreshold} />
        )}
        {user.role === "admin" && view === "audit" && <AuditLogView log={auditLog} />}
      </div>
    </div>
  );
}

export default SSASApp;
