import React, { useMemo } from "react";
import { Clock, MapPin, User } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE, ACCOUNTS } from "../constants/mockData";
import { Card, SectionHeader, Badge } from "./ui";

const DAY_ORDER = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];

function StudentSchedule({ student }) {
  const mine = useMemo(
    () => SCHEDULE.filter((s) => s.students.includes(student.id)),
    [student.id]
  );

  const byDay = useMemo(() => {
    const map = {};
    mine.forEach((s) => {
      const day = s.time.split(" ")[0];
      if (!map[day]) map[day] = [];
      map[day].push(s);
    });
    return DAY_ORDER.filter((d) => map[d]).map((d) => ({ day: d, classes: map[d].sort((a, b) => a.time.localeCompare(b.time)) }));
  }, [mine]);

  return (
    <div>
      <SectionHeader eyebrow="Process 4.0 · Class schedule" title="Your weekly timetable" />
      {byDay.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>You aren't enrolled in any scheduled courses yet.</Card>
      ) : (
        <div style={{ display: "grid", gap: 18 }}>
          {byDay.map(({ day, classes }) => (
            <div key={day}>
              <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel, letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>
                {{ Mon: "Monday", Tue: "Tuesday", Wed: "Wednesday", Thu: "Thursday", Fri: "Friday", Sat: "Saturday", Sun: "Sunday" }[day]}
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px,1fr))", gap: 12 }}>
                {classes.map((c) => {
                  const teacher = ACCOUNTS.find((a) => a.id === c.teacher);
                  return (
                    <Card key={c.courseId} style={{ padding: 16 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                        <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{c.courseId}</div>
                        <Badge tone="steel">{c.time.split(" ")[1]}</Badge>
                      </div>
                      <div style={{ fontWeight: 700, fontSize: 14.5, color: COLORS.ink, marginBottom: 10 }}>{c.title}</div>
                      <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: COLORS.steel }}>
                          <MapPin size={13} /> {c.room}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: COLORS.steel }}>
                          <User size={13} /> {teacher?.name || c.teacher}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: COLORS.steel }}>
                          <Clock size={13} /> {c.time}
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default StudentSchedule;
