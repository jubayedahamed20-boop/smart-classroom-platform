import React, { useState } from "react";
import { Fingerprint, ScanFace, GraduationCap, Radio, UserCog, XCircle } from "lucide-react";
import { COLORS } from "../constants/colors";
import { ACCOUNTS } from "../constants/mockData";
import { Card, Btn } from "./ui";
import ScanBadge from "./ScanBadge";

function LoginScreen({ onLogin, activeSession, onFaceCheckIn }) {
  const [selected, setSelected] = useState(null);
  const [idInput, setIdInput] = useState("");
  const [error, setError] = useState("");
  const [checkInStudent, setCheckInStudent] = useState(null);

  const roleMeta = {
    student: { icon: GraduationCap, label: "Student", hint: "View attendance, alerts" },
    teacher: { icon: Radio, label: "Teacher", hint: "Capture sessions, override" },
    admin: { icon: UserCog, label: "Admin", hint: "Accounts, audit, config" },
  };

  // Normalize so "s-20244103257", "S 20244103257", "s20244103257" etc. all match.
  const normalize = (v) => v.trim().toLowerCase().replace(/[\s-]/g, "");
  // Digits-only match: since role is already selected via the tiles above,
  // the leading letter (S-/T-/A-) isn't needed — just the number is enough.
  const digitsOnly = (v) => v.replace(/\D/g, "");

  // Students walking up to an active, enrolled session get scanned right at login
  // (merges Process 1.0 Authenticate with Process 2.0 Capture Attendance).
  // Everyone else signs straight in.
  const attemptLogin = (acc) => {
    const eligible = acc.role === "student" && activeSession && activeSession.checkInOpen && activeSession.students.includes(acc.id);
    if (eligible) {
      setCheckInStudent(acc);
    } else {
      onLogin(acc);
    }
  };

  const handleSubmit = () => {
    if (!idInput.trim()) {
      setError("Enter an ID, or tap a name below to sign in instantly.");
      return;
    }
    const typedDigits = digitsOnly(idInput);
    const acc = ACCOUNTS.find(
      (a) => a.role === selected && (normalize(a.id) === normalize(idInput) || (typedDigits && digitsOnly(a.id) === typedDigits))
    );
    if (!acc) {
      setError("No matching account for this role. Try one of the sample IDs below, or tap a name.");
      return;
    }
    setError("");
    attemptLogin(acc);
  };

  const sampleIds = {
    student: "20244103257",
    teacher: "1042",
    admin: "0001",
  };

  const matchingAccounts = selected ? ACCOUNTS.filter((a) => a.role === selected) : [];

  return (
    <div className="ssas" style={{ minHeight: "100vh", background: COLORS.ink, display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
      <div style={{ width: "100%", maxWidth: 460 }}>
        <div style={{ textAlign: "center", marginBottom: 30 }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 9, marginBottom: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 8, background: COLORS.gold, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Fingerprint size={19} color={COLORS.ink} />
            </div>
            <span className="ssas-display" style={{ color: "#fff", fontSize: 20, fontWeight: 800, letterSpacing: 0.2 }}>SSAS</span>
          </div>
          <p className="ssas-mono" style={{ color: "#8E9DB5", fontSize: 12.5, letterSpacing: 0.5, margin: 0 }}>
            PROCESS 1.0 · AUTHENTICATE & REGISTER USER
          </p>
        </div>

        <Card style={{ padding: 24, background: "#182A47", border: "1px solid #26395C" }}>
          {checkInStudent ? (
            <>
              <p className="ssas-mono" style={{ color: "#8E9DB5", fontSize: 11.5, marginBottom: 4, letterSpacing: 0.4 }}>
                CHECKING IN · {activeSession.courseId} · {activeSession.room}
              </p>
              <p style={{ color: "#fff", fontSize: 15, fontWeight: 700, margin: "0 0 16px" }}>
                {checkInStudent.name}
              </p>
              <div style={{ background: "#fff", borderRadius: 10, padding: 2 }}>
                <ScanBadge
                  student={checkInStudent}
                  onResult={(id, outcome, score) => {
                    onFaceCheckIn(activeSession.key, id, outcome, score);
                  }}
                />
              </div>
              <div style={{ display: "flex", gap: 8, marginTop: 14 }}>
                <Btn variant="ghost" style={{ flex: 1, justifyContent: "center", background: "transparent", color: "#C7CEDA", border: "1px solid #26395C" }} onClick={() => { setCheckInStudent(null); setSelected(null); setIdInput(""); }}>
                  Cancel
                </Btn>
                <Btn variant="gold" style={{ flex: 1, justifyContent: "center" }} onClick={() => onLogin(checkInStudent)}>
                  Continue to dashboard
                </Btn>
              </div>
            </>
          ) : (
          <>
          <p className="ssas-mono" style={{ color: "#8E9DB5", fontSize: 11.5, marginBottom: 12, letterSpacing: 0.4 }}>SELECT ROLE</p>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 8, marginBottom: 18 }}>
            {Object.entries(roleMeta).map(([key, m]) => {
              const Icon = m.icon;
              const active = selected === key;
              return (
                <button
                  type="button"
                  key={key}
                  onClick={() => { setSelected(key); setError(""); }}
                  className="focus-ring"
                  style={{
                    background: active ? COLORS.gold : "#101D35",
                    border: `1px solid ${active ? COLORS.gold : "#26395C"}`,
                    borderRadius: 10, padding: "14px 8px", cursor: "pointer",
                    display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                    transition: "all 0.15s ease",
                  }}
                >
                  <Icon size={20} color={active ? COLORS.ink : "#C7CEDA"} />
                  <span style={{ fontSize: 12, fontWeight: 700, color: active ? COLORS.ink : "#C7CEDA" }}>{m.label}</span>
                </button>
              );
            })}
          </div>

          {selected && (
            <>
              <p className="ssas-mono" style={{ color: "#8E9DB5", fontSize: 11.5, marginBottom: 8, letterSpacing: 0.4 }}>
                ENTER ID · e.g. {sampleIds[selected]}
              </p>
              <input
                value={idInput}
                onChange={(e) => setIdInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
                placeholder={sampleIds[selected]}
                autoCapitalize="none"
                autoCorrect="off"
                autoComplete="off"
                spellCheck="false"
                className="ssas-mono focus-ring"
                style={{
                  width: "100%", padding: "11px 12px", borderRadius: 8, marginBottom: 12,
                  border: "1px solid #26395C", background: "#101D35", color: "#fff", fontSize: 14,
                }}
              />
              {error && (
                <p style={{ color: "#F2A79E", fontSize: 12.5, marginBottom: 10, display: "flex", gap: 6, alignItems: "center" }}>
                  <XCircle size={14} /> {error}
                </p>
              )}
              <Btn onClick={handleSubmit} variant="gold" icon={ScanFace} style={{ width: "100%", justifyContent: "center", marginBottom: 16 }}>
                Verify & sign in
              </Btn>

              <p className="ssas-mono" style={{ color: "#5B6B84", fontSize: 10.5, marginBottom: 8, letterSpacing: 0.4 }}>
                OR TAP TO SIGN IN INSTANTLY
              </p>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {matchingAccounts.map((a) => (
                  <button
                    type="button"
                    key={a.id}
                    onClick={() => attemptLogin(a)}
                    className="focus-ring"
                    style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      background: "#101D35", border: "1px solid #26395C", borderRadius: 8,
                      padding: "9px 12px", cursor: "pointer", textAlign: "left",
                    }}
                  >
                    <span style={{ color: "#fff", fontSize: 13, fontWeight: 600 }}>{a.name}</span>
                    <span className="ssas-mono" style={{ color: "#8E9DB5", fontSize: 11 }}>{a.id}</span>
                  </button>
                ))}
              </div>
            </>
          )}
          </>
          )}
        </Card>
        <p className="ssas-mono" style={{ textAlign: "center", color: "#5B6B84", fontSize: 11, marginTop: 16 }}>
          BUBT · Dept. of CSE · Demo build, not connected to production data
        </p>
      </div>
    </div>
  );
}

export default LoginScreen;
