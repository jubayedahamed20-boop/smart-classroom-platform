import React, { useMemo, useState } from "react";
import { FileBarChart2, AlertTriangle, Download, RefreshCw } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE, ACCOUNTS } from "../constants/mockData";
import { Card, Btn, SectionHeader, Badge } from "./ui";

const toDate = (s) => new Date(`${s}T00:00:00`);
const toISO = (d) => d.toISOString().slice(0, 10);
const addDays = (s, n) => {
  const d = toDate(s);
  d.setDate(d.getDate() + n);
  return toISO(d);
};
const weekdayLabel = (s) => toDate(s).toLocaleDateString("en-US", { weekday: "short" });

function pctOf(rows) {
  if (!rows.length) return null;
  const score = rows.reduce((sum, r) => sum + (r.status === "present" ? 1 : r.status === "late" ? 0.5 : 0), 0);
  return Math.round((score / rows.length) * 100);
}

function buildReport(myCourses, records, threshold) {
  const allDates = records.map((r) => r.date).sort();
  const weekEnd = allDates.length ? allDates[allDates.length - 1] : toISO(new Date());
  const weekStart = addDays(weekEnd, -6);
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const courses = myCourses.map((c) => {
    const courseRecords = records.filter((r) => r.courseId === c.courseId && r.date >= weekStart && r.date <= weekEnd);
    const overallPct = pctOf(courseRecords);

    const dayBreakdown = days.map((d) => {
      const dayRows = courseRecords.filter((r) => r.date === d);
      return {
        date: d,
        label: weekdayLabel(d),
        present: dayRows.filter((r) => r.status === "present").length,
        late: dayRows.filter((r) => r.status === "late").length,
        absent: dayRows.filter((r) => r.status === "absent" || r.status === "denied").length,
        total: dayRows.length,
      };
    });

    const atRisk = c.students
      .map((studentId) => {
        const acc = ACCOUNTS.find((a) => a.id === studentId);
        const rows = courseRecords.filter((r) => r.studentId === studentId);
        const pct = pctOf(rows);
        return { id: studentId, name: acc?.name || studentId, pct };
      })
      .filter((s) => s.pct !== null && s.pct < threshold)
      .sort((a, b) => a.pct - b.pct);

    return { courseId: c.courseId, title: c.title, overallPct, dayBreakdown, atRisk, studentCount: c.students.length };
  });

  return { weekStart, weekEnd, generatedAt: new Date().toLocaleString(), threshold, courses };
}

function exportText(report) {
  const lines = [];
  lines.push(`Weekly attendance report`);
  lines.push(`Week: ${report.weekStart} to ${report.weekEnd}`);
  lines.push(`Generated: ${report.generatedAt}`);
  lines.push(`Threshold: ${report.threshold}%`);
  lines.push("");
  report.courses.forEach((c) => {
    lines.push(`== ${c.courseId} · ${c.title} ==`);
    lines.push(`Overall attendance: ${c.overallPct === null ? "no data" : c.overallPct + "%"}`);
    lines.push(`Day-by-day: ${c.dayBreakdown.map((d) => `${d.label} ${d.date} (P${d.present}/L${d.late}/A${d.absent})`).join(", ")}`);
    if (c.atRisk.length) {
      lines.push(`At-risk students (< ${report.threshold}%):`);
      c.atRisk.forEach((s) => lines.push(`  - ${s.name} (${s.id}): ${s.pct}%`));
    } else {
      lines.push(`At-risk students: none`);
    }
    lines.push("");
  });
  return lines.join("\n");
}

function downloadReport(report) {
  const text = exportText(report);
  const blob = new Blob([text], { type: "text/plain" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `weekly-report_${report.weekStart}_to_${report.weekEnd}.txt`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function WeeklyReportView({ teacher, records, threshold }) {
  const myCourses = useMemo(() => SCHEDULE.filter((s) => s.teacher === teacher.id), [teacher.id]);
  const [report, setReport] = useState(null);

  const generate = () => setReport(buildReport(myCourses, records, threshold));

  return (
    <div>
      <SectionHeader
        eyebrow="Process 6.0 · Generate Reports & Statistics"
        title="This week's report"
        action={
          <div style={{ display: "flex", gap: 8 }}>
            {report && (
              <Btn variant="ghost" icon={Download} onClick={() => downloadReport(report)} style={{ fontSize: 12, padding: "8px 14px" }}>
                Export
              </Btn>
            )}
            <Btn icon={report ? RefreshCw : FileBarChart2} onClick={generate} style={{ fontSize: 12, padding: "8px 14px" }}>
              {report ? "Regenerate" : "Generate this week's report"}
            </Btn>
          </div>
        }
      />

      {myCourses.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>No classes assigned yet.</Card>
      ) : !report ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>
          <FileBarChart2 size={22} color={COLORS.steelLight} style={{ marginBottom: 8 }} />
          <div>Generate a snapshot to compile attendance %, at-risk students, and a day-by-day breakdown for each of your classes.</div>
        </Card>
      ) : (
        <div style={{ display: "grid", gap: 20 }}>
          <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>
            Week {report.weekStart} → {report.weekEnd} · generated {report.generatedAt} · threshold {report.threshold}%
          </div>
          {report.courses.map((c) => (
            <Card key={c.courseId} style={{ padding: 18 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14, flexWrap: "wrap", gap: 10 }}>
                <div>
                  <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{c.courseId} · {c.studentCount} students</div>
                  <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.ink }}>{c.title}</div>
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Weekly attendance</span>
                  <Badge tone={c.overallPct === null ? "steel" : c.overallPct < 70 ? "red" : c.overallPct < 85 ? "gold" : "teal"}>
                    {c.overallPct === null ? "no data" : `${c.overallPct}%`}
                  </Badge>
                </div>
              </div>

              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.steel, marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.4 }}>Day-by-day</div>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 8 }}>
                  {c.dayBreakdown.map((d) => (
                    <div key={d.date} style={{ border: `1px solid ${COLORS.paper}`, borderRadius: 8, padding: "8px 6px", textAlign: "center" }}>
                      <div className="ssas-mono" style={{ fontSize: 10.5, color: COLORS.steel, marginBottom: 4 }}>{d.label}</div>
                      {d.total === 0 ? (
                        <div style={{ fontSize: 11, color: COLORS.steelLight }}>—</div>
                      ) : (
                        <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.ink }}>
                          {d.present + d.late}/{d.total}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.steel, marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.4 }}>
                  At-risk students (below {report.threshold}%)
                </div>
                {c.atRisk.length === 0 ? (
                  <div style={{ fontSize: 13, color: COLORS.steel }}>None this week.</div>
                ) : (
                  <div style={{ display: "grid", gap: 6 }}>
                    {c.atRisk.map((s) => (
                      <div key={s.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "7px 10px", background: COLORS.paper, borderRadius: 7 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <AlertTriangle size={13} color={COLORS.red} />
                          <span style={{ fontSize: 13, fontWeight: 600, color: COLORS.ink }}>{s.name}</span>
                          <span className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel }}>{s.id}</span>
                        </div>
                        <Badge tone="red">{s.pct}%</Badge>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default WeeklyReportView;
