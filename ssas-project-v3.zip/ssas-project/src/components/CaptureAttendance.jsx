import React, { useState } from "react";
import { ShieldCheck, Fingerprint, CheckCheck } from "lucide-react";
import { COLORS } from "../constants/colors";
import { Badge, Card, Btn, SectionHeader, StatusBadge } from "./ui";
import ScanBadge from "./ScanBadge";

function CaptureAttendance({ session, roster, records, onScanResult, onOverride, onEndSession, onToggleCheckIn }) {
  const [overrideFor, setOverrideFor] = useState(null);
  const [reason, setReason] = useState("");

  const rec = (studentId) => records.find((r) => r.studentId === studentId && r.sessionKey === session.key);

  const markAllPresent = () => {
    roster.forEach((s) => {
      if (!rec(s.id)) onOverride(session.key, s.id, "present", "bulk mark-all present");
    });
  };

  return (
    <div>
      <SectionHeader
        eyebrow="Process 2.0 · Capture & Verify Attendance"
        title={`${session.courseId} — live session`}
        action={
          <div style={{ display: "flex", alignItems: "center", gap: 14, flexWrap: "wrap" }}>
            <span className="ssas-mono" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: COLORS.teal, fontWeight: 600 }}>
              <span className="live-dot" style={{ width: 7, height: 7, borderRadius: 99, background: COLORS.teal, display: "inline-block" }} /> LIVE · {session.room} · {session.time}
            </span>
            <Btn
              variant={session.checkInOpen ? "primary" : "gold"}
              onClick={onToggleCheckIn}
              icon={session.checkInOpen ? ShieldCheck : Fingerprint}
              style={{ fontSize: 12, padding: "6px 12px" }}
            >
              {session.checkInOpen ? "Student check-in: ON" : "Allow student check-in"}
            </Btn>
            <Btn variant="danger" onClick={onEndSession} style={{ fontSize: 12, padding: "6px 12px" }}>End session</Btn>
          </div>
        }
      />
      {!session.checkInOpen && (
        <p className="ssas-mono" style={{ fontSize: 12, color: COLORS.steel, marginTop: -8, marginBottom: 18 }}>
          Students can't self-check-in yet — tap "Allow student check-in" once you're ready for them to verify their own faces at login.
        </p>
      )}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 14 }}>
        {roster.map((s) => (
          <ScanBadge key={s.id} student={s} onResult={(id, outcome, sc) => onScanResult(session.key, id, outcome, sc)} />
        ))}
      </div>

      <div style={{ marginTop: 26 }}>
        <SectionHeader
          eyebrow="Process 3.0 · Manage Manual Override"
          title="Session roster & corrections"
          action={
            <Btn variant="ghost" icon={CheckCheck} onClick={markAllPresent} style={{ fontSize: 12, padding: "6px 12px" }}>
              Mark all present
            </Btn>
          }
        />
        <Card style={{ overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
            <thead>
              <tr style={{ background: COLORS.paper, textAlign: "left" }}>
                {["Student", "ID", "Method", "Status", ""].map((h) => (
                  <th key={h} className="ssas-mono" style={{ padding: "9px 14px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase", letterSpacing: 0.5 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {roster.map((s) => {
                const r = rec(s.id);
                return (
                  <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                    <td style={{ padding: "10px 14px", fontWeight: 600, color: COLORS.ink }}>{s.name}</td>
                    <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{s.id}</td>
                    <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{r ? r.method : "—"}</td>
                    <td style={{ padding: "10px 14px" }}>{r ? <StatusBadge status={r.status === "denied" ? "absent" : r.status} /> : <Badge tone="steel">pending</Badge>}</td>
                    <td style={{ padding: "10px 14px", textAlign: "right" }}>
                      <Btn variant="ghost" style={{ fontSize: 12, padding: "5px 10px" }} onClick={() => setOverrideFor(s)}>Override</Btn>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </Card>
      </div>

      {overrideFor && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(18,33,59,0.45)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 50, padding: 20 }}>
          <Card style={{ padding: 22, width: "100%", maxWidth: 400 }}>
            <h3 className="ssas-display" style={{ margin: "0 0 4px", fontSize: 17, color: COLORS.ink }}>Manual override</h3>
            <p className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel, margin: "0 0 16px" }}>{overrideFor.name} · {overrideFor.id}</p>
            <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
              {["present", "late", "absent"].map((st) => (
                <button
                  type="button"
                  key={st}
                  onClick={() => onOverride(session.key, overrideFor.id, st, reason)}
                  className="focus-ring"
                  style={{ flex: 1, padding: "8px 0", borderRadius: 8, border: `1px solid ${COLORS.steelLight}`, background: "#fff", cursor: "pointer", fontSize: 12.5, fontWeight: 700, color: COLORS.ink, textTransform: "capitalize" }}
                >
                  {st}
                </button>
              ))}
            </div>
            <textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Reason for override (logged to audit trail, D7)…"
              className="focus-ring"
              style={{ width: "100%", minHeight: 70, borderRadius: 8, border: `1px solid ${COLORS.steelLight}`, padding: 10, fontSize: 13, fontFamily: "inherit", resize: "vertical" }}
            />
            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 14 }}>
              <Btn variant="ghost" onClick={() => { setOverrideFor(null); setReason(""); }}>Cancel</Btn>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Teacher: schedule, reports ---------------------------- */


export default CaptureAttendance;
