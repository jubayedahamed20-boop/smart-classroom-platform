import React from "react";
import { COLORS } from "../constants/colors";

function Badge({ tone = "steel", children }) {
  const map = {
    steel: { bg: "#EEF1F6", fg: COLORS.steel },
    teal: { bg: "#E4F2F0", fg: COLORS.teal },
    red: { bg: "#FBEAE8", fg: COLORS.red },
    gold: { bg: "#FBF2DF", fg: COLORS.goldDeep },
  };
  const c = map[tone];
  return (
    <span
      className="ssas-mono"
      style={{
        background: c.bg, color: c.fg, fontSize: 11, fontWeight: 600,
        padding: "3px 8px", borderRadius: 5, letterSpacing: 0.3, textTransform: "uppercase",
      }}
    >
      {children}
    </span>
  );
}

function StatusBadge({ status }) {
  if (status === "present") return <Badge tone="teal">present</Badge>;
  if (status === "late") return <Badge tone="gold">late</Badge>;
  if (status === "absent") return <Badge tone="red">absent</Badge>;
  return <Badge tone="steel">{status}</Badge>;
}

function Card({ children, style }) {
  return (
    <div
      style={{
        background: COLORS.card, borderRadius: 14, border: `1px solid ${COLORS.steelLight}`,
        boxShadow: "0 1px 2px rgba(18,33,59,0.04)", ...style,
      }}
    >
      {children}
    </div>
  );
}

function Btn({ children, onClick, variant = "primary", icon: Icon, style, disabled, type = "button" }) {
  const variants = {
    primary: { background: COLORS.ink, color: "#fff", border: "none" },
    gold: { background: COLORS.gold, color: COLORS.ink, border: "none" },
    ghost: { background: "transparent", color: COLORS.ink, border: `1px solid ${COLORS.steelLight}` },
    danger: { background: "transparent", color: COLORS.red, border: `1px solid #E7B9B4` },
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className="focus-ring"
      style={{
        ...variants[variant], padding: "9px 16px", borderRadius: 9, fontSize: 13.5, fontWeight: 600,
        cursor: disabled ? "not-allowed" : "pointer", opacity: disabled ? 0.45 : 1,
        display: "inline-flex", alignItems: "center", gap: 7, fontFamily: "'IBM Plex Sans', sans-serif",
        transition: "opacity 0.12s ease", touchAction: "manipulation", WebkitTapHighlightColor: "transparent", ...style,
      }}
    >
      {Icon && <Icon size={15} />} {children}
    </button>
  );
}

function SectionHeader({ eyebrow, title, action }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 18, flexWrap: "wrap", gap: 10 }}>
      <div>
        <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, letterSpacing: 1, textTransform: "uppercase", marginBottom: 4 }}>
          {eyebrow}
        </div>
        <h2 className="ssas-display" style={{ fontSize: 22, fontWeight: 800, color: COLORS.ink, margin: 0 }}>
          {title}
        </h2>
      </div>
      {action}
    </div>
  );
}

export { Badge, StatusBadge, Card, Btn, SectionHeader };
