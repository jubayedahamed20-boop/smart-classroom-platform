import React from "react";
import { COLORS } from "../constants/colors";
import { Card, Badge, SectionHeader } from "./ui";

function AuditLogView({ log }) {
  return (
    <div>
      <SectionHeader eyebrow="D7 · Audit Log" title="System & override activity" />
      <Card style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: COLORS.paper, textAlign: "left" }}>
              {["Time", "Actor", "Action", "Detail"].map((h) => (
                <th key={h} className="ssas-mono" style={{ padding: "9px 14px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {log.length === 0 ? (
              <tr><td colSpan={4} style={{ padding: 24, textAlign: "center", color: COLORS.steel }}>No activity yet this session.</td></tr>
            ) : log.map((l, i) => (
              <tr key={i} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{l.time}</td>
                <td style={{ padding: "10px 14px", fontWeight: 600 }}>{l.actor}</td>
                <td style={{ padding: "10px 14px" }}><Badge tone={l.action === "override" ? "gold" : "steel"}>{l.action}</Badge></td>
                <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{l.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

/* ---------------------------- Student view ---------------------------- */


export default AuditLogView;
