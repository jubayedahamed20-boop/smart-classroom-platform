import React from "react";
import { Calendar, Clock, ShieldCheck, Radio } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE } from "../constants/mockData";
import { Card, Btn, SectionHeader } from "./ui";

function SessionPicker({ onPick }) {
  return (
    <div>
      <SectionHeader eyebrow="Process 4.0 · Manage Class Schedule" title="Choose a session to open" />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 14 }}>
        {SCHEDULE.map((s) => (
          <Card key={s.courseId} style={{ padding: 18 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
              <div>
                <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{s.courseId}</div>
                <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.ink }}>{s.title}</div>
              </div>
              <Calendar size={16} color={COLORS.steel} />
            </div>
            <div className="ssas-mono" style={{ fontSize: 12.5, color: COLORS.steel, marginBottom: 14, display: "flex", alignItems: "center", gap: 6 }}>
              <Clock size={13} /> {s.time} · {s.room}
            </div>
            <Btn onClick={() => onPick(s)} icon={Radio} style={{ width: "100%", justifyContent: "center" }}>Open session</Btn>
          </Card>
        ))}
        <Card style={{ padding: 18, opacity: 0.5, display: "flex", flexDirection: "column", justifyContent: "center", alignItems: "center", gap: 6, background: COLORS.paper, border: `1px dashed ${COLORS.steelLight}` }}>
          <ShieldCheck size={20} color={COLORS.steel} />
          <span className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel, textAlign: "center" }}>Process 8.0 · LMS sync<br />planned, out of scope</span>
        </Card>
      </div>
    </div>
  );
}


export default SessionPicker;
