import React, { useMemo } from "react";
import { COLORS } from "../constants/colors";
import { ACCOUNTS } from "../constants/mockData";
import { Card, SectionHeader } from "./ui";

function ReportsView({ records }) {
  const byStudent = useMemo(() => {
    const map = {};
    records.forEach((r) => {
      if (!map[r.studentId]) map[r.studentId] = { present: 0, late: 0, absent: 0, total: 0 };
      const bucket = r.status === "denied" ? "absent" : r.status;
      map[r.studentId][bucket] = (map[r.studentId][bucket] || 0) + 1;
      map[r.studentId].total += 1;
    });
    return map;
  }, [records]);

  return (
    <div>
      <SectionHeader eyebrow="Process 6.0 · Generate Reports & Statistics" title="Attendance percentage by student" />
      <Card style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
          <thead>
            <tr style={{ background: COLORS.paper, textAlign: "left" }}>
              {["Student", "Present", "Late", "Absent", "Attendance %"].map((h) => (
                <th key={h} className="ssas-mono" style={{ padding: "9px 14px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ACCOUNTS.filter((a) => a.role === "student").map((s) => {
              const b = byStudent[s.id] || { present: 0, late: 0, absent: 0, total: 0 };
              const pct = b.total ? Math.round(((b.present + b.late * 0.5) / b.total) * 100) : 0;
              return (
                <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                  <td style={{ padding: "10px 14px", fontWeight: 600, color: COLORS.ink }}>{s.name}</td>
                  <td style={{ padding: "10px 14px" }}>{b.present}</td>
                  <td style={{ padding: "10px 14px" }}>{b.late}</td>
                  <td style={{ padding: "10px 14px" }}>{b.absent}</td>
                  <td style={{ padding: "10px 14px", width: 180 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <div style={{ flex: 1, height: 6, borderRadius: 4, background: COLORS.paper, overflow: "hidden" }}>
                        <div style={{ width: `${pct}%`, height: "100%", background: pct < 70 ? COLORS.red : pct < 85 ? COLORS.gold : COLORS.teal }} />
                      </div>
                      <span className="ssas-mono" style={{ fontSize: 12, fontWeight: 700, color: COLORS.ink }}>{pct}%</span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}


export default ReportsView;
