import React, { useEffect, useMemo, useState } from "react";
import { AlertTriangle, CheckCircle2, Radio, ShieldCheck, TrendingDown, TrendingUp } from "lucide-react";
import { COLORS } from "../constants/colors";
import { Card, SectionHeader, StatusBadge, Badge, Btn } from "./ui";
import ScanBadge from "./ScanBadge";

// Given present/total sessions and a required threshold %, work out either
// how many more sessions must be attended to climb back above it, or how
// many more can safely be missed while staying above it.
function riskProjection(present, total, threshold) {
  const t = threshold / 100;
  if (total === 0) return { pct: 100, status: "safe", detail: "No sessions logged yet for this course." };
  const pct = Math.round((present / total) * 100);
  if (pct >= threshold) {
    // present / (total + m) >= t  =>  m <= present/t - total
    const margin = Math.max(0, Math.floor(present / t - total));
    return {
      pct,
      status: "safe",
      detail: margin > 0
        ? `Can miss up to ${margin} more class${margin === 1 ? "" : "es"} and stay at or above ${threshold}%.`
        : `Right at the line — one more absence will drop you below ${threshold}%.`,
    };
  }
  // (present + n) / (total + n) >= t  =>  n >= (t*total - present) / (1 - t)
  const needed = Math.max(1, Math.ceil((t * total - present) / (1 - t)));
  return {
    pct,
    status: "risk",
    detail: `Attend the next ${needed} class${needed === 1 ? "" : "es"} in a row to climb back to ${threshold}%.`,
  };
}

function LiveSessionCard({ student, session, records, onScanResult }) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const enrolled = session && session.students.includes(student.id);
  if (!session || !enrolled) return null;

  const myRecord = records.find((r) => r.sessionKey === session.key && r.studentId === student.id);

  return (
    <Card style={{ padding: 18, marginBottom: 18, background: COLORS.ink, border: "none" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span className="live-dot" style={{ width: 9, height: 9, borderRadius: 999, background: session.checkInOpen ? "#4ADE80" : COLORS.steelLight, flexShrink: 0, marginTop: 1 }} />
          <div>
            <div className="ssas-mono" style={{ fontSize: 11, color: "#8E9DB5", letterSpacing: 0.5, textTransform: "uppercase", marginBottom: 3 }}>
              Live now · {session.room}
            </div>
            <div className="ssas-display" style={{ fontSize: 17, fontWeight: 800, color: "#fff" }}>
              {session.title} <span className="ssas-mono" style={{ fontWeight: 500, fontSize: 12.5, color: "#8E9DB5" }}>· {session.courseId}</span>
            </div>
          </div>
        </div>
        <div className="ssas-mono" style={{ fontSize: 20, fontWeight: 600, color: "#fff", letterSpacing: 1 }}>
          {now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
        </div>
      </div>

      <div style={{ marginTop: 14 }}>
        {myRecord ? (
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#182A47", borderRadius: 9, padding: "10px 14px" }}>
            <CheckCircle2 size={16} color={COLORS.teal} />
            <span style={{ color: "#fff", fontSize: 13.5, fontWeight: 600 }}>
              You're marked <StatusBadge status={myRecord.status === "denied" ? "absent" : myRecord.status} /> for this session.
            </span>
          </div>
        ) : session.checkInOpen ? (
          <div style={{ maxWidth: 340 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
              <Radio size={15} color={COLORS.gold} />
              <span className="ssas-mono" style={{ fontSize: 12, color: COLORS.gold, letterSpacing: 0.4 }}>CHECK-IN OPEN · VERIFY NOW</span>
            </div>
            <ScanBadge student={student} onResult={(id, outcome, score) => onScanResult(session.key, id, outcome, score)} />
          </div>
        ) : (
          <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#182A47", borderRadius: 9, padding: "10px 14px" }}>
            <ShieldCheck size={16} color={COLORS.steelLight} />
            <span style={{ color: "#C7CEDA", fontSize: 13, fontWeight: 600 }}>
              Session is open, but check-in hasn't been enabled by your instructor yet.
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}

function StudentView({ student, records, session, onScanResult, threshold = 75 }) {
  const mine = useMemo(() => records.filter((r) => r.studentId === student.id), [records, student.id]);
  const present = mine.filter((r) => r.status === "present" || r.status === "late").length;
  const pct = mine.length ? Math.round((present / mine.length) * 100) : 100;

  const byCourse = useMemo(() => {
    const map = {};
    mine.forEach((r) => {
      if (!map[r.courseId]) map[r.courseId] = { present: 0, total: 0 };
      map[r.courseId].total += 1;
      if (r.status === "present" || r.status === "late") map[r.courseId].present += 1;
    });
    return Object.entries(map).map(([courseId, v]) => ({ courseId, ...v, ...riskProjection(v.present, v.total, threshold) }));
  }, [mine, threshold]);

  const atRiskCourses = byCourse.filter((c) => c.status === "risk");

  return (
    <div>
      <SectionHeader eyebrow="Process 6.0 · Personal report" title={`Welcome, ${student.name.split(" ")[0]}`} />

      <LiveSessionCard student={student} session={session} records={records} onScanResult={onScanResult} />

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px,1fr))", gap: 12, marginBottom: 18 }}>
        <Card style={{ padding: 16 }}>
          <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Overall attendance</div>
          <div className="ssas-display" style={{ fontSize: 30, fontWeight: 800, color: pct < threshold ? COLORS.red : COLORS.ink }}>{pct}%</div>
        </Card>
        <Card style={{ padding: 16 }}>
          <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Sessions logged</div>
          <div className="ssas-display" style={{ fontSize: 30, fontWeight: 800, color: COLORS.ink }}>{mine.length}</div>
        </Card>
        <Card style={{ padding: 16 }}>
          <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Risk status</div>
          <div style={{ marginTop: 6 }}>
            {atRiskCourses.length === 0 ? (
              <Badge tone="teal">all courses safe</Badge>
            ) : (
              <Badge tone="red">{atRiskCourses.length} course{atRiskCourses.length === 1 ? "" : "s"} at risk</Badge>
            )}
          </div>
        </Card>
      </div>

      {/* Attendance risk predictor */}
      <SectionHeader eyebrow="Attendance risk predictor" title={`Per-course standing vs. ${threshold}% minimum`} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px,1fr))", gap: 12, marginBottom: 22 }}>
        {byCourse.length === 0 && (
          <Card style={{ padding: 20, color: COLORS.steel, fontSize: 13.5 }}>No attendance history yet.</Card>
        )}
        {byCourse.map((c) => (
          <Card key={c.courseId} style={{ padding: 16, borderLeft: `3px solid ${c.status === "risk" ? COLORS.red : COLORS.teal}` }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
              <div>
                <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{c.courseId}</div>
                <div className="ssas-display" style={{ fontSize: 22, fontWeight: 800, color: c.status === "risk" ? COLORS.red : COLORS.ink }}>{c.pct}%</div>
              </div>
              {c.status === "risk" ? (
                <AlertTriangle size={18} color={COLORS.red} />
              ) : (
                <TrendingUp size={18} color={COLORS.teal} />
              )}
            </div>
            <div style={{ height: 6, borderRadius: 4, background: COLORS.paper, overflow: "hidden", marginBottom: 10 }}>
              <div style={{ height: "100%", width: `${Math.min(100, c.pct)}%`, background: c.status === "risk" ? COLORS.red : COLORS.teal, borderRadius: 4 }} />
            </div>
            <div style={{ fontSize: 12.5, color: COLORS.steel, lineHeight: 1.5 }}>
              {c.status === "risk" ? (
                <span style={{ color: COLORS.red, fontWeight: 600 }}>
                  <TrendingDown size={12} style={{ verticalAlign: -1, marginRight: 4 }} />
                  Below minimum — {c.detail}
                </span>
              ) : (
                c.detail
              )}
            </div>
          </Card>
        ))}
      </div>

      <Card style={{ overflow: "hidden" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
          <thead>
            <tr style={{ background: COLORS.paper, textAlign: "left" }}>
              {["Course", "Date", "Method", "Status"].map((h) => (
                <th key={h} className="ssas-mono" style={{ padding: "9px 14px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mine.slice(-12).reverse().map((r, i) => (
              <tr key={i} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                <td style={{ padding: "10px 14px", fontWeight: 600 }}>{r.courseId}</td>
                <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{r.date}</td>
                <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{r.method}</td>
                <td style={{ padding: "10px 14px" }}><StatusBadge status={r.status === "denied" ? "absent" : r.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

export default StudentView;
