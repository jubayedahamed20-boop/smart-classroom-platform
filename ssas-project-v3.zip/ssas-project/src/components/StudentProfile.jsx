import React, { useMemo } from "react";
import { Mail, ShieldCheck, GraduationCap, BookOpen } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE } from "../constants/mockData";
import { Card, SectionHeader, Badge } from "./ui";

function initials(name) {
  return name.split(" ").map((n) => n[0]).slice(0, 2).join("").toUpperCase();
}

function StudentProfile({ student, records, threshold = 75 }) {
  const mine = records.filter((r) => r.studentId === student.id);
  const present = mine.filter((r) => r.status === "present" || r.status === "late").length;
  const pct = mine.length ? Math.round((present / mine.length) * 100) : 100;

  const myCourses = useMemo(() => SCHEDULE.filter((s) => s.students.includes(student.id)), [student.id]);

  return (
    <div>
      <SectionHeader eyebrow="Process 1.0 · Account" title="My profile" />

      <Card style={{ padding: 22, marginBottom: 16, display: "flex", gap: 18, alignItems: "center", flexWrap: "wrap" }}>
        <div
          style={{
            width: 64, height: 64, borderRadius: "50%", background: COLORS.ink,
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
          }}
        >
          <span className="ssas-display" style={{ color: COLORS.gold, fontWeight: 800, fontSize: 22 }}>{initials(student.name)}</span>
        </div>
        <div style={{ flex: 1, minWidth: 200 }}>
          <div className="ssas-display" style={{ fontSize: 20, fontWeight: 800, color: COLORS.ink }}>{student.name}</div>
          <div className="ssas-mono" style={{ fontSize: 12.5, color: COLORS.steel, marginTop: 2 }}>{student.id} · {student.dept} · {student.status}</div>
        </div>
        <Badge tone={pct < threshold ? "red" : "teal"}>{pct}% overall attendance</Badge>
      </Card>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px,1fr))", gap: 12, marginBottom: 16 }}>
        <Card style={{ padding: 16, display: "flex", gap: 10, alignItems: "center" }}>
          <GraduationCap size={18} color={COLORS.steel} />
          <div>
            <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Department</div>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.ink }}>{student.dept}</div>
          </div>
        </Card>
        <Card style={{ padding: 16, display: "flex", gap: 10, alignItems: "center" }}>
          <BookOpen size={18} color={COLORS.steel} />
          <div>
            <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Enrolled courses</div>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.ink }}>{myCourses.length}</div>
          </div>
        </Card>
        <Card style={{ padding: 16, display: "flex", gap: 10, alignItems: "center" }}>
          <ShieldCheck size={18} color={COLORS.steel} />
          <div>
            <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Guardian contact</div>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.ink }}>on file, encrypted</div>
          </div>
        </Card>
        <Card style={{ padding: 16, display: "flex", gap: 10, alignItems: "center" }}>
          <Mail size={18} color={COLORS.steel} />
          <div>
            <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>Notifications</div>
            <div style={{ fontSize: 13.5, fontWeight: 600, color: COLORS.ink }}>email + SMS enabled</div>
          </div>
        </Card>
      </div>

      <Card style={{ padding: 16 }}>
        <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steel, textTransform: "uppercase", marginBottom: 10 }}>Enrolled in</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {myCourses.map((c) => (
            <div key={c.courseId} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 0", borderTop: `1px solid ${COLORS.paper}` }}>
              <div>
                <span style={{ fontWeight: 600, fontSize: 13.5, color: COLORS.ink }}>{c.title}</span>
                <span className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel, marginLeft: 8 }}>{c.courseId}</span>
              </div>
              <span className="ssas-mono" style={{ fontSize: 12, color: COLORS.steel }}>{c.time}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

export default StudentProfile;
