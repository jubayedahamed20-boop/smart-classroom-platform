import React, { useMemo } from "react";
import { Megaphone, AlertCircle, Paperclip } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE } from "../constants/mockData";
import { Card, SectionHeader, Badge } from "./ui";

function AnnouncementsView({ student, announcements }) {
  const myCourseIds = useMemo(
    () => SCHEDULE.filter((s) => s.students.includes(student.id)).map((s) => s.courseId),
    [student.id]
  );

  const feed = useMemo(
    () =>
      announcements
        .filter((a) => a.courseId === null || myCourseIds.includes(a.courseId))
        .slice()
        .sort((a, b) => (a.date < b.date ? 1 : -1)),
    [announcements, myCourseIds]
  );

  return (
    <div>
      <SectionHeader eyebrow="Notice board" title="Announcements" />
      {feed.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>No announcements right now.</Card>
      ) : (
        <div style={{ display: "grid", gap: 12 }}>
          {feed.map((a) => (
            <Card key={a.id} style={{ padding: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  {a.priority === "high" ? <AlertCircle size={16} color={COLORS.red} /> : <Megaphone size={16} color={COLORS.steel} />}
                  <span style={{ fontWeight: 700, fontSize: 14.5, color: COLORS.ink }}>{a.title}</span>
                </div>
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  {a.priority === "high" && <Badge tone="red">important</Badge>}
                  <Badge tone={a.courseId ? "steel" : "gold"}>{a.courseId || "general"}</Badge>
                </div>
              </div>
              <p style={{ fontSize: 13.5, color: COLORS.steel, lineHeight: 1.55, margin: "0 0 10px" }}>{a.body}</p>
              {a.materialsUrl && (
                <a
                  href={a.materialsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="focus-ring"
                  style={{
                    display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 600,
                    color: COLORS.teal, textDecoration: "none", marginBottom: 10,
                  }}
                >
                  <Paperclip size={12} /> {a.materialsLabel || "Attached material"}
                </a>
              )}
              <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steelLight, marginTop: a.materialsUrl ? 0 : undefined }}>
                {a.author} · {a.date}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default AnnouncementsView;
