import React, { useMemo } from "react";
import { AlertTriangle, CheckCircle2 } from "lucide-react";
import { COLORS } from "../constants/colors";
import { ACCOUNTS } from "../constants/mockData";
import { Card, Badge, SectionHeader } from "./ui";

function NotificationsView({ records, threshold }) {
  const alerts = useMemo(() => {
    const map = {};
    records.forEach((r) => {
      if (!map[r.studentId]) map[r.studentId] = { present: 0, total: 0 };
      map[r.studentId].total += 1;
      if (r.status === "present" || r.status === "late") map[r.studentId].present += 1;
    });
    return Object.entries(map)
      .map(([id, v]) => ({ id, pct: v.total ? Math.round((v.present / v.total) * 100) : 100 }))
      .filter((a) => a.pct < threshold);
  }, [records, threshold]);

  return (
    <div>
      <SectionHeader eyebrow="Process 7.0 · Monitor Threshold & Notify" title={`Alerts for attendance below ${threshold}%`} />
      {alerts.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>
          <CheckCircle2 size={22} color={COLORS.teal} style={{ marginBottom: 8 }} />
          <div>No students currently below the threshold.</div>
        </Card>
      ) : (
        <div style={{ display: "grid", gap: 10 }}>
          {alerts.map((a) => {
            const acc = ACCOUNTS.find((x) => x.id === a.id);
            return (
              <Card key={a.id} style={{ padding: 14, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <AlertTriangle size={18} color={COLORS.red} />
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{acc?.name || a.id}</div>
                    <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{a.pct}% attendance · guardian SMS + email queued</div>
                  </div>
                </div>
                <Badge tone="red">below threshold</Badge>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------------------- Admin: accounts + audit ---------------------------- */


export default NotificationsView;
