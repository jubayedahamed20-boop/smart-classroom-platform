import React, { useState } from "react";
import { Plus } from "lucide-react";
import { COLORS } from "../constants/colors";
import { Card, Badge, Btn, SectionHeader } from "./ui";

function AccountsView({ accounts, onAddAccount, threshold, setThreshold }) {
  const [name, setName] = useState("");
  const [role, setRole] = useState("student");

  return (
    <div>
      <SectionHeader eyebrow="Process 5.0 · Manage Accounts & Configuration" title="Accounts & alert threshold" />
      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 16, alignItems: "start" }}>
        <Card style={{ overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
            <thead>
              <tr style={{ background: COLORS.paper, textAlign: "left" }}>
                {["Name", "ID", "Role", "Status"].map((h) => (
                  <th key={h} className="ssas-mono" style={{ padding: "9px 14px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {accounts.map((a) => (
                <tr key={a.id} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                  <td style={{ padding: "10px 14px", fontWeight: 600 }}>{a.name}</td>
                  <td className="ssas-mono" style={{ padding: "10px 14px", color: COLORS.steel }}>{a.id}</td>
                  <td style={{ padding: "10px 14px", textTransform: "capitalize" }}>{a.role}</td>
                  <td style={{ padding: "10px 14px" }}><Badge tone="teal">{a.status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        <Card style={{ padding: 18 }}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 12 }}>Add account</div>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" className="focus-ring" style={{ width: "100%", padding: "9px 11px", borderRadius: 8, border: `1px solid ${COLORS.steelLight}`, marginBottom: 8, fontSize: 13 }} />
          <select value={role} onChange={(e) => setRole(e.target.value)} className="focus-ring" style={{ width: "100%", padding: "9px 11px", borderRadius: 8, border: `1px solid ${COLORS.steelLight}`, marginBottom: 10, fontSize: 13 }}>
            <option value="student">Student</option>
            <option value="teacher">Teacher</option>
            <option value="admin">Admin</option>
          </select>
          <Btn onClick={() => { if (name.trim()) { onAddAccount(name.trim(), role); setName(""); } }} icon={Plus} style={{ width: "100%", justifyContent: "center", marginBottom: 20 }}>
            Add
          </Btn>

          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8 }}>Absence alert threshold</div>
          <div className="ssas-mono" style={{ fontSize: 12, color: COLORS.steel, marginBottom: 8 }}>Notify guardian when attendance drops below <b style={{ color: COLORS.ink }}>{threshold}%</b></div>
          <input type="range" min="50" max="95" value={threshold} onChange={(e) => setThreshold(Number(e.target.value))} style={{ width: "100%" }} />
        </Card>
      </div>
    </div>
  );
}


export default AccountsView;
