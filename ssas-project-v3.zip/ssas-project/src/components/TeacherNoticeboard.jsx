import React, { useMemo, useState } from "react";
import { Megaphone, AlertCircle, Paperclip, Pencil, Trash2, Plus, X } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE } from "../constants/mockData";
import { Card, Btn, SectionHeader, Badge } from "./ui";

const EMPTY_FORM = {
  courseId: "",
  title: "",
  body: "",
  priority: "normal",
  materialsLabel: "",
  materialsUrl: "",
};

const inputStyle = {
  width: "100%",
  padding: "9px 11px",
  borderRadius: 8,
  border: `1px solid ${COLORS.steelLight}`,
  fontSize: 13,
  fontFamily: "'IBM Plex Sans', sans-serif",
  boxSizing: "border-box",
};

const labelStyle = {
  display: "block",
  fontSize: 11.5,
  fontWeight: 700,
  color: COLORS.steel,
  textTransform: "uppercase",
  letterSpacing: 0.4,
  marginBottom: 6,
};

function TeacherNoticeboard({ teacher, announcements, onAddAnnouncement, onUpdateAnnouncement, onDeleteAnnouncement }) {
  const myCourses = useMemo(() => SCHEDULE.filter((s) => s.teacher === teacher.id), [teacher.id]);
  const myCourseIds = useMemo(() => myCourses.map((c) => c.courseId), [myCourses]);

  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);

  // Posts this teacher is allowed to manage: general notices, or ones scoped to their own courses.
  const myPosts = useMemo(
    () =>
      announcements
        .filter((a) => a.courseId === null || myCourseIds.includes(a.courseId))
        .slice()
        .sort((a, b) => (a.date < b.date ? 1 : -1)),
    [announcements, myCourseIds]
  );

  const setField = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const startCreate = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setFormOpen(true);
  };

  const startEdit = (a) => {
    setEditingId(a.id);
    setForm({
      courseId: a.courseId || "",
      title: a.title,
      body: a.body,
      priority: a.priority,
      materialsLabel: a.materialsLabel || "",
      materialsUrl: a.materialsUrl || "",
    });
    setFormOpen(true);
  };

  const cancelForm = () => {
    setFormOpen(false);
    setEditingId(null);
    setForm(EMPTY_FORM);
  };

  const submit = (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.body.trim()) return;
    const payload = {
      courseId: form.courseId || null,
      title: form.title.trim(),
      body: form.body.trim(),
      priority: form.priority,
      materialsLabel: form.materialsLabel.trim(),
      materialsUrl: form.materialsUrl.trim(),
    };
    if (editingId) {
      onUpdateAnnouncement(editingId, payload);
    } else {
      onAddAnnouncement(payload);
    }
    cancelForm();
  };

  return (
    <div>
      <SectionHeader
        eyebrow="Noticeboard"
        title="Announcements & materials"
        action={
          !formOpen && (
            <Btn icon={Plus} onClick={startCreate} style={{ fontSize: 12, padding: "8px 14px" }}>
              New announcement
            </Btn>
          )
        }
      />

      {formOpen && (
        <Card style={{ padding: 18, marginBottom: 18 }}>
          <form onSubmit={submit}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5, color: COLORS.ink }}>
                {editingId ? "Edit announcement" : "New announcement"}
              </div>
              <button
                type="button"
                onClick={cancelForm}
                className="focus-ring"
                style={{ background: "transparent", border: "none", cursor: "pointer", color: COLORS.steel, padding: 4 }}
              >
                <X size={16} />
              </button>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <div>
                <label style={labelStyle}>Scope</label>
                <select value={form.courseId} onChange={setField("courseId")} className="focus-ring" style={inputStyle}>
                  <option value="">General (all students)</option>
                  {myCourses.map((c) => (
                    <option key={c.courseId} value={c.courseId}>
                      {c.courseId} · {c.title}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Priority</label>
                <select value={form.priority} onChange={setField("priority")} className="focus-ring" style={inputStyle}>
                  <option value="normal">Normal</option>
                  <option value="high">High / important</option>
                </select>
              </div>
            </div>

            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Title</label>
              <input value={form.title} onChange={setField("title")} placeholder="e.g. Quiz moved to next week" className="focus-ring" style={inputStyle} required />
            </div>

            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Message</label>
              <textarea
                value={form.body}
                onChange={setField("body")}
                placeholder="Details for students..."
                rows={4}
                className="focus-ring"
                style={{ ...inputStyle, resize: "vertical", fontFamily: "'IBM Plex Sans', sans-serif" }}
                required
              />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
              <div>
                <label style={labelStyle}>Materials label (optional)</label>
                <input value={form.materialsLabel} onChange={setField("materialsLabel")} placeholder="e.g. Lecture slides (PDF)" className="focus-ring" style={inputStyle} />
              </div>
              <div>
                <label style={labelStyle}>Materials link (optional)</label>
                <input value={form.materialsUrl} onChange={setField("materialsUrl")} placeholder="https://..." className="focus-ring" style={inputStyle} />
              </div>
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <Btn type="button" variant="ghost" onClick={cancelForm} style={{ fontSize: 13 }}>
                Cancel
              </Btn>
              <Btn type="submit" style={{ fontSize: 13 }}>{editingId ? "Save changes" : "Post announcement"}</Btn>
            </div>
          </form>
        </Card>
      )}

      {myPosts.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>
          Nothing posted yet. Use "New announcement" to reach your students.
        </Card>
      ) : (
        <div style={{ display: "grid", gap: 12 }}>
          {myPosts.map((a) => (
            <Card key={a.id} style={{ padding: 16 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  {a.priority === "high" ? <AlertCircle size={16} color={COLORS.red} /> : <Megaphone size={16} color={COLORS.steel} />}
                  <span style={{ fontWeight: 700, fontSize: 14.5, color: COLORS.ink }}>{a.title}</span>
                </div>
                <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                  {a.priority === "high" && <Badge tone="red">important</Badge>}
                  <Badge tone={a.courseId ? "steel" : "gold"}>{a.courseId || "general"}</Badge>
                </div>
              </div>
              <p style={{ fontSize: 13.5, color: COLORS.steel, lineHeight: 1.55, margin: "0 0 10px" }}>{a.body}</p>
              {a.materialsUrl && (
                <a
                  href={a.materialsUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="focus-ring"
                  style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 600, color: COLORS.teal, textDecoration: "none", marginBottom: 10 }}
                >
                  <Paperclip size={12} /> {a.materialsLabel || "Attached material"}
                </a>
              )}
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 6 }}>
                <div className="ssas-mono" style={{ fontSize: 11, color: COLORS.steelLight }}>
                  {a.author} · {a.date}
                </div>
                <div style={{ display: "flex", gap: 6 }}>
                  <button
                    type="button"
                    onClick={() => startEdit(a)}
                    className="focus-ring"
                    style={{ background: "transparent", border: `1px solid ${COLORS.steelLight}`, borderRadius: 7, padding: "5px 9px", cursor: "pointer", color: COLORS.steel, display: "inline-flex", alignItems: "center", gap: 5, fontSize: 12 }}
                  >
                    <Pencil size={12} /> Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => onDeleteAnnouncement(a.id)}
                    className="focus-ring"
                    style={{ background: "transparent", border: "1px solid #E7B9B4", borderRadius: 7, padding: "5px 9px", cursor: "pointer", color: COLORS.red, display: "inline-flex", alignItems: "center", gap: 5, fontSize: 12 }}
                  >
                    <Trash2 size={12} /> Delete
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default TeacherNoticeboard;
