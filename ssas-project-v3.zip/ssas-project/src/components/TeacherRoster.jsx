import React, { useMemo } from "react";
import { Radio, Users } from "lucide-react";
import { COLORS } from "../constants/colors";
import { SCHEDULE } from "../constants/mockData";
import { Card, Btn, SectionHeader, Badge } from "./ui";

function TeacherRoster({ teacher, accounts, records, onOpenSession }) {
  const myCourses = useMemo(() => SCHEDULE.filter((s) => s.teacher === teacher.id), [teacher.id]);

  const pctFor = (studentId, courseId) => {
    const rows = records.filter((r) => r.studentId === studentId && r.courseId === courseId);
    if (!rows.length) return null;
    const score = rows.reduce((sum, r) => sum + (r.status === "present" ? 1 : r.status === "late" ? 0.5 : 0), 0);
    return Math.round((score / rows.length) * 100);
  };

  return (
    <div>
      <SectionHeader eyebrow="Process 1.0 · Manage Class Roster" title="My classes & roster" />
      {myCourses.length === 0 ? (
        <Card style={{ padding: 30, textAlign: "center", color: COLORS.steel }}>No classes assigned yet.</Card>
      ) : (
        <div style={{ display: "grid", gap: 20 }}>
          {myCourses.map((c) => {
            const roster = accounts.filter((a) => c.students.includes(a.id));
            return (
              <Card key={c.courseId} style={{ padding: 18 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 4, flexWrap: "wrap", gap: 10 }}>
                  <div>
                    <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{c.courseId} · {c.room}</div>
                    <div style={{ fontWeight: 700, fontSize: 16, color: COLORS.ink }}>{c.title}</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <Badge tone="steel">
                      <Users size={11} style={{ verticalAlign: -1, marginRight: 4 }} />
                      {roster.length} students
                    </Badge>
                    <Btn icon={Radio} onClick={() => onOpenSession(c)} style={{ fontSize: 12, padding: "6px 12px" }}>
                      Take attendance
                    </Btn>
                  </div>
                </div>
                <div className="ssas-mono" style={{ fontSize: 12, color: COLORS.steel, marginBottom: 12 }}>{c.time}</div>
                <div style={{ overflow: "hidden", borderRadius: 10, border: `1px solid ${COLORS.paper}` }}>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13.5 }}>
                    <thead>
                      <tr style={{ background: COLORS.paper, textAlign: "left" }}>
                        {["Student", "ID", "Attendance %"].map((h) => (
                          <th key={h} className="ssas-mono" style={{ padding: "8px 12px", fontSize: 11, color: COLORS.steel, textTransform: "uppercase" }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {roster.map((s) => {
                        const pct = pctFor(s.id, c.courseId);
                        return (
                          <tr key={s.id} style={{ borderTop: `1px solid ${COLORS.paper}` }}>
                            <td style={{ padding: "8px 12px", fontWeight: 600, color: COLORS.ink }}>{s.name}</td>
                            <td className="ssas-mono" style={{ padding: "8px 12px", color: COLORS.steel }}>{s.id}</td>
                            <td style={{ padding: "8px 12px" }}>
                              {pct === null ? (
                                <span className="ssas-mono" style={{ fontSize: 12, color: COLORS.steelLight }}>no data</span>
                              ) : (
                                <div style={{ display: "flex", alignItems: "center", gap: 8, maxWidth: 160 }}>
                                  <div style={{ flex: 1, height: 6, borderRadius: 4, background: COLORS.paper, overflow: "hidden" }}>
                                    <div style={{ width: `${pct}%`, height: "100%", background: pct < 70 ? COLORS.red : pct < 85 ? COLORS.gold : COLORS.teal }} />
                                  </div>
                                  <span className="ssas-mono" style={{ fontSize: 12, fontWeight: 700, color: COLORS.ink }}>{pct}%</span>
                                </div>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default TeacherRoster;
