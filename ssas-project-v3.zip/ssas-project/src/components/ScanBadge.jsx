import React, { useState, useRef, useEffect } from "react";
import { ScanFace, Fingerprint } from "lucide-react";
import { COLORS } from "../constants/colors";
import { Badge, Card, Btn } from "./ui";

function ScanBadge({ student, onResult }) {
  const [phase, setPhase] = useState("idle"); // idle | scanning | done
  const [score, setScore] = useState(0);
  const [result, setResult] = useState(null);
  const timerRef = useRef(null);

  const runScan = () => {
    setPhase("scanning");
    setScore(0);
    let s = 0;
    timerRef.current = setInterval(() => {
      s += Math.floor(Math.random() * 14) + 6;
      if (s >= 100) {
        s = Math.min(100, s);
        clearInterval(timerRef.current);
        const accepted = s > 55 ? Math.random() > 0.12 : false;
        const finalScore = accepted ? Math.max(88, s) : 41 + Math.floor(Math.random() * 15);
        setScore(finalScore);
        const outcome = accepted ? "present" : "denied";
        setResult(outcome);
        setPhase("done");
        onResult(student.id, outcome, finalScore);
        return;
      }
      setScore(s);
    }, 110);
  };

  useEffect(() => () => clearInterval(timerRef.current), []);

  return (
    <Card style={{ padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 14.5, color: COLORS.ink }}>{student.name}</div>
          <div className="ssas-mono" style={{ fontSize: 11.5, color: COLORS.steel }}>{student.id}</div>
        </div>
        {phase === "idle" && <Badge tone="steel">awaiting scan</Badge>}
        {phase === "scanning" && <Badge tone="gold">scanning…</Badge>}
        {phase === "done" && result === "present" && <Badge tone="teal">verified</Badge>}
        {phase === "done" && result === "denied" && <Badge tone="red">not matched</Badge>}
      </div>

      <div
        style={{
          position: "relative", height: 92, borderRadius: 10, overflow: "hidden",
          background: "linear-gradient(180deg, #12213B, #1B2E4D)",
          display: "flex", alignItems: "center", justifyContent: "center",
        }}
      >
        <ScanFace size={38} color={phase === "done" && result === "present" ? COLORS.teal : phase === "done" ? "#F2A79E" : "#C7CEDA"} />
        {phase === "scanning" && (
          <div className="scan-sweep" style={{ position: "absolute", left: 0, right: 0, height: 2, background: COLORS.gold, boxShadow: `0 0 12px ${COLORS.gold}` }} />
        )}
        {phase === "done" && (
          <div
            className="stamp-pop"
            style={{
              position: "absolute", top: 8, right: 10, border: `2px solid ${result === "present" ? COLORS.teal : COLORS.red}`,
              color: result === "present" ? COLORS.teal : COLORS.red, borderRadius: 6, padding: "2px 8px",
              fontSize: 10, fontWeight: 800, letterSpacing: 1, transform: "rotate(-8deg)",
            }}
          >
            {result === "present" ? "VERIFIED" : "DENIED"}
          </div>
        )}
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 10 }}>
        <span className="ssas-mono" style={{ fontSize: 12, color: COLORS.steel }}>
          match_score: <b style={{ color: COLORS.ink }}>{phase === "idle" ? "—" : `${score}%`}</b>
        </span>
        <Btn variant={phase === "idle" ? "primary" : "ghost"} onClick={runScan} disabled={phase === "scanning"} icon={Fingerprint} style={{ fontSize: 12, padding: "6px 12px" }}>
          {phase === "done" ? "Re-scan" : "Start scan"}
        </Btn>
      </div>
    </Card>
  );
}


export default ScanBadge;
