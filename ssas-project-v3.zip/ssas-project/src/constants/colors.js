export const COLORS = {
  ink: "#12213B",
  paper: "#EEF1F6",
  card: "#FFFFFF",
  gold: "#D9A441",
  goldDeep: "#B9860F",
  teal: "#1F8A83",
  red: "#C1443C",
  steel: "#5B6B84",
  steelLight: "#C7CEDA",
};
