// Mock data for the SSAS demo — in-memory only, no backend.

const ACCOUNTS = [
  { id: "S-20244103257", name: "Jubayed Ahmed", role: "student", dept: "CSE", status: "active" },
  { id: "S-20244103426", name: "Ahsan Habib", role: "student", dept: "CSE", status: "active" },
  { id: "S-20244103425", name: "Saifur Rahman", role: "student", dept: "CSE", status: "active" },
  { id: "S-20244103406", name: "Ashikur Rahman", role: "student", dept: "CSE", status: "active" },
  { id: "T-1042", name: "Rubaiya Reza Sohana", role: "teacher", dept: "CSE", status: "active" },
  { id: "A-0001", name: "System Admin", role: "admin", dept: "CSE", status: "active" },
];

const SCHEDULE = [
  { courseId: "CSE318", title: "System Analysis & Design Lab", teacher: "T-1042", room: "Lab-4B", time: "Mon 10:00–11:30", students: ["S-20244103257", "S-20244103426", "S-20244103425", "S-20244103406"] },
  { courseId: "CSE221", title: "Data Analysis & Design", teacher: "T-1042", room: "Room-212", time: "Wed 09:00–10:30", students: ["S-20244103257", "S-20244103426", "S-20244103425"] },
  { courseId: "CSE217", title: "Computer Networking", teacher: "T-1042", room: "Room-118", time: "Thu 14:00–15:30", students: ["S-20244103257", "S-20244103406"] },
];

const seedLog = () => {
  const days = ["07-01", "07-02", "07-03", "07-04", "07-06"];
  const rows = [];
  let n = 1;
  SCHEDULE.forEach((s) =>
    s.students.forEach((stu) =>
      days.forEach((d) => {
        const roll = Math.random();
        const status = roll > 0.82 ? "absent" : roll > 0.7 ? "late" : "present";
        rows.push({
          id: `SES-${String(n++).padStart(4, "0")}`,
          studentId: stu,
          courseId: s.courseId,
          date: `2026-${d}`,
          method: status === "absent" ? "—" : Math.random() > 0.5 ? "face" : "manual",
          status,
        });
      })
    )
  );
  return rows;
};


const ANNOUNCEMENTS = [
  {
    id: "AN-04",
    courseId: null,
    title: "Mid-term routine published",
    body: "The mid-term examination routine for all CSE sections has been published on the notice board and department portal. Seat plans will follow next week.",
    author: "System Admin",
    date: "2026-07-06",
    priority: "high",
    materialsLabel: "",
    materialsUrl: "",
  },
  {
    id: "AN-03",
    courseId: "CSE318",
    title: "Lab relocated to Lab-4B",
    body: "This week's System Analysis & Design lab session has moved from Lab-2A to Lab-4B due to a scheduling conflict. Same time slot.",
    author: "Rubaiya Reza Sohana",
    date: "2026-07-05",
    priority: "normal",
    materialsLabel: "",
    materialsUrl: "",
  },
  {
    id: "AN-02",
    courseId: "CSE221",
    title: "Assignment 2 deadline extended",
    body: "The submission deadline for Assignment 2 (ER diagram + normalization) has been extended by three days. Late submissions after that will lose 10% per day.",
    author: "Rubaiya Reza Sohana",
    date: "2026-07-03",
    priority: "normal",
    materialsLabel: "Assignment 2 spec (PDF)",
    materialsUrl: "https://example.edu/cse221/assignment2.pdf",
  },
  {
    id: "AN-01",
    courseId: "CSE217",
    title: "Bring your own laptop next class",
    body: "Next Networking class will run a hands-on Wireshark exercise. Please bring a charged laptop; a shared lab set will be available for anyone without one.",
    author: "Rubaiya Reza Sohana",
    date: "2026-07-01",
    priority: "normal",
    materialsLabel: "Wireshark setup guide",
    materialsUrl: "https://example.edu/cse217/wireshark-setup",
  },
];

export { ACCOUNTS, SCHEDULE, seedLog, ANNOUNCEMENTS };
