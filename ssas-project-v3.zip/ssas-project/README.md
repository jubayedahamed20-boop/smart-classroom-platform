# SSAS — Smart Student Attendance System (Demo)

A functional demo of the SSAS Level-1 DFD (processes 1.0–7.0): role-based
login, teacher-controlled class sessions, face-verify self check-in for
students, manual override, reports, threshold alerts, account management,
and an audit log.

## Project structure

```
ssas-project/
├── index.html                  Vite entry HTML
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx                React root, mounts <App />
    ├── App.jsx                 Top-level state + screen routing + sidebar nav
    ├── styles.css              Fonts, animations, global CSS
    ├── constants/
    │   ├── colors.js           Shared color tokens
    │   └── mockData.js         Mock accounts, class schedule, seed attendance log
    └── components/
        ├── ui.jsx              Shared UI atoms (Badge, Card, Btn, SectionHeader)
        ├── LoginScreen.jsx     Role select, ID login, face check-in gate
        ├── ScanBadge.jsx       The face-verify scan animation + result
        ├── CaptureAttendance.jsx  Teacher's live session + manual override
        ├── SessionPicker.jsx   Teacher's "choose a class to open" screen
        ├── ReportsView.jsx     Attendance % table
        ├── NotificationsView.jsx  Threshold alerts
        ├── AccountsView.jsx    Admin: accounts + config
        ├── AuditLogView.jsx    Admin: activity log
        ├── StudentView.jsx     Student overview: live session tracker + risk predictor
        ├── StudentSchedule.jsx Student's weekly timetable
        ├── AnnouncementsView.jsx  Student's course/general notice feed
        └── StudentProfile.jsx  Student's account/profile page
```

## Student dashboard

The student role has four sections in the sidebar:

- **Overview** — a live card that lights up when a teacher has an active
  session for one of the student's courses (shows a live clock and, once
  check-in is enabled, an inline face-verify scan without leaving the page);
  an attendance risk predictor per course that projects how many more
  classes must be attended to clear the minimum threshold, or how many can
  still be missed while staying above it; and a recent activity log.
- **Schedule** — weekly timetable grouped by day for the student's enrolled
  courses.
- **Announcements** — course-specific and general notices, newest first.
- **Profile** — account details, enrolled courses, and overall attendance.

## Running it

```bash
npm install
npm run dev
```

Then open the local URL Vite prints (usually `http://localhost:5173`).

To build a static, deployable version:

```bash
npm run build
```

This outputs a `dist/` folder you can host anywhere (Netlify, Vercel, GitHub
Pages, or just open `dist/index.html` directly for a quick look).

## Sample logins

Tap a role tile, then either tap a name to sign in instantly, or type the ID
(the role-letter prefix is optional — just the number works too):

| Role    | ID              | Name                  |
|---------|-----------------|-----------------------|
| Student | 20244103257     | Jubayed Ahmed         |
| Teacher | 1042            | Rubaiya Reza Sohana   |
| Admin   | 0001            | System Admin          |

## Notes

- All data is in-memory only — refreshing the page resets everything to the
  seed data. There's no backend or database; this is a frontend demo.
- To let students self-check-in via face verify at login, sign in as the
  teacher, open a class session, then tap **"Allow student check-in"** before
  signing out.
