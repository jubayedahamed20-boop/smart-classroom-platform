import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import basicSsl from '@vitejs/plugin-basic-ssl';
import { nodePolyfills } from 'vite-plugin-node-polyfills';

export default defineConfig({
  // BUGFIX ("blank white page" / console error "Uncaught ReferenceError:
  // global is not defined" thrown from node_modules/randombytes/browser.js,
  // required by simple-peer): simple-peer and its dependency chain
  // (randombytes, readable-stream, buffer) are written assuming Node.js
  // globals (`global`, `Buffer`, `process`) exist. They don't in a
  // browser. Because App.jsx isn't route-split, importing App pulls in
  // MeetingRoute -> webrtc.js -> simple-peer eagerly, so this crashed
  // during the very first module evaluation — before React ever rendered
  // anything, on every page, not just the meeting screen. nodePolyfills()
  // patches in browser-safe versions of those Node globals so simple-peer
  // loads normally again.
  plugins: [react(), basicSsl(), nodePolyfills({ globals: { Buffer: true, global: true, process: true } })],
  server: {
    port: 5173,
    // Without `host: true` Vite only binds to 127.0.0.1, so the dev
    // server is unreachable from any other device on the network at all,
    // even before the camera/HTTPS issue above comes into play.
    host: true,
    proxy: {
      '/api': 'http://localhost:4000',
      '/socket.io': { target: 'http://localhost:4000', ws: true },
    },
  },
});
