import { useNavigate } from 'react-router-dom';
import Button from '../shared/Button';

const FEATURES = [
  { title: 'Live face-verified attendance', desc: 'Periodic in-browser face checks confirm the right student is actually present.' },
  { title: 'Drowsiness detection', desc: 'Eye-aspect-ratio tracking flags students who have dozed off mid-class.' },
  { title: 'Separate dashboards', desc: 'Students see their own record. Teachers run classes and mark attendance. Admins see everything.' },
];

export default function WelcomePage() {
  const navigate = useNavigate();

  return (
    <section className="min-h-screen w-full flex flex-col bg-light-bg text-ink">
      <header className="w-full px-6 py-5 flex items-center justify-between max-w-5xl mx-auto">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue flex items-center justify-center text-white font-display font-bold">S</div>
          <span className="font-display font-bold text-lg text-ink">SSAS</span>
        </div>
        <div className="flex gap-2">
          <Button variant="ghost" onClick={() => navigate('/login')}>Log in</Button>
          <Button onClick={() => navigate('/register')}>Sign up</Button>
        </div>
      </header>

      <div className="flex-1 flex items-center">
        <div className="max-w-5xl mx-auto px-6 py-10 grid md:grid-cols-2 gap-10 items-center w-full">
          <div className="flex flex-col gap-4">
            <p className="text-blue text-[13px] font-semibold tracking-wide uppercase">CSE318 · System Analysis &amp; Design</p>
            <h1 className="font-display text-[34px] leading-tight font-bold text-ink">
              Smart Student Attendance System
            </h1>
            <p className="text-ink-soft text-[15px] leading-relaxed">
              A browser-based classroom that verifies who's actually in front of the camera —
              face ID registration, live drowsiness checks, and role-based dashboards for
              students, teachers, and admins.
            </p>
            <div className="flex gap-3 mt-2">
              <Button onClick={() => navigate('/register')}>Get started</Button>
              <Button variant="ghost" onClick={() => navigate('/login')}>I already have an account</Button>
            </div>
          </div>

          <div className="flex flex-col gap-3">
            {FEATURES.map((f) => (
              <div key={f.title} className="bg-white border border-light-line rounded-xl p-4 shadow-sm">
                <h3 className="font-display font-semibold text-[14px] mb-1 text-ink">{f.title}</h3>
                <p className="text-ink-soft text-[13px] leading-snug">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
