import { useEffect, useState } from 'react';
import useMeetingStore from '../../store/useMeetingStore';

function formatElapsed(joinedAt) {
  if (!joinedAt) return '00:00';
  const secs = Math.floor((Date.now() - new Date(joinedAt).getTime()) / 1000);
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

function formatCountdown(nextCheckAt) {
  if (!nextCheckAt) return '—';
  const secs = Math.max(0, Math.floor((nextCheckAt - Date.now()) / 1000));
  const m = String(Math.floor(secs / 60)).padStart(2, '0');
  const s = String(secs % 60).padStart(2, '0');
  return `${m}:${s}`;
}

export default function MeetingHeader({ courseTitle, section, joinedAt }) {
  const { nextCheckAt, checking } = useMeetingStore();
  const [, tick] = useState(0);

  useEffect(() => {
    const id = window.setInterval(() => tick((n) => n + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <header className="flex items-center justify-between px-5 py-3 bg-white border-b border-light-line shrink-0">
      <div>
        <h1 className="font-display font-bold text-[15px] text-ink">{courseTitle}</h1>
        <p className="text-ink-soft text-[12px]">{section}</p>
      </div>

      <div className="flex items-center gap-3">
        <span className="font-mono text-[12.5px] text-ink-soft bg-light-bg border border-light-line px-3 py-1.5 rounded-full">
          {formatElapsed(joinedAt)}
        </span>
        <span
          className={`font-mono text-[12.5px] px-3 py-1.5 rounded-full border flex items-center gap-1.5 ${
            checking
              ? 'bg-sky-bg text-sky-deep border-sky/40'
              : 'bg-light-bg text-ink-soft border-light-line'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${checking ? 'bg-sky animate-pulse' : 'bg-ink-soft/40'}`}
          />
          {checking ? 'verifying now…' : `next check in ${formatCountdown(nextCheckAt)}`}
        </span>
      </div>
    </header>
  );
}
