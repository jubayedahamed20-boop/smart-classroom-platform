import Avatar from '../shared/Avatar';
import StatusBadge from '../shared/StatusBadge';

export default function GridTile({ name, role, isYou, videoRef, stream, status = 'idle', micOn = true, camOn = true }) {
  const isTeacherTile = role === 'teacher';
  return (
    <div className="relative bg-dark-tile rounded-xl overflow-hidden border border-dark-line aspect-video flex items-center justify-center">
      {isYou ? (
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className={`w-full h-full object-cover -scale-x-100 ${camOn ? 'block' : 'hidden'}`}
        />
      ) : stream ? (
        <video
          autoPlay
          playsInline
          className="w-full h-full object-cover"
          ref={(el) => {
            if (el && el.srcObject !== stream) el.srcObject = stream;
          }}
        />
      ) : null}
      {(!isYou && !stream) || (isYou && !camOn) ? <Avatar name={name} size={56} /> : null}

      {/* Teachers aren't checked in/out (no drowsiness/attendance
          check-ins run for them — see MeetingRoute.jsx), so the
          present/drowsy/absent badge doesn't apply to their tile. */}
      {!isTeacherTile && (
        <div className="absolute top-2 left-2">
          <StatusBadge status={status} />
        </div>
      )}

      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
        <span className="text-white text-[12px] font-medium bg-black/40 px-2 py-0.5 rounded-md truncate max-w-[70%] flex items-center gap-1">
          <span className="truncate">{name} {isYou ? '(you)' : ''}</span>
          {role && (
            <span
              className={`shrink-0 text-[9.5px] font-semibold uppercase tracking-wide px-1.5 py-[1px] rounded ${
                isTeacherTile ? 'bg-amber/25 text-amber' : 'bg-white/20 text-white'
              }`}
            >
              {isTeacherTile ? 'Teacher' : 'Student'}
            </span>
          )}
        </span>
        {!micOn && (
          <span className="bg-black/40 text-white text-[11px] w-6 h-6 rounded-md flex items-center justify-center">
            🔇
          </span>
        )}
      </div>
    </div>
  );
}
