import Button from '../shared/Button';

export default function ControlBar({ micOn, camOn, onToggleMic, onToggleCam, onTogglePanel, onLeave }) {
  return (
    <footer className="flex items-center justify-center gap-3 px-5 py-3.5 bg-white border-t border-light-line shrink-0">
      <button
        onClick={onToggleMic}
        className={`w-11 h-11 rounded-full flex items-center justify-center text-lg transition ${
          micOn ? 'bg-light-bg text-ink hover:bg-sky-bg' : 'bg-danger text-white'
        }`}
        title={micOn ? 'Mute' : 'Unmute'}
      >
        {micOn ? '🎙️' : '🔇'}
      </button>
      <button
        onClick={onToggleCam}
        className={`w-11 h-11 rounded-full flex items-center justify-center text-lg transition ${
          camOn ? 'bg-light-bg text-ink hover:bg-sky-bg' : 'bg-danger text-white'
        }`}
        title={camOn ? 'Turn off camera' : 'Turn on camera'}
      >
        {camOn ? '🎥' : '📷'}
      </button>
      <button
        onClick={onTogglePanel}
        className="w-11 h-11 rounded-full bg-light-bg text-ink hover:bg-sky-bg flex items-center justify-center text-lg"
        title="Participants & checks"
      >
        👥
      </button>
      <Button variant="danger" onClick={onLeave} className="ml-2">
        Leave
      </Button>
    </footer>
  );
}
