import { useEffect, useRef, useState } from 'react';
import useChatStore from '../../store/useChatStore';
import { getSocket } from '../../services/socket';

function formatTime(iso) {
  return new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Zoom-style in-meeting chat: header + recipient picker, a scrollable
// message log, and a send bar. Lives as a tab inside SidePanel so it
// reuses the same open/close (incl. the mobile full-screen overlay) and
// roster data the rest of the panel already has — see SidePanel.jsx.
export default function ChatPanel({ selfName, roster, sessionId }) {
  const { messages, recipient, setRecipient } = useChatStore();
  const [draft, setDraft] = useState('');
  const listRef = useRef(null);

  // Keep the log pinned to the latest message, like every chat UI does.
  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  const send = () => {
    const body = draft.trim();
    if (!body || !sessionId) return;

    const entry = {
      id: `local-${Date.now()}`,
      from: selfName,
      to: recipient,
      body,
      createdAt: new Date().toISOString(),
      self: true,
    };
    // Optimistic local append (same pattern the app already uses for
    // attendance checks) — the server relays it to whoever else should
    // see it but never echoes it back to the sender.
    useChatStore.getState().addMessage(entry);
    getSocket().emit('chat:message', { sessionId, to: recipient, body });
    setDraft('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  return (
    <div className="flex-1 flex flex-col min-h-0">
      {/* Header */}
      <div className="px-3 py-2.5 border-b border-light-line">
        <p className="text-[13px] font-semibold text-ink">In-meeting chat</p>
        <p className="text-[11px] text-ink-soft">Messages aren't saved after the class ends</p>
      </div>

      {/* Scrollable message area */}
      <div ref={listRef} className="flex-1 overflow-y-auto px-3 py-2.5 flex flex-col gap-2.5">
        {messages.length === 0 && (
          <p className="text-ink-soft text-[12.5px] text-center py-6">
            No messages yet — say hi 👋
          </p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`flex flex-col ${m.self ? 'items-end' : 'items-start'}`}>
            <div className="flex items-center gap-1.5 px-0.5">
              <span className="text-[11.5px] font-semibold text-ink">
                {m.self ? 'You' : m.from}
              </span>
              {m.to !== 'everyone' && (
                <span className="text-[10.5px] text-sky-deep bg-sky-bg px-1.5 py-0.5 rounded-full">
                  {m.self ? `to ${m.to}` : 'to you privately'}
                </span>
              )}
              <span className="text-[10.5px] text-ink-soft">{formatTime(m.createdAt)}</span>
            </div>
            <p
              className={`mt-0.5 max-w-[85%] rounded-xl px-3 py-1.5 text-[13px] leading-snug break-words ${
                m.self ? 'bg-sky text-white' : 'bg-light-bg text-ink'
              }`}
            >
              {m.body}
            </p>
          </div>
        ))}
      </div>

      {/* Recipient dropdown + input + send */}
      <div className="border-t border-light-line p-2.5 flex flex-col gap-2">
        <div className="flex items-center gap-1.5">
          <label className="text-[11px] text-ink-soft shrink-0">To:</label>
          <select
            value={recipient}
            onChange={(e) => setRecipient(e.target.value)}
            className="flex-1 text-[12.5px] bg-light-bg border border-light-line rounded-md px-2 py-1 text-ink focus:outline-none focus:ring-2 focus:ring-sky/40"
          >
            <option value="everyone">Everyone</option>
            {roster
              .filter((r) => r.name !== selfName)
              .map((r) => (
                <option key={r.id} value={r.name}>
                  {r.name} (privately)
                </option>
              ))}
          </select>
        </div>

        <div className="flex items-end gap-2">
          <textarea
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={recipient === 'everyone' ? 'Message everyone…' : `Message ${recipient} privately…`}
            rows={1}
            className="flex-1 resize-none text-[13px] bg-light-bg border border-light-line rounded-lg px-3 py-2 text-ink placeholder:text-ink-soft focus:outline-none focus:ring-2 focus:ring-sky/40 max-h-24"
          />
          <button
            onClick={send}
            disabled={!draft.trim()}
            className="w-9 h-9 shrink-0 rounded-full bg-sky text-white flex items-center justify-center text-[15px] disabled:opacity-40 disabled:cursor-not-allowed hover:bg-sky-deep transition"
            title="Send"
            aria-label="Send message"
          >
            ➤
          </button>
        </div>
      </div>
    </div>
  );
}
