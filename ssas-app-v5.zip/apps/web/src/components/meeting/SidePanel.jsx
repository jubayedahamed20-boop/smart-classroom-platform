import useMeetingStore from '../../store/useMeetingStore';
import useChatStore from '../../store/useChatStore';
import Avatar from '../shared/Avatar';
import StatusBadge from '../shared/StatusBadge';
import ChatPanel from './ChatPanel';

const TABS = [
  { id: 'roster', label: 'Roster' },
  { id: 'checks', label: 'Checks' },
  { id: 'chat', label: 'Chat' },
];

export default function SidePanel({ isTeacher, onOverride, onClose, selfName, sessionId }) {
  const { panelTab, setPanelTab, roster, tiles, checkLog } = useMeetingStore();
  const unread = useChatStore((s) => s.unread);

  const openTab = (id) => {
    setPanelTab(id);
    if (id === 'chat') useChatStore.getState().clearUnread();
  };

  return (
    // BUGFIX ("reshape" on mobile): was a fixed w-[300px] sitting in the
    // same flex row as the tile grid, so on phone-width screens it left
    // almost no space for the grid and squashed every tile. Below the
    // `sm` breakpoint this now renders as a full-width overlay on top of
    // the grid (with a Close button) instead of squeezing it; at `sm`+ it
    // goes back to the original 300px side-by-side panel.
    <aside
      className="absolute inset-0 z-20 bg-white flex flex-col
                 sm:static sm:inset-auto sm:z-auto sm:w-[300px] sm:shrink-0 sm:border-l sm:border-light-line"
    >
      <div className="flex items-center justify-between border-b border-light-line sm:hidden px-3 py-2">
        <span className="text-[13px] font-semibold text-ink">Participants</span>
        <button onClick={onClose} className="text-ink-soft text-[13px] font-medium px-2 py-1">
          Close ✕
        </button>
      </div>
      <div className="flex border-b border-light-line">
        {TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => openTab(t.id)}
            className={`relative flex-1 py-3 text-[13px] font-semibold transition ${
              panelTab === t.id
                ? 'text-sky-deep border-b-2 border-sky bg-sky-bg'
                : 'text-ink-soft'
            }`}
          >
            {t.label}
            {t.id === 'chat' && unread > 0 && panelTab !== 'chat' && (
              <span className="absolute top-1.5 right-3 min-w-[16px] h-4 px-1 rounded-full bg-danger text-white text-[10px] leading-4 font-bold">
                {unread}
              </span>
            )}
          </button>
        ))}
      </div>

      {panelTab === 'chat' ? (
        <ChatPanel selfName={selfName} roster={roster} sessionId={sessionId} />
      ) : (
        <div className="flex-1 overflow-y-auto p-3">
          {panelTab === 'roster' && (
            <ul className="flex flex-col gap-1.5">
              {roster.map((r) => {
                const tile = tiles[r.name] || { status: 'idle', flags: 0 };
                return (
                  <li
                    key={r.id}
                    className="flex items-center gap-2.5 p-2 rounded-lg hover:bg-light-bg"
                  >
                    <Avatar name={r.name} size={32} />
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-medium text-ink truncate">{r.name}</p>
                      <p className="text-[11px] text-ink-soft">{tile.flags} flag{tile.flags === 1 ? '' : 's'}</p>
                    </div>
                    <StatusBadge status={tile.status} />
                    {isTeacher && (
                      <button
                        onClick={() => onOverride?.(r.name, tile.status)}
                        className="text-[11px] text-sky-deep font-semibold ml-1"
                      >
                        Override
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}

          {panelTab === 'checks' && (
            <ul className="flex flex-col gap-1.5">
              {[...checkLog].reverse().map((c, i) => (
                <li key={i} className="p-2 rounded-lg bg-light-bg text-[12px]">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-ink">{c.name}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  <p className="text-ink-soft text-[11px] mt-0.5">
                    {new Date(c.checkedAt).toLocaleTimeString()}
                    {typeof c.earValue === 'number' ? ` · EAR ${c.earValue.toFixed(2)}` : ''}
                  </p>
                </li>
              ))}
              {checkLog.length === 0 && (
                <p className="text-ink-soft text-[12.5px] text-center py-6">No checks yet.</p>
              )}
            </ul>
          )}
        </div>
      )}
    </aside>
  );
}
