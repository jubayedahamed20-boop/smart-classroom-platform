import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { listSessions, getChecks } from '../../services/api';
import { connectSocket } from '../../services/socket';
import { computeCourseRisk } from '../../services/riskEngine';
import Button from '../shared/Button';
import RiskBanner from './RiskBanner';
import ToastStack from '../shared/ToastStack';

const SESSION_BADGE = {
  SCHEDULED: 'bg-sky/15 text-sky-deep',
  LIVE: 'bg-teal/15 text-teal',
  ENDED: 'bg-dark-sub/15 text-ink-soft',
};

// BUGFIX (student dashboard shows no notification / no way to join):
// this only matched a roster line if the student's name was character-
// for-character identical (after trim+lowercase) to what the teacher
// typed into AddClassForm's free-text roster box, or if both sides had a
// studentId set and those matched exactly. A single extra space, a typo,
// or a name typed slightly differently made a class invisible on this
// dashboard — no live card, no "class is live" toast, nothing — with no
// indication to the student why. Collapsing repeated internal whitespace
// (not just trimming the ends) catches the most common case of that.
function normalizeName(name) {
  return (name || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function onRoster(session, user) {
  const list = session.roster || [];
  return list.some((r) => {
    if (user.studentId && r.studentId) return r.studentId === user.studentId;
    return normalizeName(r.name) === normalizeName(user.name);
  });
}

// Real-time attendance tracking: polls for session status/roster changes
// and additionally listens on the socket for instant 'session:status'
// pushes (teacher starts/ends class) so the "Live now" card and this
// student's own check history update without a manual refresh.
const POLL_MS = 15000;

export default function OverviewTab({ user }) {
  const navigate = useNavigate();
  const [sessions, setSessions] = useState([]);
  const [otherLive, setOtherLive] = useState([]);
  const [checksBySession, setChecksBySession] = useState({});
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState([]);

  // Tracks each roster session's last-seen status so we can detect the
  // SCHEDULED -> LIVE transition and fire a toast exactly once, instead of
  // re-notifying on every poll/socket tick while it stays LIVE. Starts
  // empty so the very first load (dashboard just opened) never toasts for
  // a class that was already live before the student arrived.
  const knownStatus = useRef(new Map());
  const hasLoadedOnce = useRef(false);

  function notifyNewlyLive(newlyLiveSessions) {
    if (newlyLiveSessions.length === 0) return;
    setToasts((prev) => [
      ...prev,
      ...newlyLiveSessions.map((s) => ({
        id: `${s.id}-${Date.now()}`,
        title: `${s.courseTitle} is live`,
        body: `${s.teacherName || 'Your teacher'} just started class — join now to be checked in.`,
        actionLabel: 'Join class',
        onAction: () => navigate(`/class/${s.id}/lobby`),
      })),
    ]);

    // Also fire a browser notification when the tab isn't focused, so a
    // student who's switched away still finds out. Silently no-ops if the
    // browser doesn't support it or permission hasn't been granted —
    // never blocks or throws.
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted' && document.hidden) {
      newlyLiveSessions.forEach((s) => {
        try {
          new Notification(`${s.courseTitle} is live`, {
            body: `${s.teacherName || 'Your teacher'} just started class.`,
          });
        } catch {
          /* unsupported in this context — toast above already covers it */
        }
      });
    }
  }

  async function load() {
    const all = await listSessions();
    const mine = all.filter((s) => onRoster(s, user));
    setSessions(mine);

    if (hasLoadedOnce.current) {
      const newlyLive = mine.filter((s) => s.status === 'LIVE' && knownStatus.current.get(s.id) !== 'LIVE');
      notifyNewlyLive(newlyLive);
    }
    mine.forEach((s) => knownStatus.current.set(s.id, s.status));
    hasLoadedOnce.current = true;

    // BUGFIX: if a class doesn't show up above under "Live now", there
    // was previously no way to find it at all — POST /:id/join on the
    // backend has no roster check (see sessions.routes.js), so a roster
    // typo/mismatch was a purely front-end dead end with zero visibility
    // or recourse for the student. GET /sessions already returns every
    // session to any signed-in user with no per-role filtering (see that
    // route's own comment), so showing the ones this student isn't
    // matched to — clearly labeled, so it's obvious why they're separate
    // — isn't exposing anything new; it's surfacing what was already
    // fetched and silently thrown away.
    const notMineLive = all.filter((s) => s.status === 'LIVE' && !onRoster(s, user));
    setOtherLive(notMineLive);

    const entries = await Promise.all(
      mine.map((s) => getChecks(s.id).catch(() => []).then((checks) => [s.id, checks]))
    );
    setChecksBySession(Object.fromEntries(entries));
  }

  // Ask once, quietly, so a student who wants the "switched to another
  // tab" notification above can get it. Ignored entirely if the browser
  // doesn't support the API or the person dismisses/blocks the prompt —
  // in-app toasts still work either way.
  useEffect(() => {
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  useEffect(() => {
    load().finally(() => setLoading(false));
    const interval = setInterval(load, POLL_MS);

    const socket = connectSocket();
    const onStatus = () => load();
    const onUpdate = () => load();
    socket.on('session:status', onStatus);
    socket.on('attendance:update', onUpdate);

    return () => {
      clearInterval(interval);
      socket.off('session:status', onStatus);
      socket.off('attendance:update', onUpdate);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const myChecksBySession = useMemo(() => {
    const out = {};
    for (const [sid, checks] of Object.entries(checksBySession)) {
      out[sid] = checks.filter((c) => (c.name || '').trim().toLowerCase() === (user.name || '').trim().toLowerCase());
    }
    return out;
  }, [checksBySession, user]);

  const myChecksAll = useMemo(() => Object.values(myChecksBySession).flat(), [myChecksBySession]);
  const presentCount = myChecksAll.filter((c) => c.status === 'present' || c.status === 'woke').length;
  const overallPct = myChecksAll.length ? Math.round((presentCount / myChecksAll.length) * 100) : null;

  // Per-course risk: group this student's checks (across all sessions of
  // that course) into present/total, then run the risk predictor on each.
  const courseRisks = useMemo(() => {
    const byCourse = {};
    for (const s of sessions) {
      const checks = myChecksBySession[s.id] || [];
      if (!checks.length) continue;
      const bucket = byCourse[s.courseTitle] || { present: 0, total: 0 };
      bucket.present += checks.filter((c) => c.status === 'present' || c.status === 'woke').length;
      bucket.total += checks.length;
      byCourse[s.courseTitle] = bucket;
    }
    return Object.entries(byCourse).map(([courseTitle, stats]) => ({
      courseTitle,
      risk: computeCourseRisk(stats),
    }));
  }, [sessions, myChecksBySession]);

  const live = sessions.filter((s) => s.status === 'LIVE');
  const upcoming = sessions.filter((s) => s.status === 'SCHEDULED');
  const ended = sessions.filter((s) => s.status === 'ENDED');

  return (
    <div className="flex flex-col gap-5">
      <ToastStack toasts={toasts} onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))} />
      {overallPct !== null && (
        <div className="bg-white border border-light-line rounded-2xl p-5 flex items-center justify-between">
          <div>
            <h2 className="font-display font-semibold text-ink text-[14px]">Overall attendance</h2>
            <p className="text-ink-soft text-[12.5px] mt-0.5">Across {myChecksAll.length} recorded check{myChecksAll.length === 1 ? '' : 's'}</p>
          </div>
          <div className="text-2xl font-display font-bold text-sky-deep">{overallPct}%</div>
        </div>
      )}

      {courseRisks.length > 0 && (
        <div>
          <h2 className="font-display font-semibold text-ink mb-2.5 text-[14px]">Attendance risk predictor</h2>
          <RiskBanner courseRisks={courseRisks} />
        </div>
      )}

      {live.length > 0 && (
        <div className="bg-white border border-teal/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-2 h-2 rounded-full bg-teal animate-pulse" />
            <h2 className="font-display font-semibold text-ink">Live now</h2>
          </div>
          <ul className="flex flex-col gap-2">
            {live.map((s) => (
              <li key={s.id} className="flex items-center justify-between bg-teal/5 rounded-lg p-3">
                <div>
                  <p className="text-ink text-[13.5px] font-medium">{s.courseTitle}</p>
                  <p className="text-ink-soft text-[12px]">{s.section} · {s.teacherName || 'Teacher'}</p>
                </div>
                <Button onClick={() => navigate(`/class/${s.id}/lobby`)}>Join class</Button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {otherLive.length > 0 && (
        <div className="bg-white border border-amber/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2 h-2 rounded-full bg-amber" />
            <h2 className="font-display font-semibold text-ink">Other live classes</h2>
          </div>
          <p className="text-ink-soft text-[12px] mb-3">
            These are live right now but your name isn't on the roster yet — you can still join,
            and ask your teacher to check the spelling matches your account name exactly.
          </p>
          <ul className="flex flex-col gap-2">
            {otherLive.map((s) => (
              <li key={s.id} className="flex items-center justify-between bg-amber/5 rounded-lg p-3">
                <div>
                  <p className="text-ink text-[13.5px] font-medium">{s.courseTitle}</p>
                  <p className="text-ink-soft text-[12px]">{s.section} · {s.teacherName || 'Teacher'}</p>
                </div>
                <Button variant="ghost" onClick={() => navigate(`/class/${s.id}/lobby`)}>Join anyway</Button>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="bg-white border border-light-line rounded-2xl p-5">
        <h2 className="font-display font-semibold text-ink mb-3">My classes</h2>
        {loading && <p className="text-ink-soft text-[13px]">Loading…</p>}
        {!loading && sessions.length === 0 && (
          <p className="text-ink-soft text-[13px]">
            No classes yet — you'll show up here once a teacher adds you to a class roster.
          </p>
        )}
        <ul className="flex flex-col gap-2">
          {[...upcoming, ...ended].map((s) => {
            const checks = myChecksBySession[s.id] || [];
            const present = checks.filter((c) => c.status === 'present' || c.status === 'woke').length;
            const pct = checks.length ? Math.round((present / checks.length) * 100) : null;
            return (
              <li key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-light-bg">
                <div>
                  <p className="text-ink text-[13.5px] font-medium">{s.courseTitle}</p>
                  <p className="text-ink-soft text-[12px]">
                    {s.section} · {new Date(s.scheduledStart).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  {pct !== null && <span className="text-ink-soft text-[12px]">{pct}% attended</span>}
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${SESSION_BADGE[s.status]}`}>
                    {s.status === 'SCHEDULED' ? 'Upcoming' : 'Ended'}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
