import { RISK_COPY } from '../../services/riskEngine';
import { MIN_ATTENDANCE_PCT } from '../../services/constants';

const TONE_STYLES = {
  teal: 'bg-teal/8 border-teal/25 text-teal',
  amber: 'bg-amber/8 border-amber/30 text-amber',
  danger: 'bg-danger/8 border-danger/30 text-danger',
};

// One row per at-risk-or-worse course, plus a compact "all clear" state
// when nothing needs attention. Deliberately silent about courses that
// are simply 'safe' or 'watch' here — those show inline on the course
// list instead, so this banner stays reserved for things worth acting on.
export default function RiskBanner({ courseRisks }) {
  const flagged = courseRisks.filter((c) => c.risk.level === 'at-risk' || c.risk.level === 'critical');

  if (flagged.length === 0) {
    return (
      <div className="flex items-center gap-2.5 bg-teal/8 border border-teal/25 rounded-2xl p-4">
        <span className="text-teal text-lg leading-none">✓</span>
        <p className="text-[13px] text-ink">
          No attendance risk right now — every course is at or above the {MIN_ATTENDANCE_PCT}% requirement.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2.5">
      {flagged.map(({ courseTitle, risk }) => {
        const copy = RISK_COPY[risk.level];
        return (
          <div
            key={courseTitle}
            className={`flex items-start gap-3 rounded-2xl border p-4 ${TONE_STYLES[copy.tone]}`}
          >
            <span className="text-lg leading-none mt-0.5">⚠</span>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="font-display font-semibold text-ink text-[13.5px]">{courseTitle}</p>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-white/70">
                  {risk.pct}%
                </span>
              </div>
              <p className="text-ink-soft text-[12.5px] mt-1">{copy.message(courseTitle, risk)}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
