import { useEffect, useState } from 'react';
import { listAnnouncements } from '../../services/api';
import { getSocket, connectSocket } from '../../services/socket';

function timeAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diffMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

export default function AnnouncementsTab() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listAnnouncements()
      .then(setItems)
      .finally(() => setLoading(false));

    // Live updates: a teacher/admin posting while this tab is open pushes
    // straight into the list instead of waiting for the next reload.
    const socket = connectSocket();
    const onNew = (a) => setItems((prev) => [a, ...prev]);
    socket.on('announcement:new', onNew);
    return () => socket.off('announcement:new', onNew);
  }, []);

  if (loading) return <p className="text-ink-soft text-[13px] px-1">Loading announcements…</p>;

  if (items.length === 0) {
    return (
      <div className="bg-white border border-light-line rounded-2xl p-6 text-center">
        <p className="text-ink-soft text-[13px]">No announcements yet.</p>
      </div>
    );
  }

  return (
    <ul className="flex flex-col gap-3">
      {items.map((a) => (
        <li
          key={a.id}
          className={`bg-white border rounded-2xl p-4 ${a.priority === 'high' ? 'border-danger/30' : 'border-light-line'}`}
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                {a.priority === 'high' && (
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-danger/15 text-danger">
                    IMPORTANT
                  </span>
                )}
                <h3 className="font-display font-semibold text-ink text-[13.5px]">{a.title}</h3>
              </div>
              <p className="text-ink-soft text-[11.5px] mt-0.5">
                {a.authorName || 'System'}
                {a.courseTitle ? ` · ${a.courseTitle}` : ' · Campus-wide'}
              </p>
            </div>
            <span className="text-ink-soft text-[11px] whitespace-nowrap">{timeAgo(a.createdAt)}</span>
          </div>
          <p className="text-ink text-[13px] mt-2.5 leading-relaxed">{a.body}</p>
        </li>
      ))}
    </ul>
  );
}
