import { useState } from 'react';
import useAuthStore from '../../store/useAuthStore';
import AppHeader from '../shared/AppHeader';
import OverviewTab from './OverviewTab';
import ScheduleTab from './ScheduleTab';
import AnnouncementsTab from './AnnouncementsTab';
import ProfileTab from './ProfileTab';

const TABS = [
  { id: 'overview', label: 'Overview' },
  { id: 'schedule', label: 'Schedule' },
  { id: 'announcements', label: 'Announcements' },
  { id: 'profile', label: 'Profile' },
];

export default function StudentDashboard() {
  const { user } = useAuthStore();
  const [tab, setTab] = useState('overview');

  return (
    <section className="min-h-screen bg-light-bg">
      <AppHeader subtitle="Student dashboard" />
      <div className="max-w-4xl mx-auto p-6 flex flex-col gap-5">
        <nav className="flex gap-1 bg-white border border-light-line rounded-xl p-1 w-fit">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition ${
                tab === t.id ? 'bg-blue text-white' : 'text-ink-soft hover:text-ink'
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {tab === 'overview' && <OverviewTab user={user} />}
        {tab === 'schedule' && <ScheduleTab user={user} />}
        {tab === 'announcements' && <AnnouncementsTab />}
        {tab === 'profile' && <ProfileTab />}
      </div>
    </section>
  );
}
