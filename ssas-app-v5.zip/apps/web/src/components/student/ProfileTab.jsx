import { useEffect, useState } from 'react';
import useAuthStore from '../../store/useAuthStore';
import { updateProfile, changePassword, getFaceProfile } from '../../services/api';
import Avatar from '../shared/Avatar';
import Button from '../shared/Button';

function Field({ label, children }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-ink-soft text-[11.5px] font-semibold uppercase tracking-wide">{label}</span>
      {children}
    </label>
  );
}

const inputCls =
  'bg-light-bg border border-light-line rounded-lg px-3 py-2 text-[13.5px] text-ink outline-none focus:border-blue transition';

export default function ProfileTab() {
  const { user, hydrate } = useAuthStore();
  const [form, setForm] = useState({ name: user.name, phone: user.phone || '', department: user.department || '', bio: user.bio || '' });
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');

  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [pwSaving, setPwSaving] = useState(false);
  const [pwMsg, setPwMsg] = useState('');

  const [faceProfile, setFaceProfile] = useState(null);

  useEffect(() => {
    getFaceProfile().then(setFaceProfile).catch(() => setFaceProfile(null));
  }, []);

  async function saveProfile(e) {
    e.preventDefault();
    setSaving(true);
    setSavedMsg('');
    try {
      await updateProfile(form);
      await hydrate();
      setSavedMsg('Saved.');
    } catch {
      setSavedMsg('Could not save — try again.');
    } finally {
      setSaving(false);
    }
  }

  async function savePassword(e) {
    e.preventDefault();
    setPwMsg('');
    if (pw.newPassword !== pw.confirm) {
      setPwMsg('New passwords do not match.');
      return;
    }
    setPwSaving(true);
    try {
      await changePassword({ currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
      setPwMsg('Password updated.');
    } catch (err) {
      setPwMsg(err?.response?.data?.error || 'Could not update password.');
    } finally {
      setPwSaving(false);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="bg-white border border-light-line rounded-2xl p-5 flex items-center gap-4">
        <Avatar name={user.name} size={56} />
        <div>
          <h2 className="font-display text-lg font-bold text-ink">{user.name}</h2>
          <p className="text-ink-soft text-[13px]">
            {user.studentId ? `ID ${user.studentId} · ` : ''}
            {user.email}
          </p>
        </div>
      </div>

      <form onSubmit={saveProfile} className="bg-white border border-light-line rounded-2xl p-5 flex flex-col gap-4">
        <h3 className="font-display font-semibold text-ink text-[14px]">Profile details</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Full name">
            <input className={inputCls} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </Field>
          <Field label="Phone">
            <input className={inputCls} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="Optional" />
          </Field>
          <Field label="Department">
            <input className={inputCls} value={form.department} onChange={(e) => setForm({ ...form, department: e.target.value })} placeholder="e.g. CSE" />
          </Field>
        </div>
        <Field label="Bio">
          <textarea
            className={`${inputCls} resize-none`}
            rows={3}
            maxLength={280}
            value={form.bio}
            onChange={(e) => setForm({ ...form, bio: e.target.value })}
          />
        </Field>
        <div className="flex items-center gap-3">
          <Button type="submit" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</Button>
          {savedMsg && <span className="text-[12.5px] text-ink-soft">{savedMsg}</span>}
        </div>
      </form>

      <form onSubmit={savePassword} className="bg-white border border-light-line rounded-2xl p-5 flex flex-col gap-4">
        <h3 className="font-display font-semibold text-ink text-[14px]">Change password</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Field label="Current password">
            <input type="password" className={inputCls} value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
          </Field>
          <Field label="New password">
            <input type="password" className={inputCls} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
          </Field>
          <Field label="Confirm new password">
            <input type="password" className={inputCls} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          </Field>
        </div>
        <div className="flex items-center gap-3">
          <Button type="submit" variant="ghost" disabled={pwSaving}>{pwSaving ? 'Updating…' : 'Update password'}</Button>
          {pwMsg && <span className="text-[12.5px] text-ink-soft">{pwMsg}</span>}
        </div>
      </form>

      <div className="bg-white border border-light-line rounded-2xl p-5 flex items-center justify-between">
        <div>
          <h3 className="font-display font-semibold text-ink text-[14px]">Face-ID profile</h3>
          <p className="text-ink-soft text-[12.5px] mt-1">
            {faceProfile
              ? `Set up · ${faceProfile.sampleCount || 0} sample${faceProfile.sampleCount === 1 ? '' : 's'} captured`
              : 'Not set up yet — required for automatic attendance checks.'}
          </p>
        </div>
        <span className={`px-2.5 py-1 rounded-full text-[11px] font-semibold ${faceProfile ? 'bg-teal/15 text-teal' : 'bg-amber/15 text-amber'}`}>
          {faceProfile ? 'Ready' : 'Pending setup'}
        </span>
      </div>
    </div>
  );
}
