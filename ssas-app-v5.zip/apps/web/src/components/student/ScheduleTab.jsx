import { useEffect, useMemo, useState } from 'react';
import { listSchedule } from '../../services/api';
import { DAY_NAMES, DAY_SHORT } from '../../services/constants';

function onRoster(slot, user) {
  return (slot.roster || []).some((r) => {
    if (user.studentId && r.studentId) return r.studentId === user.studentId;
    return (r.name || '').trim().toLowerCase() === (user.name || '').trim().toLowerCase();
  });
}

function minutesOf(hhmm) {
  const [h, m] = hhmm.split(':').map(Number);
  return h * 60 + m;
}

export default function ScheduleTab({ user }) {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    listSchedule()
      .then((all) => setSlots(all.filter((s) => onRoster(s, user))))
      .finally(() => setLoading(false));
  }, [user]);

  const today = new Date().getDay();
  const now = new Date();
  const nowMinutes = now.getHours() * 60 + now.getMinutes();

  const byDay = useMemo(() => {
    const map = Array.from({ length: 7 }, () => []);
    slots.forEach((s) => map[s.dayOfWeek].push(s));
    map.forEach((list) => list.sort((a, b) => minutesOf(a.startTime) - minutesOf(b.startTime)));
    return map;
  }, [slots]);

  const nextClass = useMemo(() => {
    for (let offset = 0; offset < 7; offset++) {
      const day = (today + offset) % 7;
      const candidates = byDay[day].filter((s) => offset > 0 || minutesOf(s.startTime) > nowMinutes);
      if (candidates.length) return { day, offset, slot: candidates[0] };
    }
    return null;
  }, [byDay, today, nowMinutes]);

  if (loading) return <p className="text-ink-soft text-[13px] px-1">Loading schedule…</p>;

  if (slots.length === 0) {
    return (
      <div className="bg-white border border-light-line rounded-2xl p-6 text-center">
        <p className="text-ink-soft text-[13px]">
          No weekly classes on your timetable yet — they'll appear once a teacher adds you to a course schedule.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      {nextClass && (
        <div className="bg-blue/8 border border-blue/25 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <p className="text-[11px] font-semibold text-blue uppercase tracking-wide">
              {nextClass.offset === 0 ? 'Next up today' : `Next class · ${DAY_NAMES[nextClass.day]}`}
            </p>
            <p className="font-display font-semibold text-ink text-[14px] mt-0.5">
              {nextClass.slot.courseTitle}
            </p>
          </div>
          <div className="text-right">
            <p className="text-ink font-semibold text-[13.5px]">
              {nextClass.slot.startTime}–{nextClass.slot.endTime}
            </p>
            {nextClass.slot.room && <p className="text-ink-soft text-[11.5px]">{nextClass.slot.room}</p>}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {DAY_SHORT.map((label, day) =>
          byDay[day].length === 0 ? null : (
            <div
              key={day}
              className={`bg-white border rounded-2xl p-4 ${day === today ? 'border-blue/40' : 'border-light-line'}`}
            >
              <h3 className={`font-display font-semibold text-[12.5px] mb-2.5 ${day === today ? 'text-blue' : 'text-ink'}`}>
                {DAY_NAMES[day]} {day === today && <span className="text-[10.5px] font-semibold ml-1">· Today</span>}
              </h3>
              <ul className="flex flex-col gap-2">
                {byDay[day].map((s) => (
                  <li key={s.id} className="bg-light-bg rounded-lg p-2.5">
                    <p className="text-ink text-[13px] font-medium">{s.courseTitle}</p>
                    <p className="text-ink-soft text-[11.5px] mt-0.5">
                      {s.startTime}–{s.endTime}
                      {s.room ? ` · ${s.room}` : ''}
                    </p>
                    {s.teacherName && <p className="text-ink-soft text-[11px]">{s.teacherName}</p>}
                  </li>
                ))}
              </ul>
            </div>
          )
        )}
      </div>
    </div>
  );
}
