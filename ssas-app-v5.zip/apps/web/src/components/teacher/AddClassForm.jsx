import { useState } from 'react';
import { createSession } from '../../services/api';
import Button from '../shared/Button';

// crypto.randomUUID() is available in all modern browsers — no need to
// pull in the uuid package (that's a server-only dependency here).
const genId = () =>
  crypto.randomUUID ? crypto.randomUUID() : `r-${Date.now()}-${Math.random().toString(36).slice(2)}`;

function parseRoster(text) {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [name, studentId] = line.split(',').map((p) => p.trim());
      return { id: genId(), name, studentId: studentId || undefined };
    });
}

function defaultDateTimeLocal() {
  const d = new Date(Date.now() + 60 * 60 * 1000); // an hour from now
  d.setSeconds(0, 0);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export default function AddClassForm({ onCreated, onCancel }) {
  const [form, setForm] = useState({
    courseId: 'CSE318',
    courseTitle: 'CSE318 · System Analysis & Design',
    section: 'Section 7 · Online',
    scheduledStart: defaultDateTimeLocal(),
    checkIntervalMin: 5,
    checkDurationSec: 15,
    rosterText: '',
  });
  const [error, setError] = useState(null);
  const [saving, setSaving] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      const session = await createSession({
        courseId: form.courseId,
        courseTitle: form.courseTitle,
        section: form.section,
        scheduledStart: new Date(form.scheduledStart).toISOString(),
        checkIntervalSec: Number(form.checkIntervalMin) * 60,
        checkDurationSec: Number(form.checkDurationSec),
        roster: parseRoster(form.rosterText),
      });
      onCreated(session);
    } catch (err) {
      setError(err.response?.data?.error?.formErrors?.[0] || 'Could not create the class.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center p-6 z-50">
      <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 max-w-md w-full flex flex-col gap-3 max-h-[90vh] overflow-y-auto">
        <h2 className="font-display font-bold text-ink text-lg">Add a class</h2>

        <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
          Course
          <input
            required
            value={form.courseTitle}
            onChange={set('courseTitle')}
            className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
          />
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
            Course ID
            <input
              required
              value={form.courseId}
              onChange={set('courseId')}
              className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
            />
          </label>
          <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
            Section
            <input
              value={form.section}
              onChange={set('section')}
              className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
            />
          </label>
        </div>

        <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
          Start time
          <input
            type="datetime-local"
            required
            value={form.scheduledStart}
            onChange={set('scheduledStart')}
            className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
          />
        </label>

        <div className="grid grid-cols-2 gap-3">
          <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
            Check interval (min)
            <input
              type="number"
              min={1}
              value={form.checkIntervalMin}
              onChange={set('checkIntervalMin')}
              className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
            />
          </label>
          <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
            Check duration (sec)
            <input
              type="number"
              min={5}
              value={form.checkDurationSec}
              onChange={set('checkDurationSec')}
              className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink"
            />
          </label>
        </div>

        <label className="text-[12.5px] text-ink-soft flex flex-col gap-1.5">
          Roster (one student per line — <span className="font-mono">Name, StudentID</span>)
          <textarea
            rows={4}
            value={form.rosterText}
            onChange={set('rosterText')}
            placeholder={'Ashikur Rahman, 20244103406\nSaifur Rahman, 20244103425'}
            className="border border-light-line px-3 py-2.5 rounded-lg text-sm text-ink font-mono text-[12.5px]"
          />
        </label>

        {error && <p className="text-danger text-xs">{error}</p>}

        <div className="flex gap-2 mt-1">
          <Button type="button" variant="ghost" onClick={onCancel} className="flex-1">
            Cancel
          </Button>
          <Button type="submit" disabled={saving} className="flex-1">
            {saving ? 'Creating…' : 'Create class'}
          </Button>
        </div>
      </form>
    </div>
  );
}
