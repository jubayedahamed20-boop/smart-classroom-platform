import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';
import { listSessions, startSession, endSession } from '../../services/api';
import AppHeader from '../shared/AppHeader';
import Button from '../shared/Button';
import AddClassForm from './AddClassForm';
import ScheduleManager from '../shared/ScheduleManager';
import AnnouncementComposer from '../shared/AnnouncementComposer';

const SESSION_BADGE = {
  SCHEDULED: 'bg-sky/15 text-sky-deep',
  LIVE: 'bg-teal/15 text-teal',
  ENDED: 'bg-dark-sub/15 text-ink-soft',
};
const SESSION_LABEL = { SCHEDULED: 'Scheduled', LIVE: 'Live', ENDED: 'Ended' };

const TABS = [
  { id: 'classes', label: 'Classes' },
  { id: 'schedule', label: 'Schedule' },
  { id: 'announcements', label: 'Announcements' },
];

export default function TeacherDashboard() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [tab, setTab] = useState('classes');
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [busyId, setBusyId] = useState(null);

  const load = () => {
    setLoading(true);
    listSessions()
      .then((all) => setSessions(all.filter((s) => s.teacherId === user.id)))
      .finally(() => setLoading(false));
  };

  useEffect(load, [user]);

  const handleStart = async (id) => {
    setBusyId(id);
    try {
      await startSession(id);
      navigate(`/class/${id}/lobby`);
    } finally {
      setBusyId(null);
    }
  };

  const handleEnd = async (id) => {
    setBusyId(id);
    try {
      await endSession(id);
      load();
    } finally {
      setBusyId(null);
    }
  };

  const live = sessions.filter((s) => s.status === 'LIVE');
  const upcoming = sessions.filter((s) => s.status === 'SCHEDULED');
  const ended = sessions.filter((s) => s.status === 'ENDED');

  // De-duplicated course list from this teacher's own sessions — feeds the
  // "attach to a course" dropdown in the announcement composer.
  const myCourses = Object.values(
    sessions.reduce((acc, s) => {
      acc[s.courseId] = { courseId: s.courseId, courseTitle: s.courseTitle };
      return acc;
    }, {})
  );

  return (
    <section className="min-h-screen bg-light-bg">
      <AppHeader subtitle="Teacher dashboard" />
      <div className="max-w-4xl mx-auto p-6 flex flex-col gap-5">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="font-display text-lg font-bold text-ink">Teacher dashboard</h1>
            <p className="text-ink-soft text-[13px]">{user.name}</p>
          </div>
          <nav className="flex gap-1 bg-white border border-light-line rounded-xl p-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition ${
                  tab === t.id ? 'bg-blue text-white' : 'text-ink-soft hover:text-ink'
                }`}
              >
                {t.label}
              </button>
            ))}
          </nav>
        </div>

        {tab === 'classes' && (
          <>
            <div className="flex justify-end">
              <Button onClick={() => setShowAdd(true)}>+ Add class</Button>
            </div>

            {loading && <p className="text-ink-soft text-[13px]">Loading…</p>}

            {!loading && sessions.length === 0 && (
              <div className="bg-white border border-light-line rounded-2xl p-8 text-center">
                <p className="text-ink-soft text-[13.5px]">You haven't added any classes yet.</p>
                <Button onClick={() => setShowAdd(true)} className="mt-3">+ Add your first class</Button>
              </div>
            )}

            {[...live, ...upcoming, ...ended].length > 0 && (
              <div className="bg-white border border-light-line rounded-2xl p-5">
                <ul className="flex flex-col gap-2">
                  {[...live, ...upcoming, ...ended].map((s) => (
                    <li key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-light-bg gap-3 flex-wrap">
                      <div className="min-w-[180px]">
                        <p className="text-ink text-[13.5px] font-medium">{s.courseTitle}</p>
                        <p className="text-ink-soft text-[12px]">
                          {s.section} · {new Date(s.scheduledStart).toLocaleString()} · {s.roster?.length || 0} students
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${SESSION_BADGE[s.status]}`}>
                          {SESSION_LABEL[s.status]}
                        </span>
                        <Button variant="ghost" onClick={() => navigate(`/teacher/class/${s.id}`)}>
                          Attendance
                        </Button>
                        {s.status !== 'ENDED' && (
                          <Button
                            onClick={() => (s.status === 'LIVE' ? navigate(`/class/${s.id}/lobby`) : handleStart(s.id))}
                            disabled={busyId === s.id}
                          >
                            {s.status === 'LIVE' ? 'Rejoin class' : 'Start class'}
                          </Button>
                        )}
                        {s.status === 'LIVE' && (
                          <Button variant="danger" onClick={() => handleEnd(s.id)} disabled={busyId === s.id}>
                            End
                          </Button>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}

        {tab === 'schedule' && <ScheduleManager user={user} scopeToTeacherId={user.id} />}

        {tab === 'announcements' && (
          <AnnouncementComposer user={user} courses={myCourses} allowAudiencePicker={false} />
        )}
      </div>

      {showAdd && (
        <AddClassForm
          onCancel={() => setShowAdd(false)}
          onCreated={() => {
            setShowAdd(false);
            load();
          }}
        />
      )}
    </section>
  );
}
