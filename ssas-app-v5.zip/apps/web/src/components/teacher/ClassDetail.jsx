import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';
import { getSession, getChecks, getOverrides, overrideStatus } from '../../services/api';
import AppHeader from '../shared/AppHeader';
import Avatar from '../shared/Avatar';
import Button from '../shared/Button';
import StatusBadge from '../shared/StatusBadge';
import { csvEscape, downloadBlob } from '../../services/exportUtils';

const OPTIONS = ['present', 'drowsy', 'absent', 'mismatch'];

export default function ClassDetail() {
  const { sessionId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [session, setSession] = useState(null);
  const [checks, setChecks] = useState([]);
  const [overrides, setOverrides] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    Promise.all([getSession(sessionId), getChecks(sessionId).catch(() => []), getOverrides(sessionId).catch(() => [])])
      .then(([s, c, o]) => {
        setSession(s);
        setChecks(c);
        setOverrides(o);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, [sessionId]);

  const latestStatus = (name) => {
    const mine = checks.filter((c) => c.name === name);
    if (!mine.length) return 'idle';
    return mine[mine.length - 1].status;
  };

  const attendancePct = (name) => {
    const mine = checks.filter((c) => c.name === name);
    if (!mine.length) return null;
    const present = mine.filter((c) => c.status === 'present' || c.status === 'woke').length;
    return Math.round((present / mine.length) * 100);
  };

  const drowsyCount = (name) => checks.filter((c) => c.name === name && c.status === 'drowsy').length;

  // New: surfaces which students the drowsiness detector caught dozing off
  // most, sorted worst-first, so a teacher can follow up without reading
  // the full roster/checks log line by line.
  // BUGFIX: this read `session.roster` directly. `session` starts out
  // `null` (useState(null) above) and stays that way until `load()`'s
  // async fetch resolves — but this line ran on every render, including
  // that very first one, before the `if (loading || !session) return`
  // guard further down ever got a chance to bail out. That crashed this
  // whole page with "Cannot read properties of null (reading 'roster')"
  // every single time a teacher opened a class's Attendance view.
  // Optional-chaining it is enough: `undefined?.roster` is just
  // `undefined`, so `[]` kicks in exactly like it does everywhere else in
  // this file, and the real data appears once the fetch finishes and
  // `session` is set.
  const drowsyRanked = (session?.roster || [])
    .map((r) => ({ ...r, drowsy: drowsyCount(r.name) }))
    .filter((r) => r.drowsy > 0)
    .sort((a, b) => b.drowsy - a.drowsy);

  const handleMark = async (name, status) => {
    await overrideStatus(sessionId, {
      name,
      fromStatus: latestStatus(name),
      toStatus: status,
      actor: user.name,
      createdAt: new Date().toISOString(),
    });
    load();
  };

  const exportCsv = () => {
    const header = 'name,studentId,latestStatus,attendancePct,drowsyChecks,checks';
    const rows = (session?.roster || []).map((r) =>
      [
        r.name,
        r.studentId || '',
        latestStatus(r.name),
        attendancePct(r.name) ?? '',
        drowsyCount(r.name),
        checks.filter((c) => c.name === r.name).length,
      ]
        .map(csvEscape)
        .join(',')
    );
    downloadBlob(`${session?.courseId || 'class'}-attendance.csv`, [header, ...rows].join('\n'), 'text/csv');
  };

  if (loading || !session) {
    return (
      <section className="min-h-screen bg-light-bg">
        <AppHeader subtitle="Teacher dashboard" />
        <p className="text-ink-soft text-[13px] p-6">Loading…</p>
      </section>
    );
  }

  return (
    <section className="min-h-screen bg-light-bg">
      <AppHeader subtitle="Teacher dashboard" />
      <div className="max-w-3xl mx-auto p-6 flex flex-col gap-5">
        <div className="flex items-center justify-between">
          <div>
            <button onClick={() => navigate('/teacher')} className="text-[12.5px] text-ink-soft hover:text-ink mb-1">
              ← Back to my classes
            </button>
            <h1 className="font-display text-lg font-bold text-ink">{session.courseTitle}</h1>
            <p className="text-ink-soft text-[13px]">
              {session.section} · {new Date(session.scheduledStart).toLocaleString()} · {session.status}
            </p>
          </div>
          <Button variant="ghost" onClick={exportCsv}>Export CSV</Button>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Roster &amp; presence</h2>
          <ul className="flex flex-col gap-3">
            {(session.roster || []).map((r) => (
              <li key={r.id} className="flex items-center gap-3 flex-wrap">
                <Avatar name={r.name} size={32} />
                <div className="min-w-[140px]">
                  <p className="text-ink text-[13px]">{r.name}</p>
                  {r.studentId && <p className="text-ink-soft text-[11px]">{r.studentId}</p>}
                </div>
                <StatusBadge status={latestStatus(r.name)} />
                {attendancePct(r.name) !== null && (
                  <span className="text-ink-soft text-[12px]">{attendancePct(r.name)}% attended</span>
                )}
                <div className="flex gap-1 ml-auto">
                  {OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      onClick={() => handleMark(r.name, opt)}
                      className="text-[11px] px-2 py-1 rounded-md border border-light-line text-ink-soft hover:bg-light-bg capitalize"
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </li>
            ))}
            {(session.roster || []).length === 0 && (
              <p className="text-ink-soft text-[13px]">No students on this class's roster yet.</p>
            )}
          </ul>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Attentiveness — who dozed off</h2>
          <p className="text-ink-soft text-[12.5px] mb-3">
            Backed by the same eye-closure (EAR) check that runs during class — ranked by how many
            check windows caught closed eyes for most of the window.
          </p>
          <ul className="flex flex-col gap-2">
            {drowsyRanked.map((r) => (
              <li key={r.id} className="flex items-center gap-3">
                <Avatar name={r.name} size={28} />
                <span className="text-[13px] text-ink flex-1 truncate">{r.name}</span>
                <span className="text-[12.5px] text-amber font-semibold">
                  {r.drowsy} drowsy check{r.drowsy === 1 ? '' : 's'}
                </span>
                <button
                  onClick={() => handleMark(r.name, 'present')}
                  className="text-[11px] px-2 py-1 rounded-md border border-light-line text-ink-soft hover:bg-light-bg"
                >
                  Mark present anyway
                </button>
              </li>
            ))}
            {drowsyRanked.length === 0 && (
              <p className="text-ink-soft text-[13px]">No one's been flagged drowsy yet — nice.</p>
            )}
          </ul>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Override audit log</h2>
          <ul className="flex flex-col gap-2">
            {[...overrides].reverse().map((o, i) => (
              <li key={i} className="p-2 rounded-lg bg-light-bg text-[12.5px]">
                <span className="font-medium text-ink">{o.name}</span>{' '}
                <span className="text-ink-soft">
                  {o.fromStatus} → {o.toStatus} by {o.actor}, {new Date(o.createdAt).toLocaleString()}
                </span>
              </li>
            ))}
            {overrides.length === 0 && <p className="text-ink-soft text-[13px]">No overrides recorded.</p>}
          </ul>
        </div>
      </div>
    </section>
  );
}
