import { useEffect } from 'react';
import Button from '../shared/Button';
import useFaceStore from '../../store/useFaceStore';
import { loadModels, runFaceRegistration } from '../../services/faceEngine';
import { saveFaceProfile } from '../../services/api';

export default function FaceIdSetup({ videoRef, name }) {
  const {
    modelsReady, modelsError, profile, registering, registrationStatus,
    setModelsReady, setModelsError, setProfile, setRegistering, setRegistrationStatus,
  } = useFaceStore();

  useEffect(() => {
    loadModels()
      .then(() => setModelsReady(true))
      .catch((e) => setModelsError(e.message));
  }, [setModelsReady, setModelsError]);

  const handleRegister = async () => {
    if (!modelsReady) {
      setRegistrationStatus('Detection models are still loading — wait a few seconds and try again.');
      return;
    }
    if (!videoRef.current) {
      setRegistrationStatus('Turn your camera on first.');
      return;
    }
    setRegistering(true);
    try {
      const result = await runFaceRegistration(videoRef.current, {
        onPhase: setRegistrationStatus,
      });
      // Persists to the server (replaces localStorage.setItem('ssas_face_profiles', ...))
      const saved = await saveFaceProfile(result).catch(() => ({
        ...result,
        updatedAt: new Date().toISOString(),
      }));
      setProfile(saved);
      setRegistrationStatus(
        `Face ID saved for "${name || 'You'}"${
          result.earBaseline ? ` — blink baseline ${result.earBaseline.toFixed(2)}` : ''
        }. You can rerun this anytime to recalibrate.`
      );
    } catch (e) {
      setRegistrationStatus(e.message);
    } finally {
      setRegistering(false);
    }
  };

  return (
    <div className="flex flex-col gap-2 bg-dark-tile border border-dark-line rounded-xl p-3.5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-[12.5px] font-semibold">Face ID</span>
        {!modelsReady && !modelsError && (
          <span className="text-[11px] text-dark-sub">loading model…</span>
        )}
        {modelsError && <span className="text-[11px] text-danger">model failed to load</span>}
      </div>
      <p className="text-[12.5px] text-dark-sub leading-snug">
        {registrationStatus ||
          (profile
            ? `Face ID on file for "${name || 'You'}" (saved ${new Date(profile.updatedAt).toLocaleDateString()}). Run again to recalibrate.`
            : `No face profile saved yet for "${name || 'You'}" — recommended before joining.`)}
      </p>
      <Button variant="ghost" onClick={handleRegister} disabled={registering}>
        {registering ? 'Calibrating…' : profile ? 'Recalibrate face ID (5s)' : 'Set up face ID (5s)'}
      </Button>
    </div>
  );
}
