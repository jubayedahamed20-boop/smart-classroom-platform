import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import useCamera from '../../hooks/useCamera';
import useSessionStore from '../../store/useSessionStore';
import useAuthStore from '../../store/useAuthStore';
import { getSession } from '../../services/api';
import CameraPreview from './CameraPreview';
import FaceIdSetup from './FaceIdSetup';
import JoinForm from './JoinForm';

export default function LobbyPage() {
  const navigate = useNavigate();
  const { sessionId } = useParams();
  const { user } = useAuthStore();
  const { videoRef, stream, error: camError, requesting, enable } = useCamera();
  const { setRole, name, setName, setCameraStream, setCheckPrefs, markJoined } = useSessionStore();

  const [interval, setInterval] = useState(5);
  const [duration, setDuration] = useState(15);
  const [joinError, setJoinError] = useState(null);
  const [rosterNames, setRosterNames] = useState([]);
  const [classInfo, setClassInfo] = useState(null);

  // Signed in now, so name + role come from the account, not free typing —
  // this also fixes the old name-collision-with-roster class of bugs since
  // a logged-in student's display name matches their actual roster entry.
  useEffect(() => {
    if (!user) return;
    setName(user.name);
    setRole(user.role === 'STUDENT' ? 'student' : 'teacher');
  }, [user, setName, setRole]);

  useEffect(() => {
    if (!sessionId) return;
    getSession(sessionId)
      .then((s) => {
        setClassInfo(s);
        setRosterNames((s.roster || []).map((r) => r.name));
        setInterval(Math.round((s.checkIntervalSec || 300) / 60));
        setDuration(s.checkDurationSec || 15);
      })
      .catch(() => setRosterNames([]));
  }, [sessionId]);

  const handleJoin = async () => {
    // BUGFIX ("easy time to join a class"): this used to hard-block
    // joining entirely if the camera failed for *any* reason — no camera
    // hardware, permission denied, another app already using it, or the
    // browser blocking getUserMedia off a non-localhost/https origin
    // (see the secure-context note in useCamera.js). There was no way
    // past that screen at all. The WebRTC layer (createMesh in
    // webrtc.js) already handles a missing local stream fine — it just
    // creates a receive-only peer connection — so this was a purely
    // artificial UI restriction, not a real technical one. Now a missing
    // camera only downgrades the join (no local video tile, and for
    // students, automatic face-based attendance checks are skipped — see
    // `enabled: !!cameraStream` in MeetingRoute.jsx, so a teacher can
    // still mark them present manually) instead of blocking it outright.
    const typedName = (name || user?.name || 'You').trim();
    const isOwnRosterName = user?.role === 'STUDENT';
    const collision =
      !isOwnRosterName &&
      rosterNames.some((n) => n.toLowerCase() === typedName.toLowerCase());
    if (collision) {
      setJoinError(
        `"${typedName}" is already in the class roster. Pick a different name so your tile doesn't clash with theirs.`
      );
      return;
    }
    setJoinError(null);
    setCameraStream(stream || null);
    setName(typedName);
    // BUGFIX: these inputs used to be display-only — actually carry them
    // into the meeting now (see useSessionStore + MeetingRoute).
    setCheckPrefs(interval, duration);
    markJoined();
    navigate(`/class/${sessionId}/meeting`);
  };

  return (
    <section className="min-h-screen w-full flex items-center justify-center p-6 bg-dark-bg text-dark-text">
      <div className="flex gap-7 max-w-[920px] w-full flex-wrap">
        <CameraPreview
          videoRef={videoRef}
          stream={stream}
          error={camError}
          requesting={requesting}
          name={name}
          onEnable={enable}
        />

        <div className="flex-1 min-w-[280px] flex flex-col gap-3.5">
          <div>
            <h1 className="text-[22px] font-display font-bold">Join classroom</h1>
            <p className="text-dark-sub text-[13.5px] -mt-1">
              {classInfo ? `${classInfo.courseTitle} — ${classInfo.section || ''}` : 'Loading class…'}
            </p>
          </div>

          <div className="bg-dark-tile border border-dark-line rounded-lg px-3.5 py-2.5 text-[13px]">
            Joining as <span className="font-semibold">{user?.name}</span>{' '}
            <span className="text-dark-sub capitalize">({user?.role?.toLowerCase()})</span>
          </div>

          <JoinForm
            interval={interval}
            setInterval={setInterval}
            duration={duration}
            setDuration={setDuration}
            canJoin
            hasCamera={!!stream}
            isStudent={user?.role === 'STUDENT'}
            onJoin={handleJoin}
            error={joinError}
          />

          {stream && <FaceIdSetup videoRef={videoRef} name={name} />}
        </div>
      </div>
    </section>
  );
}
