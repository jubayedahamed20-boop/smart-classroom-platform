import Button from '../shared/Button';

export default function JoinForm({
  interval, setInterval: setIntervalSec, duration, setDuration,
  canJoin, hasCamera, isStudent, onJoin, error,
}) {
  return (
    <>
      <div className="grid grid-cols-2 gap-3">
        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Check interval (min)
          <input
            type="number"
            min={1}
            value={interval}
            onChange={(e) => setIntervalSec(Number(e.target.value))}
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>
        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Check duration (sec)
          <input
            type="number"
            min={5}
            value={duration}
            onChange={(e) => setDuration(Number(e.target.value))}
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>
      </div>

      {error && <p className="text-danger text-xs">{error}</p>}

      {/* Camera is no longer required to join at all (see the BUGFIX note
          in LobbyPage's handleJoin) — this just makes the trade-off
          honest instead of hiding it, since a student joining without
          video won't get automatic face-based attendance checks. */}
      {!hasCamera && !error && (
        <p className="text-amber text-xs">
          {isStudent
            ? "No camera yet — you can still join, but you won't get automatic attendance checks. Ask your teacher to mark you present manually, or enable your camera above first."
            : "No camera yet — you can still join without video."}
        </p>
      )}

      <Button onClick={onJoin} disabled={!canJoin} className="w-full">
        {hasCamera ? 'Join class' : 'Join without camera'}
      </Button>
    </>
  );
}
