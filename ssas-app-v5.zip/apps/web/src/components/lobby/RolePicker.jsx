const ROLES = [
  { value: 'student', label: 'Student' },
  { value: 'teacher', label: 'Teacher' },
];

export default function RolePicker({ role, onChange }) {
  return (
    <div className="flex gap-2">
      {ROLES.map((r) => (
        <button
          key={r.value}
          type="button"
          onClick={() => onChange(r.value)}
          className={`flex-1 py-2.5 rounded-lg font-semibold text-[13.5px] border transition ${
            role === r.value
              ? 'bg-blue border-blue text-white'
              : 'bg-dark-tile border-dark-line text-dark-sub'
          }`}
        >
          {r.label}
        </button>
      ))}
    </div>
  );
}
