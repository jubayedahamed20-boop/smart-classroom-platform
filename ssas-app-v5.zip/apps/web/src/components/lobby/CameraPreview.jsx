import Avatar from '../shared/Avatar';
import Button from '../shared/Button';

export default function CameraPreview({ videoRef, stream, error, requesting, name, onEnable }) {
  return (
    <div className="flex-1 min-w-[280px] bg-dark-tile rounded-2xl aspect-[4/3] relative overflow-hidden border border-dark-line">
      <video
        ref={videoRef}
        autoPlay
        muted
        playsInline
        className={`w-full h-full object-cover -scale-x-100 ${stream ? 'block' : 'hidden'}`}
      />
      {!stream && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 text-dark-sub text-[13px] px-6 text-center">
          <Avatar name={name || 'You'} size={64} />
          {error && <p className="text-danger text-xs max-w-[240px]">{error}</p>}
          <Button onClick={onEnable} disabled={requesting}>
            {requesting ? 'Requesting camera…' : 'Enable camera'}
          </Button>
        </div>
      )}
    </div>
  );
}
