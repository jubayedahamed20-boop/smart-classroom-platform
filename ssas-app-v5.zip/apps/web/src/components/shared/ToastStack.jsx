import { useEffect, useRef } from 'react';

// Minimal, dependency-free toast stack. `toasts` is [{ id, title, body, actionLabel, onAction }].
// Each auto-dismisses after `durationMs` unless the person interacts with it first.
export default function ToastStack({ toasts, onDismiss, durationMs = 8000 }) {
  return (
    <div className="fixed bottom-5 right-5 z-[60] flex flex-col gap-2.5 w-[calc(100%-2.5rem)] max-w-sm">
      {toasts.map((t) => (
        <Toast key={t.id} toast={t} onDismiss={() => onDismiss(t.id)} durationMs={durationMs} />
      ))}
    </div>
  );
}

function Toast({ toast, onDismiss, durationMs }) {
  // BUGFIX: this used to depend on [onDismiss, durationMs]. `onDismiss` is
  // a brand-new `() => onDismiss(t.id)` closure created by ToastStack on
  // *every* render, so any parent re-render (OverviewTab re-renders at
  // least every POLL_MS=15s from polling, and more often on live socket
  // events) reset this effect and restarted the countdown from zero. In
  // practice a toast could keep getting its timer reset indefinitely and
  // never auto-dismiss. Storing the latest onDismiss in a ref and keying
  // the timer to `toast.id` (stable for the toast's whole lifetime) means
  // the countdown starts once, on mount, and isn't disturbed by unrelated
  // re-renders.
  const onDismissRef = useRef(onDismiss);
  useEffect(() => {
    onDismissRef.current = onDismiss;
  }, [onDismiss]);

  useEffect(() => {
    const timer = setTimeout(() => onDismissRef.current(), durationMs);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [toast.id]);

  return (
    <div className="bg-white border border-teal/30 shadow-lg rounded-2xl p-4 flex items-start gap-3 animate-[fadeIn_0.15s_ease-out]">
      <span className="w-2 h-2 rounded-full bg-teal mt-1.5 shrink-0 animate-pulse" />
      <div className="flex-1 min-w-0">
        <p className="font-display font-semibold text-ink text-[13.5px]">{toast.title}</p>
        {toast.body && <p className="text-ink-soft text-[12.5px] mt-0.5">{toast.body}</p>}
        <div className="flex items-center gap-3 mt-2">
          {toast.actionLabel && (
            <button
              onClick={() => {
                toast.onAction?.();
                onDismiss();
              }}
              className="text-[12.5px] font-semibold text-blue hover:text-blue-deep transition"
            >
              {toast.actionLabel}
            </button>
          )}
          <button onClick={onDismiss} className="text-[12.5px] font-semibold text-ink-soft hover:text-ink transition">
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
