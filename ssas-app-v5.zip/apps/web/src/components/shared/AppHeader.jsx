import { useNavigate } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';
import Avatar from './Avatar';

const HOME_BY_ROLE = { STUDENT: '/student', TEACHER: '/teacher', ADMIN: '/admin' };

export default function AppHeader({ subtitle }) {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();

  return (
    <header className="bg-white border-b border-light-line">
      <div className="max-w-5xl mx-auto px-6 py-3.5 flex items-center justify-between">
        <div
          className="flex items-center gap-2 cursor-pointer"
          onClick={() => navigate(user ? HOME_BY_ROLE[user.role] || '/' : '/')}
        >
          <div className="w-7 h-7 rounded-lg bg-blue flex items-center justify-center text-white font-display font-bold text-[13px]">
            S
          </div>
          <div>
            <span className="font-display font-bold text-ink text-[15px]">SSAS</span>
            {subtitle && <span className="text-ink-soft text-[12px] ml-2">{subtitle}</span>}
          </div>
        </div>

        {user && (
          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-[13px] text-ink font-medium leading-tight">{user.name}</div>
              <div className="text-[11px] text-ink-soft leading-tight capitalize">{user.role.toLowerCase()}</div>
            </div>
            <Avatar name={user.name} size={30} />
            <button
              onClick={() => {
                logout();
                navigate('/');
              }}
              className="text-[12.5px] font-semibold text-ink-soft hover:text-danger transition px-2 py-1"
            >
              Log out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
