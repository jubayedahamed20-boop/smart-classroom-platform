import { useEffect, useState } from 'react';
import { listAnnouncements, createAnnouncement, deleteAnnouncement } from '../../services/api';
import Button from '../shared/Button';

function timeAgo(iso) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.round(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.round(hrs / 24)}d ago`;
}

const inputCls =
  'bg-light-bg border border-light-line rounded-lg px-3 py-2 text-[13.5px] text-ink outline-none focus:border-blue transition';

// Shared between TeacherDashboard (audience locked to STUDENT, course
// optional) and AdminDashboard (full audience + campus-wide control).
// `courses` supplies the course dropdown; pass [] to hide it (free-text
// campus-wide posts only).
export default function AnnouncementComposer({ user, courses = [], allowAudiencePicker = false }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ title: '', body: '', courseId: '', priority: 'normal', audience: 'STUDENT' });
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState(null);

  const load = () => listAnnouncements().then(setItems).finally(() => setLoading(false));
  useEffect(() => { load(); }, []);

  const mine = items.filter((a) => a.authorId === user.id || user.role === 'ADMIN');

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setPosting(true);
    try {
      const course = courses.find((c) => c.courseId === form.courseId);
      await createAnnouncement({
        title: form.title,
        body: form.body,
        courseId: course?.courseId,
        courseTitle: course?.courseTitle,
        priority: form.priority,
        audience: allowAudiencePicker ? form.audience : 'STUDENT',
      });
      setForm({ title: '', body: '', courseId: '', priority: 'normal', audience: 'STUDENT' });
      load();
    } catch {
      setError('Could not post — try again.');
    } finally {
      setPosting(false);
    }
  }

  async function handleDelete(id) {
    await deleteAnnouncement(id);
    load();
  }

  return (
    <div className="flex flex-col gap-4">
      <form onSubmit={handleSubmit} className="bg-white border border-light-line rounded-2xl p-5 flex flex-col gap-3">
        <h3 className="font-display font-semibold text-ink text-[14px]">Post an announcement</h3>
        <input
          required
          className={inputCls}
          placeholder="Title"
          value={form.title}
          onChange={(e) => setForm({ ...form, title: e.target.value })}
        />
        <textarea
          required
          rows={3}
          className={`${inputCls} resize-none`}
          placeholder="Announcement text"
          value={form.body}
          onChange={(e) => setForm({ ...form, body: e.target.value })}
        />
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {courses.length > 0 && (
            <select
              className={inputCls}
              value={form.courseId}
              onChange={(e) => setForm({ ...form, courseId: e.target.value })}
            >
              <option value="">Campus-wide</option>
              {courses.map((c) => (
                <option key={c.courseId} value={c.courseId}>{c.courseTitle}</option>
              ))}
            </select>
          )}
          <select
            className={inputCls}
            value={form.priority}
            onChange={(e) => setForm({ ...form, priority: e.target.value })}
          >
            <option value="normal">Normal priority</option>
            <option value="high">High priority</option>
          </select>
          {allowAudiencePicker && (
            <select
              className={inputCls}
              value={form.audience}
              onChange={(e) => setForm({ ...form, audience: e.target.value })}
            >
              <option value="ALL">Everyone</option>
              <option value="STUDENT">Students only</option>
              <option value="TEACHER">Teachers only</option>
            </select>
          )}
        </div>
        {error && <p className="text-danger text-xs">{error}</p>}
        <Button type="submit" disabled={posting} className="self-start">
          {posting ? 'Posting…' : 'Post announcement'}
        </Button>
      </form>

      <div className="bg-white border border-light-line rounded-2xl p-5">
        <h3 className="font-display font-semibold text-ink text-[14px] mb-3">
          {user.role === 'ADMIN' ? 'All announcements' : 'Your announcements'}
        </h3>
        {loading && <p className="text-ink-soft text-[13px]">Loading…</p>}
        <ul className="flex flex-col gap-2">
          {mine.map((a) => (
            <li key={a.id} className="flex items-start justify-between gap-3 p-3 rounded-lg bg-light-bg">
              <div>
                <div className="flex items-center gap-2">
                  {a.priority === 'high' && (
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-danger/15 text-danger">HIGH</span>
                  )}
                  <p className="text-ink text-[13px] font-medium">{a.title}</p>
                </div>
                <p className="text-ink-soft text-[12px] mt-0.5">
                  {a.courseTitle || 'Campus-wide'} · {a.audience === 'ALL' ? 'Everyone' : `${a.audience.toLowerCase()}s`} · {timeAgo(a.createdAt)}
                </p>
              </div>
              <button
                onClick={() => handleDelete(a.id)}
                className="text-[12px] font-semibold text-ink-soft hover:text-danger transition shrink-0"
              >
                Delete
              </button>
            </li>
          ))}
          {!loading && mine.length === 0 && <p className="text-ink-soft text-[13px]">Nothing posted yet.</p>}
        </ul>
      </div>
    </div>
  );
}
