import { useEffect, useState } from 'react';
import { listSchedule, createScheduleSlot, deleteScheduleSlot } from '../../services/api';
import { DAY_NAMES } from '../../services/constants';
import Button from '../shared/Button';

const inputCls =
  'bg-light-bg border border-light-line rounded-lg px-3 py-2 text-[13.5px] text-ink outline-none focus:border-blue transition';

const genId = () =>
  crypto.randomUUID ? crypto.randomUUID() : `r-${Date.now()}-${Math.random().toString(36).slice(2)}`;

function parseRoster(text) {
  return text
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line) => {
      const [name, studentId] = line.split(',').map((p) => p.trim());
      return { id: genId(), name, studentId: studentId || undefined };
    });
}

// Shared between TeacherDashboard (sees + manages only its own slots) and
// AdminDashboard (sees + manages every slot campus-wide). `scopeToTeacherId`
// filters the list and defaults new slots to that teacher.
export default function ScheduleManager({ user, scopeToTeacherId = null }) {
  const [slots, setSlots] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    courseId: '', courseTitle: '', section: '', dayOfWeek: '1', startTime: '10:00', endTime: '11:20', room: '', rosterText: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const load = () =>
    listSchedule().then((all) => setSlots(scopeToTeacherId ? all.filter((s) => s.teacherId === scopeToTeacherId) : all))
      .finally(() => setLoading(false));

  useEffect(() => { load(); }, [scopeToTeacherId]);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setSaving(true);
    try {
      await createScheduleSlot({
        courseId: form.courseId,
        courseTitle: form.courseTitle,
        section: form.section || undefined,
        dayOfWeek: Number(form.dayOfWeek),
        startTime: form.startTime,
        endTime: form.endTime,
        room: form.room || undefined,
        roster: parseRoster(form.rosterText),
      });
      setForm({ courseId: '', courseTitle: '', section: '', dayOfWeek: '1', startTime: '10:00', endTime: '11:20', room: '', rosterText: '' });
      setShowForm(false);
      load();
    } catch {
      setError('Could not save — check the fields and try again.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    await deleteScheduleSlot(id);
    load();
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h3 className="font-display font-semibold text-ink text-[14px]">Weekly timetable</h3>
        <Button onClick={() => setShowForm((v) => !v)} variant={showForm ? 'ghost' : 'primary'}>
          {showForm ? 'Cancel' : '+ Add weekly slot'}
        </Button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="bg-white border border-light-line rounded-2xl p-5 flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            <input required className={inputCls} placeholder="Course ID (e.g. CSE318)" value={form.courseId} onChange={(e) => setForm({ ...form, courseId: e.target.value })} />
            <input required className={inputCls} placeholder="Course title" value={form.courseTitle} onChange={(e) => setForm({ ...form, courseTitle: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <select className={inputCls} value={form.dayOfWeek} onChange={(e) => setForm({ ...form, dayOfWeek: e.target.value })}>
              {DAY_NAMES.map((d, i) => <option key={i} value={i}>{d}</option>)}
            </select>
            <input required type="time" className={inputCls} value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
            <input required type="time" className={inputCls} value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
            <input className={inputCls} placeholder="Room" value={form.room} onChange={(e) => setForm({ ...form, room: e.target.value })} />
          </div>
          <input className={inputCls} placeholder="Section (optional)" value={form.section} onChange={(e) => setForm({ ...form, section: e.target.value })} />
          <label className="text-ink-soft text-[11.5px] font-semibold uppercase tracking-wide">
            Roster (one per line — Name, StudentID)
          </label>
          <textarea
            rows={3}
            className={`${inputCls} font-mono text-[12.5px] resize-none`}
            placeholder={'Ashikur Rahman, 20244103400\nSaifur Rahman, 20244103401'}
            value={form.rosterText}
            onChange={(e) => setForm({ ...form, rosterText: e.target.value })}
          />
          {error && <p className="text-danger text-xs">{error}</p>}
          <Button type="submit" disabled={saving} className="self-start">{saving ? 'Saving…' : 'Save weekly slot'}</Button>
        </form>
      )}

      <div className="bg-white border border-light-line rounded-2xl p-5">
        {loading && <p className="text-ink-soft text-[13px]">Loading…</p>}
        <ul className="flex flex-col gap-2">
          {slots.map((s) => (
            <li key={s.id} className="flex items-center justify-between p-3 rounded-lg bg-light-bg gap-3 flex-wrap">
              <div>
                <p className="text-ink text-[13px] font-medium">{s.courseTitle}</p>
                <p className="text-ink-soft text-[12px]">
                  {DAY_NAMES[s.dayOfWeek]} · {s.startTime}–{s.endTime}
                  {s.room ? ` · ${s.room}` : ''} · {s.roster?.length || 0} students
                  {scopeToTeacherId === null && s.teacherName ? ` · ${s.teacherName}` : ''}
                </p>
              </div>
              <button
                onClick={() => handleDelete(s.id)}
                className="text-[12px] font-semibold text-ink-soft hover:text-danger transition"
              >
                Delete
              </button>
            </li>
          ))}
          {!loading && slots.length === 0 && <p className="text-ink-soft text-[13px]">No weekly slots yet.</p>}
        </ul>
      </div>
    </div>
  );
}
