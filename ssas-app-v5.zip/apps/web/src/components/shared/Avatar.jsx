const AVATAR_COLORS = ['#2A5EF5', '#00A88E', '#C9750E', '#8B5CF6', '#E5484D', '#0EA5B7'];

function colorFor(name) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % AVATAR_COLORS.length;
  return AVATAR_COLORS[h];
}

function initials(name) {
  return name
    .split(' ')
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

export default function Avatar({ name = 'You', size = 64 }) {
  return (
    <div
      className="rounded-full flex items-center justify-center font-display font-bold text-white shrink-0"
      style={{ width: size, height: size, background: colorFor(name), fontSize: size * 0.34 }}
    >
      {initials(name)}
    </div>
  );
}
