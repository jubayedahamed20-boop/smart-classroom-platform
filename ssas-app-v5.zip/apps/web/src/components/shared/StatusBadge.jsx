const STYLES = {
  present: { bg: 'bg-teal/15', text: 'text-teal', label: 'Present' },
  woke: { bg: 'bg-teal/15', text: 'text-teal', label: 'Woke up' },
  drowsy: { bg: 'bg-amber/15', text: 'text-amber', label: 'Drowsy/asleep' },
  absent: { bg: 'bg-danger/15', text: 'text-danger', label: 'Absent' },
  mismatch: { bg: 'bg-violet/15', text: 'text-violet', label: 'Face mismatch' },
  override: { bg: 'bg-sky/15', text: 'text-sky-deep', label: 'Manual override' },
  idle: { bg: 'bg-dark-sub/15', text: 'text-dark-sub', label: 'No check yet' },
};

export default function StatusBadge({ status = 'idle', size = 'sm' }) {
  const s = STYLES[status] || STYLES.idle;
  const pad = size === 'sm' ? 'px-2 py-0.5 text-[10.5px]' : 'px-2.5 py-1 text-xs';
  return (
    <span className={`inline-flex items-center rounded-full font-semibold ${pad} ${s.bg} ${s.text}`}>
      {s.label}
    </span>
  );
}
