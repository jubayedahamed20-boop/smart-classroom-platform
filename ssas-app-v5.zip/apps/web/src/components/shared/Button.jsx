const VARIANTS = {
  primary: 'bg-blue hover:bg-blue-deep text-white',
  ghost: 'bg-dark-tile hover:bg-dark-line text-dark-text border border-dark-line',
  danger: 'bg-danger hover:brightness-90 text-white',
};

export default function Button({ variant = 'primary', className = '', children, ...rest }) {
  return (
    <button
      className={`px-4 py-2.5 rounded-lg font-semibold text-sm transition disabled:opacity-50 disabled:cursor-not-allowed ${VARIANTS[variant]} ${className}`}
      {...rest}
    >
      {children}
    </button>
  );
}
