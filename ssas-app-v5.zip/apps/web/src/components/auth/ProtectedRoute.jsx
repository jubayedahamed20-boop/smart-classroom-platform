import { Navigate } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';

const HOME_BY_ROLE = { STUDENT: '/student', TEACHER: '/teacher', ADMIN: '/admin' };

export default function ProtectedRoute({ roles, children }) {
  const { user, status } = useAuthStore();

  if (status !== 'ready') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-light-bg">
        <p className="text-ink-soft text-sm">Loading…</p>
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  if (roles && !roles.includes(user.role)) {
    return <Navigate to={HOME_BY_ROLE[user.role] || '/'} replace />;
  }

  return children;
}
