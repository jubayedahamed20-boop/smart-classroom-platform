import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';
import { extractErrorMessage } from '../../services/api';
import Button from '../shared/Button';

const HOME_BY_ROLE = { STUDENT: '/student', TEACHER: '/teacher', ADMIN: '/admin' };

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const user = await login(email.trim(), password);
      navigate(HOME_BY_ROLE[user.role] || '/');
    } catch (err) {
      setError(extractErrorMessage(err, 'Invalid email or password.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-screen w-full flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="max-w-sm w-full flex flex-col gap-3.5">
        <div>
          <h1 className="text-[22px] font-display font-bold">Log in to SSAS</h1>
          <p className="text-dark-sub text-[13.5px] -mt-1">CSE318 · Section 7 · Online</p>
        </div>

        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Email
          <input
            type="email"
            required
            autoFocus
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="you@bubt.edu.bd"
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>

        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Password
          <input
            type="password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••••••"
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>

        {error && <p className="text-danger text-xs">{error}</p>}

        <Button type="submit" disabled={loading} className="w-full">
          {loading ? 'Logging in…' : 'Log in'}
        </Button>

        <p className="text-dark-sub text-[12.5px] text-center">
          No account?{' '}
          <Link to="/register" className="text-blue font-semibold">
            Sign up
          </Link>
        </p>
      </form>
    </section>
  );
}
