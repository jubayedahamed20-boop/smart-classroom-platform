import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import useAuthStore from '../../store/useAuthStore';
import { extractErrorMessage } from '../../services/api';
import Button from '../shared/Button';

const HOME_BY_ROLE = { STUDENT: '/student', TEACHER: '/teacher', ADMIN: '/admin' };

export default function RegisterPage() {
  const navigate = useNavigate();
  const { register } = useAuthStore();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'STUDENT', studentId: '' });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const payload = { ...form, name: form.name.trim(), email: form.email.trim() };
      if (payload.role !== 'STUDENT') delete payload.studentId;
      const user = await register(payload);
      navigate(HOME_BY_ROLE[user.role] || '/');
    } catch (err) {
      setError(extractErrorMessage(err, 'Could not create account.'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="min-h-screen w-full flex items-center justify-center p-6">
      <form onSubmit={handleSubmit} className="max-w-sm w-full flex flex-col gap-3.5">
        <div>
          <h1 className="text-[22px] font-display font-bold">Create your account</h1>
          <p className="text-dark-sub text-[13.5px] -mt-1">CSE318 · Section 7 · Online</p>
        </div>

        <div className="flex gap-2">
          {['STUDENT', 'TEACHER'].map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setForm((f) => ({ ...f, role: r }))}
              className={`flex-1 py-2.5 rounded-lg font-semibold text-[13.5px] border transition ${
                form.role === r ? 'bg-blue border-blue text-white' : 'bg-dark-tile border-dark-line text-dark-sub'
              }`}
            >
              {r === 'STUDENT' ? 'Student' : 'Teacher'}
            </button>
          ))}
        </div>

        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Full name
          <input
            required
            value={form.name}
            onChange={set('name')}
            placeholder="e.g. Ashikur Rahman"
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>

        {form.role === 'STUDENT' && (
          <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
            Student ID
            <input
              value={form.studentId}
              onChange={set('studentId')}
              placeholder="e.g. 20244103257"
              className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
            />
          </label>
        )}

        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Email
          <input
            type="email"
            required
            value={form.email}
            onChange={set('email')}
            placeholder="you@bubt.edu.bd"
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>

        <label className="text-[12.5px] text-dark-sub flex flex-col gap-1.5">
          Password
          <input
            type="password"
            required
            minLength={6}
            value={form.password}
            onChange={set('password')}
            placeholder="At least 6 characters"
            className="bg-dark-tile border border-dark-line text-dark-text px-3 py-2.5 rounded-lg text-sm"
          />
        </label>

        {error && <p className="text-danger text-xs">{error}</p>}

        <Button type="submit" disabled={loading} className="w-full">
          {loading ? 'Creating account…' : 'Create account'}
        </Button>

        <p className="text-dark-sub text-[12.5px] text-center">
          Already have an account?{' '}
          <Link to="/login" className="text-blue font-semibold">
            Log in
          </Link>
        </p>
      </form>
    </section>
  );
}
