import { useNavigate } from 'react-router-dom';
import useMeetingStore from '../../store/useMeetingStore';
import useSessionStore from '../../store/useSessionStore';
import useAuthStore from '../../store/useAuthStore';
import StatusBadge from '../shared/StatusBadge';
import Button from '../shared/Button';
import { csvEscape, downloadBlob } from '../../services/exportUtils';

const HOME_BY_ROLE = { STUDENT: '/student', TEACHER: '/teacher', ADMIN: '/admin' };

export default function ReportPage() {
  const navigate = useNavigate();
  const { name } = useSessionStore();
  const { user } = useAuthStore();
  const { checkLog } = useMeetingStore();

  const myChecks = checkLog.filter((c) => c.name === name);
  const presentCount = myChecks.filter((c) => c.status === 'present' || c.status === 'woke').length;
  const drowsyCount = myChecks.filter((c) => c.status === 'drowsy').length;
  const absentCount = myChecks.filter((c) => c.status === 'absent').length;
  const mismatchCount = myChecks.filter((c) => c.status === 'mismatch').length;
  const attendancePct = myChecks.length ? Math.round((presentCount / myChecks.length) * 100) : 0;

  const exportCsv = () => {
    const header = 'name,status,faceDetected,identityMatch,matchDistance,earValue,checkedAt';
    const rows = myChecks.map((c) =>
      [c.name, c.status, c.faceDetected, c.identityMatch, c.matchDistance, c.earValue, c.checkedAt]
        .map(csvEscape)
        .join(',')
    );
    downloadBlob('my-attendance.csv', [header, ...rows].join('\n'), 'text/csv');
  };

  return (
    <section className="min-h-screen bg-light-bg flex items-center justify-center p-6">
      <div className="max-w-lg w-full bg-white border border-light-line rounded-2xl p-6">
        <h1 className="font-display text-xl font-bold text-ink">Class report</h1>
        <p className="text-ink-soft text-[13px] mb-5">{name || 'You'} — CSE318, Section 7</p>

        <div className="flex items-center gap-4 mb-3">
          <div className="text-3xl font-display font-bold text-sky-deep">{attendancePct}%</div>
          <div className="text-ink-soft text-[13px]">
            attended {presentCount} of {myChecks.length} checks
          </div>
        </div>

        {myChecks.length > 0 && (
          <div className="grid grid-cols-3 gap-2 mb-5">
            <div className="bg-amber/10 rounded-lg p-2.5 text-center">
              <div className="text-lg font-display font-bold text-amber">{drowsyCount}</div>
              <div className="text-ink-soft text-[11px]">drowsy/asleep</div>
            </div>
            <div className="bg-danger/10 rounded-lg p-2.5 text-center">
              <div className="text-lg font-display font-bold text-danger">{absentCount}</div>
              <div className="text-ink-soft text-[11px]">absent</div>
            </div>
            <div className="bg-violet/10 rounded-lg p-2.5 text-center">
              <div className="text-lg font-display font-bold text-violet">{mismatchCount}</div>
              <div className="text-ink-soft text-[11px]">face mismatch</div>
            </div>
          </div>
        )}

        <ul className="flex flex-col gap-2 max-h-64 overflow-y-auto mb-5">
          {[...myChecks].reverse().map((c, i) => (
            <li key={i} className="flex items-center justify-between p-2 rounded-lg bg-light-bg text-[13px]">
              <span className="text-ink-soft">{new Date(c.checkedAt).toLocaleTimeString()}</span>
              <StatusBadge status={c.status} />
            </li>
          ))}
          {myChecks.length === 0 && (
            <p className="text-ink-soft text-[12.5px] text-center py-6">No checks recorded this session.</p>
          )}
        </ul>

        <div className="flex gap-2">
          <Button variant="ghost" onClick={exportCsv} className="flex-1">
            Export CSV
          </Button>
          <Button onClick={() => navigate(HOME_BY_ROLE[user?.role] || '/')} className="flex-1">
            Back to dashboard
          </Button>
        </div>
      </div>
    </section>
  );
}
