import { useState } from 'react';
import useAuthStore from '../../store/useAuthStore';
import useMeetingStore from '../../store/useMeetingStore';
import Avatar from '../shared/Avatar';
import StatusBadge from '../shared/StatusBadge';
import Button from '../shared/Button';
import AppHeader from '../shared/AppHeader';
import ScheduleManager from '../shared/ScheduleManager';
import AnnouncementComposer from '../shared/AnnouncementComposer';
import { csvEscape, downloadBlob } from '../../services/exportUtils';

const TABS = [
  { id: 'live', label: 'Live overview' },
  { id: 'schedule', label: 'Schedule' },
  { id: 'announcements', label: 'Announcements' },
];

export default function AdminDashboard() {
  const { user } = useAuthStore();
  const { roster, tiles, checkLog, overrides } = useMeetingStore();
  const [tab, setTab] = useState('live');

  const rows = roster.map((r) => {
    const checks = checkLog.filter((c) => c.name === r.name);
    const present = checks.filter((c) => c.status === 'present' || c.status === 'woke').length;
    const drowsy = checks.filter((c) => c.status === 'drowsy').length;
    const pct = checks.length ? Math.round((present / checks.length) * 100) : 0;
    return {
      ...r,
      pct,
      checks: checks.length,
      drowsy,
      current: tiles[r.name]?.status || 'idle',
      flags: tiles[r.name]?.flags || 0,
    };
  });

  const flagged = rows.filter((r) => r.flags > 0);

  // New: class-wide engagement snapshot — how many students are drowsy/asleep
  // right now, and who has racked up the most drowsy checks this session, so
  // an admin can see attentiveness trends at a glance instead of scanning
  // the whole roster row by row.
  const drowsyNow = rows.filter((r) => r.current === 'drowsy').length;
  const everChecked = rows.filter((r) => r.checks > 0).length;
  const classEngagementPct = everChecked
    ? Math.round((rows.reduce((sum, r) => sum + (r.checks - r.drowsy), 0) /
        rows.reduce((sum, r) => sum + r.checks, 0)) * 100) || 0
    : 0;
  const mostDrowsy = [...rows].filter((r) => r.drowsy > 0).sort((a, b) => b.drowsy - a.drowsy).slice(0, 5);

  const exportRosterCsv = () => {
    const header = 'name,studentId,checks,attendancePct,drowsyChecks,currentStatus,flags';
    const csvRows = rows.map((r) =>
      [r.name, r.id, r.checks, r.pct, r.drowsy, r.current, r.flags].map(csvEscape).join(',')
    );
    downloadBlob('roster-summary.csv', [header, ...csvRows].join('\n'), 'text/csv');
  };

  const exportFullJson = () => {
    downloadBlob(
      'ssas-full-backup.json',
      JSON.stringify({ roster, checkLog, overrides }, null, 2),
      'application/json'
    );
  };

  return (
    <section className="min-h-screen bg-light-bg">
      <AppHeader subtitle="Admin dashboard" />
      <div className="max-w-4xl mx-auto p-6 flex flex-col gap-5">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="font-display text-xl font-bold text-ink">Admin dashboard</h1>
            <p className="text-ink-soft text-[13px]">{user.name}</p>
          </div>
          <nav className="flex gap-1 bg-white border border-light-line rounded-xl p-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`px-4 py-2 rounded-lg text-[13px] font-semibold transition ${
                  tab === t.id ? 'bg-blue text-white' : 'text-ink-soft hover:text-ink'
                }`}
              >
                {t.label}
              </button>
            ))}
          </nav>
        </div>

        {tab === 'live' && (
        <>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="font-display text-lg font-bold text-ink">Live session overview</h2>
            <p className="text-ink-soft text-[13px]">
              CSE318 · Section 7 · Online — reflects whichever class meeting is currently open in this browser
            </p>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={exportRosterCsv}>Export roster CSV</Button>
            <Button onClick={exportFullJson}>Export full backup JSON</Button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white border border-light-line rounded-2xl p-4">
            <p className="text-ink-soft text-[11.5px] uppercase tracking-wide font-semibold">Class engagement</p>
            <p className="text-2xl font-display font-bold text-sky-deep mt-1">{classEngagementPct}%</p>
            <p className="text-ink-soft text-[11.5px]">checks that weren't drowsy/asleep</p>
          </div>
          <div className="bg-white border border-light-line rounded-2xl p-4">
            <p className="text-ink-soft text-[11.5px] uppercase tracking-wide font-semibold">Drowsy right now</p>
            <p className="text-2xl font-display font-bold text-amber mt-1">{drowsyNow}</p>
            <p className="text-ink-soft text-[11.5px]">of {roster.length} on roster</p>
          </div>
          <div className="bg-white border border-light-line rounded-2xl p-4">
            <p className="text-ink-soft text-[11.5px] uppercase tracking-wide font-semibold">Flagged students</p>
            <p className="text-2xl font-display font-bold text-danger mt-1">{flagged.length}</p>
            <p className="text-ink-soft text-[11.5px]">1+ drowsy/absent/mismatch check</p>
          </div>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Drowsiness / sleep overview</h2>
          <p className="text-ink-soft text-[12.5px] mb-3">
            Students ranked by how often the live face check caught closed eyes for most of a check window.
          </p>
          <ul className="flex flex-col gap-2">
            {mostDrowsy.map((r) => (
              <li key={r.id} className="flex items-center gap-3">
                <Avatar name={r.name} size={28} />
                <span className="text-[13px] text-ink flex-1 truncate">{r.name}</span>
                <span className="text-[12.5px] text-amber font-semibold">
                  {r.drowsy} drowsy check{r.drowsy === 1 ? '' : 's'}
                </span>
                <StatusBadge status={r.current} />
              </li>
            ))}
            {mostDrowsy.length === 0 && (
              <p className="text-ink-soft text-[13px]">No drowsiness detected this session.</p>
            )}
          </ul>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Attendance</h2>
          <ul className="flex flex-col gap-3">
            {rows.map((r) => (
              <li key={r.id} className="flex items-center gap-3">
                <Avatar name={r.name} size={32} />
                <span className="text-[13px] text-ink w-36 truncate">{r.name}</span>
                <div className="flex-1 h-2 rounded-full bg-light-bg overflow-hidden">
                  <div
                    className="h-full bg-sky rounded-full"
                    style={{ width: `${r.pct}%` }}
                  />
                </div>
                <span className="text-[12.5px] text-ink-soft w-10 text-right">{r.pct}%</span>
                <StatusBadge status={r.current} />
              </li>
            ))}
            {rows.length === 0 && <p className="text-ink-soft text-[13px]">No roster loaded.</p>}
          </ul>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Flagged students</h2>
          <ul className="flex flex-col gap-2">
            {flagged.map((r) => (
              <li key={r.id} className="flex items-center justify-between p-2 rounded-lg bg-amber/5 text-[13px]">
                <span className="text-ink">{r.name}</span>
                <span className="text-ink-soft">{r.flags} flag{r.flags === 1 ? '' : 's'}</span>
                <StatusBadge status={r.current} />
              </li>
            ))}
            {flagged.length === 0 && <p className="text-ink-soft text-[13px]">No flags — everyone's clean.</p>}
          </ul>
        </div>

        <div className="bg-white border border-light-line rounded-2xl p-5">
          <h2 className="font-display font-semibold text-ink mb-3">Override audit log</h2>
          <ul className="flex flex-col gap-2">
            {[...overrides].reverse().map((o, i) => (
              <li key={i} className="p-2 rounded-lg bg-light-bg text-[12.5px]">
                <span className="font-medium text-ink">{o.name}</span>{' '}
                <span className="text-ink-soft">
                  {o.fromStatus} → {o.toStatus} by {o.actor}, {new Date(o.createdAt).toLocaleString()}
                </span>
              </li>
            ))}
            {overrides.length === 0 && <p className="text-ink-soft text-[13px]">No overrides recorded.</p>}
          </ul>
        </div>
        </>
        )}

        {tab === 'schedule' && <ScheduleManager user={user} scopeToTeacherId={null} />}

        {tab === 'announcements' && (
          <AnnouncementComposer user={user} courses={[]} allowAudiencePicker={true} />
        )}
      </div>
    </section>
  );
}
