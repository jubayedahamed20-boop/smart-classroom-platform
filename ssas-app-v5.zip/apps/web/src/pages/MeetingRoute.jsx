import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import useSessionStore from '../store/useSessionStore';
import useMeetingStore from '../store/useMeetingStore';
import useChatStore from '../store/useChatStore';
import useAuthStore from '../store/useAuthStore';
import useCheckScheduler from '../hooks/useCheckScheduler';
import { getSession, overrideStatus, leaveSession } from '../services/api';
import { connectSocket, disconnectSocket } from '../services/socket';
import { createMesh } from '../services/webrtc';
import MeetingHeader from '../components/meeting/MeetingHeader';
import GridTile from '../components/meeting/GridTile';
import ControlBar from '../components/meeting/ControlBar';
import SidePanel from '../components/meeting/SidePanel';

export default function MeetingRoute() {
  const navigate = useNavigate();
  const { sessionId: SESSION_ID } = useParams();
  const { user } = useAuthStore();
  const [classInfo, setClassInfo] = useState(null);
  const [sessionLoadFailed, setSessionLoadFailed] = useState(false);
  // peerId -> { name, stream } — populated as WebRTC connections come up
  // and each peer's data-channel "hello" tells us who they actually are.
  const [remotePeers, setRemotePeers] = useState({});
  const { name, role, cameraStream, micOn, camOn, toggleMic, toggleCam, joinedAt, checkIntervalMin, checkDurationSec: checkDurationSecPref } =
    useSessionStore();
  const { roster, tiles, setRoster, panelOpen, togglePanel, setCheckSettings, setTileStatus, logCheck, logOverride } =
    useMeetingStore(); // logOverride is applied via the socket listener below, not called directly
  const videoRef = useRef(null);
  const isTeacher = role === 'teacher';

  useEffect(() => {
    if (videoRef.current && cameraStream) videoRef.current.srcObject = cameraStream;
  }, [cameraStream]);

  // Wires up the actual peer-to-peer video: joins the WebRTC mesh for
  // this session as soon as we know which session it is, and tracks each
  // remote peer's stream/name as connections come up, so GridTile can
  // render real video instead of always falling back to the avatar
  // placeholder.
  // BUGFIX: this used to also require `cameraStream` before connecting
  // at all — so someone who joined without a camera (see the "join
  // without camera" fix in LobbyPage.jsx) got no mesh connection
  // whatsoever, meaning they couldn't see or be seen by anyone, not even
  // as an avatar tile with a live status. createMesh already passes
  // `stream: localStream || undefined` to simple-peer, which is
  // perfectly happy to set up a receive-only connection with no local
  // stream, so the only thing actually gating this was this line.
  //
  // BUGFIX ("other id add in the video call" after leave+rejoin): this
  // effect used to be declared *after* the socket-connect effect below.
  // React runs cleanup functions in the same order the effects were
  // declared, so on unmount the socket-connect effect's cleanup
  // (disconnectSocket()) fired *before* this effect's cleanup — killing
  // the connection before mesh.teardown() ever got to emit its
  // 'room:leave'. That leave then sat in socket.io's outgoing buffer and
  // got auto-replayed on the *next* connection (a fresh socket.id that
  // hadn't even joined a room yet), so the server processed a stray
  // leave/peer-left for an id nobody was using right as the real
  // room:join for the rejoin landed — the "extra id" in the call.
  // Declaring the mesh effect first means its cleanup now runs first on
  // unmount, so room:leave always goes out over a still-live socket.
  useEffect(() => {
    if (!SESSION_ID) return undefined;
    const mesh = createMesh({
      sessionId: SESSION_ID,
      localName: name || user?.name || 'You',
      localStream: cameraStream,
      onRemoteStream: (peerId, stream) => {
        setRemotePeers((prev) => ({ ...prev, [peerId]: { ...prev[peerId], stream } }));
      },
      onPeerName: (peerId, peerName) => {
        setRemotePeers((prev) => ({ ...prev, [peerId]: { ...prev[peerId], name: peerName } }));
      },
      onPeerLeft: (peerId) => {
        setRemotePeers((prev) => {
          const next = { ...prev };
          delete next[peerId];
          return next;
        });
      },
    });
    return () => {
      mesh.teardown();
      setRemotePeers({});
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cameraStream, SESSION_ID]);

  // Real-time sync: other participants' checks/overrides land here live,
  // via the socket relay in apps/server/src/sockets/index.js — this is
  // what lets the SidePanel/AdminDashboard update without polling.
  useEffect(() => {
    const socket = connectSocket();
    const onUpdate = (entry) => {
      setTileStatus(entry.name, entry.status);
      logCheck(entry);
    };
    const onOverride = (entry) => {
      logOverride(entry);
    };
    // Incoming chat — server has already resolved "everyone" vs. a
    // direct message to just us (see chat:message in sockets/index.js),
    // so anything landing here is meant to be shown. Bump the unread
    // badge unless the Chat tab is the one currently open.
    // BUGFIX: this used to read `panelOpen` from the destructured value
    // above, which this effect's closure (empty dep array, so it's only
    // ever created once) froze at whatever panelOpen was on first render.
    // Toggling the panel afterwards never updated it, so a message that
    // arrived while the panel was actually closed could be marked "read"
    // and never bump the badge, making it look like nothing arrived.
    // Reading it fresh from the store, like panelTab already does below,
    // fixes that.
    const onChatMessage = (entry) => {
      const meeting = useMeetingStore.getState();
      useChatStore.getState().addMessage(entry, {
        incrementUnread: !(meeting.panelOpen && meeting.panelTab === 'chat'),
      });
    };
    socket.on('attendance:update', onUpdate);
    socket.on('attendance:override', onOverride);
    socket.on('chat:message', onChatMessage);
    return () => {
      socket.off('attendance:update', onUpdate);
      socket.off('attendance:override', onOverride);
      socket.off('chat:message', onChatMessage);
      disconnectSocket();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Loads the roster + check-interval config for this session (falls back
  // to sane defaults if the backend isn't reachable yet in dev). The user's
  // own Lobby choice (checkIntervalMin/checkDurationSecPref) wins over the
  // server default when they set one — see the BUGFIX note in LobbyPage.jsx.
  useEffect(() => {
    getSession(SESSION_ID)
      .then((s) => {
        setClassInfo(s);
        setSessionLoadFailed(false);
        setRoster(s.roster || []);
        const intervalSec = checkIntervalMin ? checkIntervalMin * 60 : s.checkIntervalSec || 300;
        const durationSec = checkDurationSecPref || s.checkDurationSec || 15;
        setCheckSettings(intervalSec, durationSec);
      })
      .catch(() => {
        // BUGFIX: this used to silently fabricate two fake students
        // ("Ashikur Rahman", "Nabila Kabir") whenever the API call failed,
        // which made a genuinely down backend look like a real class with
        // real attendees. Fail to an empty roster instead and surface it,
        // so it's obvious something didn't load rather than pretending.
        setSessionLoadFailed(true);
        setRoster([]);
        setCheckSettings(
          checkIntervalMin ? checkIntervalMin * 60 : 300,
          checkDurationSecPref || 15
        );
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // BUGFIX: the scheduler used to run for everyone with a camera stream,
  // including the teacher — so the teacher got periodic face/drowsiness
  // "check-ins" and a status badge just like a student, which doesn't
  // make sense (the teacher isn't being marked present/absent for their
  // own class). Only students get scheduled checks now.
  useCheckScheduler({ videoRef, name, sessionId: SESSION_ID, enabled: !isTeacher && !!cameraStream });

  const handleLeave = () => {
    leaveSession(SESSION_ID, { userId: user?.id, name }).catch(() => {});
    navigate(`/class/${SESSION_ID}/report`);
  };

  const handleOverride = (studentName, fromStatus) => {
    const toStatus = window.prompt(
      `Override status for ${studentName} (present / drowsy / absent / mismatch):`,
      fromStatus
    );
    if (!toStatus) return;
    const entry = { name: studentName, fromStatus, toStatus, actor: name, createdAt: new Date().toISOString() };
    // Not applied locally here — the server persists it and broadcasts
    // 'attendance:override' back over the socket (including to this same
    // browser), which is what actually updates the store. Single source
    // of truth, no double-logging.
    overrideStatus(SESSION_ID, entry).catch(() => {});
  };

  // Matches a roster name to whichever connected peer's data-channel
  // "hello" claimed that name (see webrtc.js). Until that handshake lands,
  // the tile just shows the avatar like it always did.
  const remoteStreamFor = (studentName) =>
    Object.values(remotePeers).find((p) => p.name === studentName)?.stream || null;

  return (
    <section className="min-h-screen flex flex-col bg-light-bg">
      <MeetingHeader
        courseTitle={classInfo?.courseTitle || 'CSE318 · System Analysis & Design'}
        section={classInfo?.section || 'Section 7 · Online'}
        joinedAt={joinedAt}
      />

      {sessionLoadFailed && (
        <div className="px-4 py-2 bg-amber/10 text-amber text-[12.5px] text-center">
          Couldn't reach the server for this class's roster — showing your own camera only.
        </div>
      )}

      {/* BUGFIX: this was a plain `flex` row with SidePanel at a fixed
          w-[300px]. On a ~375px phone that left the tile grid almost no
          room (375 - 300px sidebar), squashing every GridTile — the
          "reshape" bug. `relative` here + making SidePanel an absolute
          overlay on small screens (see SidePanel.jsx) fixes that; on
          sm+ screens it still sits side-by-side as before. */}
      <div className="flex-1 flex relative overflow-hidden">
        <div className="flex-1 p-3 sm:p-4 overflow-y-auto min-w-0">
          <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))' }}>
            {/* BUGFIX: GridTile's avatar fallback for the local tile only
                checked the camOn *toggle*, not whether a camera stream
                actually exists — so joining without a camera (now
                possible, see LobbyPage.jsx) left this tile completely
                blank instead of showing the avatar placeholder every
                other camera-off tile gets. Folding `!!cameraStream` into
                what we pass as camOn makes "no stream" behave exactly
                like "camera toggled off" without needing to touch
                GridTile's own logic. */}
            <GridTile
              name={name || 'You'}
              role={isTeacher ? 'teacher' : 'student'}
              isYou
              videoRef={videoRef}
              status={tiles[name]?.status || 'idle'}
              micOn={micOn}
              camOn={camOn && !!cameraStream}
            />
            {/* FIX: students never got a tile for the teacher — the grid
                only ever mapped over `roster`, which is the student list.
                The WebRTC connection to the teacher was live the whole
                time, but there was no box to show it in. Add one
                explicitly whenever we know the teacher's name and we're
                not the teacher ourselves. Also skip any roster entry
                that matches our own name, so a student who's also on
                the roster doesn't get a second, empty "self" tile next
                to their real "You" tile. */}
            {!isTeacher && classInfo?.teacherName && (
              <GridTile
                name={classInfo.teacherName}
                role="teacher"
                status={tiles[classInfo.teacherName]?.status || 'idle'}
                stream={remoteStreamFor(classInfo.teacherName)}
              />
            )}
            {roster
              .filter((r) => r.name !== (name || user?.name))
              .map((r) => (
                <GridTile
                  key={r.id}
                  name={r.name}
                  role="student"
                  status={tiles[r.name]?.status || 'idle'}
                  stream={remoteStreamFor(r.name)}
                />
              ))}
          </div>
        </div>

        {panelOpen && (
          <SidePanel
            isTeacher={isTeacher}
            onOverride={handleOverride}
            onClose={togglePanel}
            selfName={name || user?.name || 'You'}
            sessionId={SESSION_ID}
          />
        )}
      </div>

      <ControlBar
        micOn={micOn}
        camOn={camOn}
        onToggleMic={toggleMic}
        onToggleCam={toggleCam}
        onTogglePanel={togglePanel}
        onLeave={handleLeave}
      />
    </section>
  );
}
