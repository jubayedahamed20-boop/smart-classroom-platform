import AdminDashboard from '../components/admin/AdminDashboard';

export default function AdminRoute() {
  return <AdminDashboard />;
}
