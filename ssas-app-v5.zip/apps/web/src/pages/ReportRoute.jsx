import ReportPage from '../components/report/ReportPage';

export default function ReportRoute() {
  return <ReportPage />;
}
