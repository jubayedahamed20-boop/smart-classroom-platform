import { useEffect, useRef } from 'react';
import useMeetingStore from '../store/useMeetingStore';
import useFaceStore from '../store/useFaceStore';
import { runLiveCheck } from '../services/faceEngine';
import { logCheck as apiLogCheck } from '../services/api';
import { getSocket } from '../services/socket';

/**
 * Runs a real face-api.js verification against the local video element every
 * `checkIntervalSec`, for `checkDurationSec`, classifying face-present /
 * drowsy (EAR) / mismatch (identity distance) / absent. Ported from the
 * original demo's runCheck()/classifyFrames(), now server-synced instead of
 * localStorage-logged, and broadcast over the socket so the teacher's
 * SidePanel/AdminDashboard update live for every student.
 */
export default function useCheckScheduler({ videoRef, name, sessionId, enabled }) {
  const { checkIntervalSec, checkDurationSec, setNextCheckAt, setChecking, setTileStatus, logCheck } =
    useMeetingStore();
  const { profile, earThreshold } = useFaceStore();
  const timeoutRef = useRef(null);

  useEffect(() => {
    if (!enabled) return undefined;

    async function runOneCheck() {
      setChecking(true);
      const frames = [];
      const start = Date.now();
      const durationMs = checkDurationSec * 1000;

      while (Date.now() - start < durationMs) {
        try {
          if (videoRef.current && videoRef.current.readyState >= 2) {
            const frame = await runLiveCheck(videoRef.current, profile, earThreshold);
            frames.push(frame);
          }
        } catch (_) {
          /* a missed frame is fine — classify on whatever we collected */
        }
        await new Promise((r) => setTimeout(r, 600));
      }

      const status = classifyFrames(frames, !!profile);
      const last = frames[frames.length - 1] || {};
      const entry = {
        name,
        status,
        faceDetected: frames.some((f) => f.faceDetected),
        identityMatch: last.identityMatch ?? null,
        matchDistance: last.matchDistance ?? null,
        earValue: last.earValue ?? null,
        checkedAt: new Date().toISOString(),
      };

      setTileStatus(name, status);
      logCheck(entry);

      // Sync to backend + broadcast to the room (teacher's live view).
      apiLogCheck(sessionId, entry).catch(() => {});
      getSocket().emit('attendance:check', { sessionId, ...entry });

      setChecking(false);
      scheduleNext();
    }

    function scheduleNext() {
      const nextAt = Date.now() + checkIntervalSec * 1000;
      setNextCheckAt(nextAt);
      timeoutRef.current = setTimeout(runOneCheck, checkIntervalSec * 1000);
    }

    scheduleNext();
    return () => clearTimeout(timeoutRef.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, checkIntervalSec, checkDurationSec, profile, earThreshold, name, sessionId]);
}

/**
 * BUGFIX: this used to only ever return present/drowsy/absent/mismatch —
 * the original demo's four-state classifier (absent / drowsy / woke / present)
 * had a 'woke' state (eyes closed early in the check, open by the end — fell
 * asleep then woke back up) that got silently dropped in the rewrite, even
 * though the UI (StatusBadge, meeting store) still has full support for it.
 * Restored the original's early-half/late-half comparison below. Also fixed
 * override precedence: an identity mismatch should only override a
 * present/woke reading (someone IS there, just maybe not the right person),
 * not a drowsy one — the original applies it that way, this rewrite had it
 * overriding drowsy too.
 */
function classifyFrames(frames, hasProfile) {
  if (frames.length === 0) return 'absent';

  const faceRatio = frames.filter((f) => f.faceDetected).length / frames.length;
  if (faceRatio < 0.3) return 'absent';

  const seen = frames.filter((f) => f.faceDetected);
  const closed = (f) => f.eyesOpen === false;
  const closedRatio = seen.filter(closed).length / seen.length;
  const half = Math.floor(seen.length / 2) || 1;
  const firstHalf = seen.slice(0, half).filter(closed).length / half;
  const secondHalf = seen.slice(half).filter(closed).length / (seen.length - half || 1);

  let status;
  if (closedRatio > 0.6) status = 'drowsy';
  else if (firstHalf > 0.5 && secondHalf < 0.3) status = 'woke';
  else status = 'present';

  if (hasProfile && (status === 'present' || status === 'woke')) {
    const mismatchCount = seen.filter((f) => f.identityMatch === false).length;
    if (mismatchCount / seen.length > 0.5) return 'mismatch';
  }

  return status;
}
