import { describe, it, expect, vi, beforeAll, afterAll } from 'vitest';
import { render, cleanup, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { EventEmitter } from 'events';

console.log('EventEmitter is', typeof EventEmitter);

describe('sanity4', () => {
  it('renders', () => {
    const { getByText } = render(<div>hello</div>);
    expect(getByText('hello')).toBeTruthy();
  });
});
