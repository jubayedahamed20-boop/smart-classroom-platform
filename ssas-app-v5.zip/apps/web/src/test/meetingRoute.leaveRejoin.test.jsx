import { describe, it, expect, vi, beforeAll, afterAll } from 'vitest';
import { render, cleanup, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { EventEmitter } from 'events';

// NOTE: vi.hoisted() must come before any vi.mock() factory that closes
// over its result — vitest hoists both to the top of the module, but
// preserves their *relative* order, so a vi.mock() written above the
// vi.hoisted() it (indirectly, via shared module scope) depends on can
// end up evaluated before that binding is initialized.
const { createdSockets } = vi.hoisted(() => ({ createdSockets: [] }));

// --- Stub simple-peer: we're testing socket/room lifecycle, not real
// media negotiation. Records enough (initiator flag) for visibility but
// never actually connects.
vi.mock('simple-peer', () => {
  class FakePeer extends EventEmitter {
    constructor({ initiator }) {
      super();
      this.initiator = initiator;
      this.destroyed = false;
    }
    signal() {}
    send() {}
    destroy() {
      this.destroyed = true;
    }
  }
  return { default: FakePeer };
});

// --- Redirect socket.io-client's target from the app's relative '/' (only
// resolvable via the Vite dev proxy, which doesn't exist under jsdom) to
// the real server this test spins up. Everything else is the REAL
// socket.io-client library talking to the REAL server — only the URL is
// patched.
vi.mock('socket.io-client', async () => {
  const actual = await vi.importActual('socket.io-client');
  return {
    io: (_url, opts) => {
      const s = actual.io('http://localhost:4000', opts);
      createdSockets.push(s);
      return s;
    },
  };
});

import MeetingRoute from '../pages/MeetingRoute';
import useSessionStore from '../store/useSessionStore';
import useAuthStore from '../store/useAuthStore';

const SESSION_ID = 'vitest-session';

function renderMeeting() {
  return render(
    <MemoryRouter initialEntries={[`/class/${SESSION_ID}/meeting`]}>
      <Routes>
        <Route path="/class/:sessionId/meeting" element={<MeetingRoute />} />
      </Routes>
    </MemoryRouter>
  );
}

describe('MeetingRoute leave + rejoin (live server)', () => {
  let observer;
  const observed = [];

  beforeAll(async () => {
    useSessionStore.setState({ name: 'Test Student', role: 'student', cameraStream: null });
    useAuthStore.setState({ user: { id: 'u1', name: 'Test Student', role: 'student' } });

    const { io } = await vi.importActual('socket.io-client');
    observer = io('http://localhost:4000', { autoConnect: false });
    observer.on('webrtc:peer-left', (p) => observed.push({ event: 'peer-left', ...p, at: Date.now() }));
    observer.on('webrtc:peer-joined', (p) => observed.push({ event: 'peer-joined', ...p, at: Date.now() }));
    await new Promise((resolve, reject) => {
      observer.on('connect', resolve);
      observer.on('connect_error', reject);
      observer.connect();
    });
    observer.emit('room:join', { sessionId: SESSION_ID, name: 'Observer' });
  });

  afterAll(() => {
    observer?.disconnect();
  });

  it('does not leave a stray/duplicate room-membership event after unmount + remount', async () => {
    // --- Mount ("join") ---
    const view1 = renderMeeting();
    await waitFor(() => expect(createdSockets.length).toBeGreaterThan(0));
    const socketA = createdSockets[createdSockets.length - 1];
    await waitFor(() => expect(socketA.connected).toBe(true));
    const firstId = socketA.id;
    expect(firstId).toBeTruthy();

    // give the room:join a moment to land server-side
    await new Promise((r) => setTimeout(r, 200));

    // --- Unmount ("leave") ---
    view1.unmount();

    // Wait for the observer to see the peer-left for the FIRST id, and
    // for the underlying socket to actually disconnect.
    await waitFor(() => {
      expect(observed.some((e) => e.event === 'peer-left' && e.peerId === firstId)).toBe(true);
    });
    await waitFor(() => expect(socketA.connected).toBe(false));

    const eventsAfterLeave = observed.length;

    // --- Remount ("rejoin") ---
    const view2 = renderMeeting();
    await waitFor(() => expect(createdSockets.length).toBeGreaterThan(1));
    const socketB = createdSockets[createdSockets.length - 1];
    await waitFor(() => expect(socketB.connected).toBe(true));
    const secondId = socketB.id;
    expect(secondId).toBeTruthy();
    expect(secondId).not.toBe(firstId);

    await new Promise((r) => setTimeout(r, 300));

    // THE BUG: the old effect order queued a 'room:leave' for the *new*
    // connection (replayed from the disconnected old socket's send
    // buffer), which the server processed as a phantom leave for an id
    // that had only just joined — an extra, unexplained peer-left the
    // rest of the room never should have seen, for an id (`secondId`)
    // that's still actually in the call.
    const phantomLeaveForNewId = observed.find(
      (e) => e.event === 'peer-left' && e.peerId === secondId
    );
    expect(phantomLeaveForNewId).toBeUndefined();

    // Sanity: no *new* stray peer-left events fired at all between
    // finishing the leave and finishing the rejoin (only real transitions
    // should produce events, and rejoining alone shouldn't produce a
    // peer-left for anyone).
    const newEventsDuringRejoin = observed.slice(eventsAfterLeave);
    const strayLeaves = newEventsDuringRejoin.filter((e) => e.event === 'peer-left');
    expect(strayLeaves).toEqual([]);

    view2.unmount();
  }, 15000);
});
