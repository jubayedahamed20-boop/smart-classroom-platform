import { create } from 'zustand';
import { login as loginApi, register as registerApi, me as meApi } from '../services/api';

// Backs the real welcome/login/register flow. Token lives in localStorage
// (api.js's axios interceptor reads it from there on every request) —
// this store just mirrors it plus the decoded user for the UI/route guards.
const useAuthStore = create((set, get) => ({
  user: null,                 // { id, email, name, role, studentId }
  status: 'idle',             // 'idle' | 'loading' | 'ready'
  error: null,

  hydrate: async () => {
    const token = localStorage.getItem('ssas_jwt');
    if (!token) return set({ status: 'ready' });
    set({ status: 'loading' });
    try {
      const user = await meApi();
      set({ user, status: 'ready' });
    } catch {
      localStorage.removeItem('ssas_jwt');
      set({ user: null, status: 'ready' });
    }
  },

  login: async (email, password) => {
    set({ error: null });
    const { token, user } = await loginApi(email, password);
    localStorage.setItem('ssas_jwt', token);
    set({ user });
    return user;
  },

  register: async (payload) => {
    set({ error: null });
    const { token, user } = await registerApi(payload);
    localStorage.setItem('ssas_jwt', token);
    set({ user });
    return user;
  },

  logout: () => {
    localStorage.removeItem('ssas_jwt');
    set({ user: null });
  },
}));

export default useAuthStore;
