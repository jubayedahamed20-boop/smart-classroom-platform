import { create } from 'zustand';

// Replaces state.simStudents / state.studentLog / state.overrides / the
// countdown-pill fields from the original demo's global `state` object.
const useMeetingStore = create((set, get) => ({
  roster: [],                 // [{ id, name, included }] — loaded from /sessions/:id
  tiles: {},                  // name -> { status: 'idle'|'present'|'drowsy'|'absent'|'woke'|'mismatch'|'override', flags }
  checkLog: [],                // [{ name, status, faceDetected, identityMatch, matchDistance, earValue, checkedAt }]
  overrides: [],                // [{ name, fromStatus, toStatus, reason, actor, createdAt }]
  checkIntervalSec: 300,
  checkDurationSec: 15,
  nextCheckAt: null,
  checking: false,
  panelTab: 'roster',
  panelOpen: true,

  setRoster: (roster) => {
    const tiles = {};
    roster.forEach((r) => {
      tiles[r.name] = get().tiles[r.name] || { status: 'idle', flags: 0 };
    });
    set({ roster, tiles });
  },

  setCheckSettings: (checkIntervalSec, checkDurationSec) => set({ checkIntervalSec, checkDurationSec }),
  setNextCheckAt: (nextCheckAt) => set({ nextCheckAt }),
  setChecking: (checking) => set({ checking }),
  setPanelTab: (panelTab) => set({ panelTab }),
  togglePanel: () => set((s) => ({ panelOpen: !s.panelOpen })),

  setTileStatus: (name, status) =>
    set((s) => ({
      tiles: {
        ...s.tiles,
        [name]: {
          status,
          flags: (s.tiles[name]?.flags || 0) + (['drowsy', 'absent', 'mismatch'].includes(status) ? 1 : 0),
        },
      },
    })),

  logCheck: (entry) => set((s) => ({ checkLog: [...s.checkLog, entry] })),

  logOverride: (entry) =>
    set((s) => ({
      overrides: [...s.overrides, entry],
      tiles: { ...s.tiles, [entry.name]: { status: entry.toStatus, flags: s.tiles[entry.name]?.flags || 0 } },
    })),

  reset: () =>
    set({ roster: [], tiles: {}, checkLog: [], overrides: [], nextCheckAt: null, checking: false }),
}));

export default useMeetingStore;
