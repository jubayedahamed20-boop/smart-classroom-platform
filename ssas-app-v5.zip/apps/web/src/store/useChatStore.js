import { create } from 'zustand';

// Meeting chat state — mirrors useMeetingStore's shape/conventions.
// Messages are kept per-mount only (matches the rest of the meeting state,
// which is also memory-only and re-fetched/reset on each Lobby → Meeting
// entry); nothing here is persisted to the backend.
const useChatStore = create((set, get) => ({
  messages: [],          // [{ id, from, to, body, createdAt, self }]
  recipient: 'everyone',  // 'everyone' | a roster name — who compose targets
  unread: 0,              // messages received while the Chat tab isn't the active/open one

  setRecipient: (recipient) => set({ recipient }),

  addMessage: (entry, { incrementUnread = false } = {}) =>
    set((s) => ({
      messages: [...s.messages, entry],
      unread: incrementUnread ? s.unread + 1 : s.unread,
    })),

  clearUnread: () => set({ unread: 0 }),

  reset: () => set({ messages: [], recipient: 'everyone', unread: 0 }),
}));

export default useChatStore;
