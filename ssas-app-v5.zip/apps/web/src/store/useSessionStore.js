import { create } from 'zustand';

// Replaces the old global `state` object's identity/role fields.
// Meeting-in-progress state (roster, tiles, checks) lives in useMeetingStore,
// added in the next pass alongside GridTile/ControlBar.
const useSessionStore = create((set, get) => ({
  user: null,               // { id, name, role, studentId } — set after auth/join
  role: 'student',          // 'student' | 'teacher' | 'admin'
  name: '',
  cameraStream: null,
  micOn: true,
  camOn: true,
  joinedAt: null,
  // BUGFIX: the Lobby's check-interval/duration inputs were captured in
  // local component state and never went anywhere — MeetingRoute always
  // used the server's stored defaults instead. Carrying the user's choice
  // here so MeetingRoute can actually honor it (null = "use server default").
  checkIntervalMin: null,
  checkDurationSec: null,

  setRole: (role) => set({ role }),
  setName: (name) => set({ name }),
  setCameraStream: (cameraStream) => set({ cameraStream }),
  setCheckPrefs: (checkIntervalMin, checkDurationSec) => set({ checkIntervalMin, checkDurationSec }),
  // FIX: this used to only flip the `micOn` boolean for the UI icon —
  // it never touched the actual audio track, so peers kept hearing you
  // (once audio was even being captured at all — see the `audio: false`
  // fix in useCamera.js) no matter what the mic button showed. Mirrors
  // toggleCam's pattern: disable the track itself rather than
  // stopping/dropping it, so re-enabling doesn't need a fresh
  // getUserMedia call.
  toggleMic: () => {
    const { cameraStream, micOn } = get();
    cameraStream?.getAudioTracks().forEach((t) => { t.enabled = micOn ? false : true; });
    set({ micOn: !micOn });
  },
  // BUGFIX: ControlBar's camera button rendered and looked interactive but
  // was wired to `onToggleCam={() => {}}` in MeetingRoute — it never did
  // anything. Disabling the video track(s) (rather than stopping/dropping
  // the stream) turns the camera off for everyone watching, including
  // remote peers over WebRTC, and re-enabling restores it instantly with
  // no need to re-request getUserMedia.
  toggleCam: () => {
    const { cameraStream, camOn } = get();
    cameraStream?.getVideoTracks().forEach((t) => { t.enabled = camOn ? false : true; });
    set({ camOn: !camOn });
  },
  markJoined: () => set({ joinedAt: new Date().toISOString() }),
  reset: () => set({ user: null, cameraStream: null, joinedAt: null, camOn: true, checkIntervalMin: null, checkDurationSec: null }),
}));

export default useSessionStore;
