import { create } from 'zustand';
import { EAR_CLOSED_THRESHOLD_DEFAULT } from '../services/faceEngine';

// Replaces faceProfiles{} + state.faceProfile/state.earThreshold from the
// original demo. Profile now comes from the server (getFaceProfile), not
// localStorage, so it follows the user across devices.
const useFaceStore = create((set) => ({
  modelsReady: false,
  modelsError: null,
  profile: null,            // { descriptor: number[128], earBaseline, updatedAt } | null
  earThreshold: EAR_CLOSED_THRESHOLD_DEFAULT,
  registering: false,
  registrationStatus: '',

  setModelsReady: (modelsReady) => set({ modelsReady }),
  setModelsError: (modelsError) => set({ modelsError }),
  setProfile: (profile) =>
    set({
      profile,
      earThreshold:
        profile && typeof profile.earBaseline === 'number'
          ? Math.max(0.15, profile.earBaseline - 0.05)
          : EAR_CLOSED_THRESHOLD_DEFAULT,
    }),
  setRegistering: (registering) => set({ registering }),
  setRegistrationStatus: (registrationStatus) => set({ registrationStatus }),
}));

export default useFaceStore;
