import { useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import useAuthStore from './store/useAuthStore';

import WelcomePage from './components/welcome/WelcomePage';
import LoginPage from './components/auth/LoginPage';
import RegisterPage from './components/auth/RegisterPage';
import ProtectedRoute from './components/auth/ProtectedRoute';

import StudentDashboard from './components/student/StudentDashboard';
import TeacherDashboard from './components/teacher/TeacherDashboard';
import ClassDetail from './components/teacher/ClassDetail';

import LobbyRoute from './pages/LobbyRoute';
import MeetingRoute from './pages/MeetingRoute';
import ReportRoute from './pages/ReportRoute';
import AdminRoute from './pages/AdminRoute';

export default function App() {
  const hydrate = useAuthStore((s) => s.hydrate);

  // Restore the logged-in user from the stored JWT on first load, so a
  // refresh doesn't bounce a signed-in student/teacher back to /login.
  useEffect(() => {
    hydrate();
  }, [hydrate]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/" element={<WelcomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Student */}
        <Route
          path="/student"
          element={
            <ProtectedRoute roles={['STUDENT']}>
              <StudentDashboard />
            </ProtectedRoute>
          }
        />

        {/* Teacher */}
        <Route
          path="/teacher"
          element={
            <ProtectedRoute roles={['TEACHER']}>
              <TeacherDashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/teacher/class/:sessionId"
          element={
            <ProtectedRoute roles={['TEACHER', 'ADMIN']}>
              <ClassDetail />
            </ProtectedRoute>
          }
        />

        {/* Admin */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute roles={['ADMIN']}>
              <AdminRoute />
            </ProtectedRoute>
          }
        />

        {/* Shared classroom flow — any signed-in role can enter a class it
            has access to (student joining, teacher/admin running it) */}
        <Route
          path="/class/:sessionId/lobby"
          element={
            <ProtectedRoute>
              <LobbyRoute />
            </ProtectedRoute>
          }
        />
        <Route
          path="/class/:sessionId/meeting"
          element={
            <ProtectedRoute>
              <MeetingRoute />
            </ProtectedRoute>
          }
        />
        <Route
          path="/class/:sessionId/report"
          element={
            <ProtectedRoute>
              <ReportRoute />
            </ProtectedRoute>
          }
        />
      </Routes>
    </BrowserRouter>
  );
}
