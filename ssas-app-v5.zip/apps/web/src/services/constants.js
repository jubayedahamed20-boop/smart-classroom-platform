// TODO: replace with a real session id (route param / picked in a real
// SetupScreen) once that screen exists. Centralized here so the Lobby's
// roster-collision check and the Meeting screen always agree on which
// session they're talking about.
export const DEMO_SESSION_ID = 'demo-session';

// Minimum overall attendance percentage a student must maintain. Mirrors
// most university attendance policies (BUBT's included) — used by the
// Student dashboard's risk predictor to warn before it becomes a problem.
export const MIN_ATTENDANCE_PCT = 75;

// Below this (but still >= MIN_ATTENDANCE_PCT), the risk predictor shows
// a "watch" warning instead of a hard "at risk" one.
export const ATTENDANCE_WATCH_PCT = 82;

export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
export const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
