import { MIN_ATTENDANCE_PCT, ATTENDANCE_WATCH_PCT } from './constants';

/**
 * Attendance risk predictor.
 *
 * Takes each course's attended/total check counts and projects whether the
 * student can still recover above MIN_ATTENDANCE_PCT even if every
 * remaining scheduled class this term is attended — vs. whether they're
 * mathematically at risk of falling (or have already fallen) below it.
 *
 * `remainingSessions` is an estimate of classes left in the term for that
 * course; when unknown we fall back to a flat assumption so the predictor
 * still gives a directionally useful answer instead of refusing to run.
 */
const DEFAULT_REMAINING_ESTIMATE = 12;

export function computeCourseRisk({ present, total, remainingSessions = DEFAULT_REMAINING_ESTIMATE }) {
  const pct = total ? (present / total) * 100 : null;

  // Best case: attend every remaining class.
  const bestCaseTotal = total + remainingSessions;
  const bestCasePresent = present + remainingSessions;
  const bestCasePct = bestCaseTotal ? (bestCasePresent / bestCaseTotal) * 100 : null;

  let level = 'safe';
  if (pct !== null) {
    if (pct < MIN_ATTENDANCE_PCT) {
      level = bestCasePct !== null && bestCasePct < MIN_ATTENDANCE_PCT ? 'critical' : 'at-risk';
    } else if (pct < ATTENDANCE_WATCH_PCT) {
      level = 'watch';
    }
  }

  // How many of the next classes must be attended (in a row, with zero
  // more misses) to climb back to the minimum, given remainingSessions left.
  let classesNeededToRecover = 0;
  if (pct !== null && pct < MIN_ATTENDANCE_PCT) {
    let p = present;
    let t = total;
    let n = 0;
    while (t > 0 && (p / t) * 100 < MIN_ATTENDANCE_PCT && n < remainingSessions) {
      p += 1;
      t += 1;
      n += 1;
    }
    classesNeededToRecover = n;
  }

  return {
    pct: pct !== null ? Math.round(pct * 10) / 10 : null,
    bestCasePct: bestCasePct !== null ? Math.round(bestCasePct * 10) / 10 : null,
    level, // 'safe' | 'watch' | 'at-risk' | 'critical'
    classesNeededToRecover,
    canStillRecover: bestCasePct === null || bestCasePct >= MIN_ATTENDANCE_PCT,
  };
}

export const RISK_COPY = {
  safe: {
    label: 'On track',
    tone: 'teal',
    message: (c) => `${c} attendance is healthy — keep it up.`,
  },
  watch: {
    label: 'Keep an eye on this',
    tone: 'amber',
    message: (c) => `${c} attendance is above the minimum but getting close — a couple more misses will put it at risk.`,
  },
  'at-risk': {
    label: 'At risk',
    tone: 'danger',
    message: (c, r) =>
      `${c} attendance is below the ${MIN_ATTENDANCE_PCT}% requirement. Attend the next ${r.classesNeededToRecover || 'few'} class${r.classesNeededToRecover === 1 ? '' : 'es'} in a row to recover.`,
  },
  critical: {
    label: 'Cannot recover',
    tone: 'danger',
    message: (c) =>
      `${c} attendance is below ${MIN_ATTENDANCE_PCT}% and can no longer reach it even attending every remaining class this term. Talk to your course teacher as soon as possible.`,
  },
};
