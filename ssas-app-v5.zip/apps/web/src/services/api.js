import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('ssas_jwt');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Turns an axios error into one readable string for forms to show.
// Handles three cases that were previously all collapsing into the same
// generic fallback message (e.g. "Could not create account.") no matter
// what actually went wrong, which made the real problem (usually: the
// backend dev server just isn't running) invisible from the UI:
//   1. No response at all (err.response is undefined) — the request
//      never reached the server: it's down, or the Vite proxy in
//      vite.config.js couldn't reach it. This is the common case when
//      only `npm run dev` in apps/web was started and apps/server wasn't.
//   2. A zod validation error — the server sends `{ error: parsed.error.flatten() }`,
//      an OBJECT, not a string (see registerSchema.safeParse in
//      auth.routes.js), so `err.response.data.error` used to render as
//      "[object Object]" or get silently swallowed by the `||` fallback.
//   3. A plain string error message (e.g. "Email already registered",
//      "Invalid credentials") — the normal case, passed through as-is.
export function extractErrorMessage(err, fallback = 'Something went wrong.') {
  if (!err.response) {
    return "Can't reach the server — make sure the backend (apps/server) is running, then try again.";
  }
  const data = err.response.data?.error;
  if (typeof data === 'string') return data;
  if (data?.fieldErrors) {
    const firstField = Object.values(data.fieldErrors).flat().find(Boolean);
    if (firstField) return firstField;
  }
  if (data?.formErrors?.length) return data.formErrors[0];
  return fallback;
}

// --- Auth -------------------------------------------------------------
export const login = (email, password) => api.post('/auth/login', { email, password }).then((r) => r.data);
export const register = (payload) => api.post('/auth/register', payload).then((r) => r.data);
export const me = () => api.get('/auth/me').then((r) => r.data);

// --- Face profile -------------------------------------------------------
export const saveFaceProfile = (payload) => api.post('/face-profiles/me', payload).then((r) => r.data);
export const getFaceProfile = () => api.get('/face-profiles/me').then((r) => r.data);

// --- Sessions -------------------------------------------------------
export const listSessions = () => api.get('/sessions').then((r) => r.data);
export const createSession = (payload) => api.post('/sessions', payload).then((r) => r.data);
export const getSession = (id) => api.get(`/sessions/${id}`).then((r) => r.data);
export const joinSession = (id, payload) => api.post(`/sessions/${id}/join`, payload).then((r) => r.data);
export const leaveSession = (id, payload) => api.post(`/sessions/${id}/leave`, payload).then((r) => r.data);
export const startSession = (id) => api.post(`/sessions/${id}/start`).then((r) => r.data);
export const endSession = (id) => api.post(`/sessions/${id}/end`).then((r) => r.data);

// --- Attendance -------------------------------------------------------
export const logCheck = (sessionId, payload) => api.post(`/sessions/${sessionId}/checks`, payload).then((r) => r.data);
export const getChecks = (sessionId) => api.get(`/sessions/${sessionId}/checks`).then((r) => r.data);
export const overrideStatus = (sessionId, payload) => api.post(`/sessions/${sessionId}/overrides`, payload).then((r) => r.data);
export const getOverrides = (sessionId) => api.get(`/sessions/${sessionId}/overrides`).then((r) => r.data);

// --- Reporting -------------------------------------------------------
export const exportSessionCsv = (sessionId) => `/api/sessions/${sessionId}/export.csv`;
export const exportSessionJson = (sessionId) => `/api/sessions/${sessionId}/export.json`;

// --- Weekly schedule -------------------------------------------------------
export const listSchedule = () => api.get('/schedule').then((r) => r.data);
export const createScheduleSlot = (payload) => api.post('/schedule', payload).then((r) => r.data);
export const updateScheduleSlot = (id, payload) => api.put(`/schedule/${id}`, payload).then((r) => r.data);
export const deleteScheduleSlot = (id) => api.delete(`/schedule/${id}`).then((r) => r.data);

// --- Announcements -------------------------------------------------------
export const listAnnouncements = () => api.get('/announcements').then((r) => r.data);
export const createAnnouncement = (payload) => api.post('/announcements', payload).then((r) => r.data);
export const deleteAnnouncement = (id) => api.delete(`/announcements/${id}`).then((r) => r.data);

// --- Profile -------------------------------------------------------
export const updateProfile = (payload) => api.put('/auth/me', payload).then((r) => r.data);
export const changePassword = (payload) => api.post('/auth/change-password', payload).then((r) => r.data);

export default api;
