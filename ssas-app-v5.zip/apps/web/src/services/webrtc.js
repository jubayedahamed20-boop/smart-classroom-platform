import SimplePeer from 'simple-peer';
import { getSocket } from './socket';

/**
 * Full-mesh WebRTC via simple-peer, signaled over Socket.io. Fine up to
 * ~8-10 concurrent video participants per room — swap to an SFU (LiveKit)
 * if a section regularly exceeds that.
 *
 * Usage: const mesh = createMesh({ sessionId, localName, localStream, onRemoteStream, onPeerName, onPeerLeft });
 * mesh.teardown() on leave.
 */
export function createMesh({ sessionId, localName, localStream, onRemoteStream, onPeerName, onPeerLeft }) {
  const socket = getSocket();
  const peers = new Map(); // peerSocketId -> SimplePeer instance

  function addPeer(peerId, initiator) {
    const peer = new SimplePeer({ initiator, trickle: true, stream: localStream || undefined });

    peer.on('signal', (signal) => {
      socket.emit('webrtc:signal', { sessionId, to: peerId, signal });
    });
    peer.on('stream', (remoteStream) => onRemoteStream?.(peerId, remoteStream));
    // The signaling layer only ever knows socket IDs, not who's actually
    // behind them — the roster/report/attendance side of the app keys
    // everything by student name. Once the data channel is up, exchange
    // names directly peer-to-peer so the meeting grid can match a remote
    // video stream back to the right roster tile.
    peer.on('connect', () => {
      try {
        peer.send(JSON.stringify({ type: 'hello', name: localName }));
      } catch (_) {
        /* data channel not ready yet — remote tile just falls back to the avatar */
      }
    });
    peer.on('data', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg?.type === 'hello' && msg.name) onPeerName?.(peerId, msg.name);
      } catch (_) {
        /* not JSON / not a hello — ignore */
      }
    });
    peer.on('close', () => {
      peers.delete(peerId);
      onPeerLeft?.(peerId);
    });
    peer.on('error', () => {
      peers.delete(peerId);
      onPeerLeft?.(peerId);
    });

    peers.set(peerId, peer);
    return peer;
  }

  // Only the side told to initiate creates the peer eagerly; the other side
  // creates its (non-initiator) peer lazily on first signal — see the
  // matching BUGFIX note in apps/server/src/sockets/index.js.
  socket.on('webrtc:peer-joined', ({ peerId }) => addPeer(peerId, true));
  socket.on('webrtc:signal', ({ from, signal }) => {
    const peer = peers.get(from) || addPeer(from, false);
    peer.signal(signal);
  });
  socket.on('webrtc:peer-left', ({ peerId }) => {
    peers.get(peerId)?.destroy();
    peers.delete(peerId);
    onPeerLeft?.(peerId);
  });

  socket.emit('room:join', { sessionId, name: localName });

  return {
    teardown() {
      socket.emit('room:leave', { sessionId });
      peers.forEach((p) => p.destroy());
      peers.clear();
      socket.off('webrtc:peer-joined');
      socket.off('webrtc:signal');
      socket.off('webrtc:peer-left');
    },
  };
}
