import * as faceapi from 'face-api.js';

// Same public weights CDN the original demo used. In production, self-host
// these under /public/models to avoid a third-party runtime dependency.
const MODEL_URL = 'https://cdn.jsdelivr.net/gh/justadudewhohacks/face-api.js@master/weights';

export const EAR_CLOSED_THRESHOLD_DEFAULT = 0.23;
export const IDENTITY_MATCH_THRESHOLD = 0.55; // face-api descriptor distance below this = same person

let modelsReady = false;
let loadingPromise = null;

export function areModelsReady() {
  return modelsReady;
}

export function loadModels() {
  if (modelsReady) return Promise.resolve(true);
  if (loadingPromise) return loadingPromise;
  loadingPromise = (async () => {
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL);
    await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
    modelsReady = true;
    return true;
  })();
  return loadingPromise;
}

function dist(a, b) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

// Eye Aspect Ratio: high when eyes are open, near 0 when closed.
export function ear(eye) {
  const v1 = dist(eye[1], eye[5]);
  const v2 = dist(eye[2], eye[4]);
  const h = dist(eye[0], eye[3]);
  return (v1 + v2) / (2 * h);
}

export function averageDescriptors(list) {
  const len = list[0].length;
  const out = new Float32Array(len);
  list.forEach((d) => {
    for (let i = 0; i < len; i++) out[i] += d[i];
  });
  for (let i = 0; i < len; i++) out[i] /= list.length;
  return out;
}

export function euclideanDistance(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += (a[i] - b[i]) ** 2;
  return Math.sqrt(sum);
}

// BUGFIX: the default TinyFaceDetectorOptions (inputSize 416, scoreThreshold
// 0.5) misses faces that aren't dead-center/close to the lens — common in a
// laptop-lid camera framing — which was the other big contributor to
// "Could not get a clear look at your face" beyond the video-not-ready race
// fixed in useCamera. A larger input size and a slightly more lenient score
// threshold catch those frames without materially hurting accuracy.
const DETECTOR_OPTS = new faceapi.TinyFaceDetectorOptions({ inputSize: 512, scoreThreshold: 0.4 });

function videoFrameReady(video) {
  return !!video && video.readyState >= 2 && video.videoWidth > 0 && video.videoHeight > 0;
}

async function detectOnce(video, { withDescriptor = false } = {}) {
  if (!videoFrameReady(video)) return null;
  const base = faceapi.detectSingleFace(video, DETECTOR_OPTS).withFaceLandmarks(true);
  return withDescriptor ? base.withFaceDescriptor() : base;
}

/**
 * Runs the 5-second registration routine used by the Lobby's "Set up face ID"
 * step: phase 1 samples descriptors (identity), phase 2 samples EAR (blink
 * baseline). Reports progress via onPhase for UI status text.
 */
export async function runFaceRegistration(video, { onPhase } = {}) {
  if (!modelsReady) throw new Error('Detection models are still loading.');

  onPhase?.('Hold still and look at the camera…');
  const descriptors = [];
  let p1Start = Date.now();
  // 2.5s is enough once the camera is warm, but give it up to 6s total
  // (retrying in the same loop) before giving up — a cold camera / slow
  // autofocus can eat the first second or two with zero valid detections.
  const p1Budget = 6000;
  while (Date.now() - p1Start < p1Budget && (descriptors.length < 4 || Date.now() - p1Start < 2500)) {
    try {
      const full = await detectOnce(video, { withDescriptor: true });
      if (full) descriptors.push(full.descriptor);
    } catch (_) {
      /* a missed frame just means fewer samples averaged — not fatal */
    }
    await new Promise((r) => setTimeout(r, 300));
  }

  onPhase?.('Now keep your eyes open normally…');
  const earSamples = [];
  let p2Start = Date.now();
  while (Date.now() - p2Start < 2500) {
    try {
      const det = await detectOnce(video);
      if (det) {
        earSamples.push((ear(det.landmarks.getLeftEye()) + ear(det.landmarks.getRightEye())) / 2);
      }
    } catch (_) {}
    await new Promise((r) => setTimeout(r, 300));
  }

  if (descriptors.length === 0) {
    const msg = videoFrameReady(video)
      ? 'Could not get a clear look at your face — move closer, face the camera directly, and make sure the room is well lit, then try again.'
      : 'Camera feed isn\u2019t ready yet — wait a second after enabling the camera and try again.';
    throw new Error(msg);
  }

  const avgDescriptor = Array.from(averageDescriptors(descriptors));
  const avgEar = earSamples.length ? earSamples.reduce((a, b) => a + b, 0) / earSamples.length : null;

  return { descriptor: avgDescriptor, earBaseline: avgEar, sampleCount: descriptors.length };
}

/**
 * Runs one live verification check against a stored profile — used during
 * the meeting screen's periodic checks (next pass wires this into GridTile).
 */
export async function runLiveCheck(video, profile, earThreshold = EAR_CLOSED_THRESHOLD_DEFAULT) {
  const full = await detectOnce(video, { withDescriptor: true });
  if (!full) return { faceDetected: false, identityMatch: null, matchDistance: null, earValue: null };

  const earValue = (ear(full.landmarks.getLeftEye()) + ear(full.landmarks.getRightEye())) / 2;
  let identityMatch = null;
  let matchDistance = null;
  if (profile?.descriptor) {
    matchDistance = euclideanDistance(Array.from(full.descriptor), profile.descriptor);
    identityMatch = matchDistance < IDENTITY_MATCH_THRESHOLD;
  }
  return { faceDetected: true, identityMatch, matchDistance, earValue, eyesOpen: earValue >= earThreshold };
}
