import { io } from 'socket.io-client';

let socket = null;

// Lazily connects once, reused across the app (Meeting room joins, WebRTC
// signaling, live check-result broadcasts to the SidePanel/AdminDashboard).
export function getSocket() {
  if (!socket) {
    socket = io('/', {
      autoConnect: false,
      auth: { token: localStorage.getItem('ssas_jwt') },
    });
  }
  return socket;
}

export function connectSocket() {
  const s = getSocket();
  if (!s.connected) s.connect();
  return s;
}

export function disconnectSocket() {
  // BUGFIX ("other id add in the video call" on leave+rejoin): this used
  // to just call socket.disconnect() and keep reusing the same Socket
  // instance forever. socket.io-client buffers any emit() made while
  // disconnected (e.g. a room:leave that fires a beat after this) and
  // replays it automatically the moment the socket reconnects — so a
  // stale room:leave from the *previous* visit could fire on the *new*
  // connection (new socket.id, hasn't even room:join'd yet), telling the
  // server to boot a room member that was never actually joined this
  // time, right as the real room:join for the new id lands. Dropping the
  // instance entirely means the next getSocket()/connectSocket() call
  // builds a brand new socket with an empty send buffer, so nothing from
  // the last session can leak into the next one.
  socket?.disconnect();
  socket = null;
}
