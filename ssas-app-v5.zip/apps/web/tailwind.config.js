/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        // carried over 1:1 from the original demo's :root tokens
        blue: { DEFAULT: '#2A5EF5', deep: '#1A3FC4' },
        sky: { DEFAULT: '#0EA5E9', deep: '#0284C7', bg: '#F0F9FF' },
        teal: '#00C2A8',
        amber: '#C9750E',
        danger: '#E5484D',
        violet: '#7C3AED',
        dark: {
          bg: '#0B0D12', surface: '#171A21', tile: '#1E222B', line: '#2A2F3A',
          text: '#E7E9EE', sub: '#8B93A7',
        },
        light: { bg: '#F7F8FA', card: '#FFFFFF', line: '#E4E7EC' },
        ink: { DEFAULT: '#10151F', soft: '#4B5566' },
      },
      fontFamily: {
        display: ['Space Grotesk', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['IBM Plex Mono', 'monospace'],
      },
    },
  },
  plugins: [],
};
