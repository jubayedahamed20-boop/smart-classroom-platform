import jwt from 'jsonwebtoken';
import { findUserById } from '../db/store.js';

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
export const SIGN_OPTS = { expiresIn: '12h' };
export { JWT_SECRET };

export function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = findUserById(payload.sub);
    if (!user) return res.status(401).json({ error: 'Invalid token' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}
