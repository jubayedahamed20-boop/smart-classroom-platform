import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/rbac.middleware.js';
import { createAnnouncement, listAnnouncements, getAnnouncement, deleteAnnouncement } from '../db/store.js';

const router = Router();

const createSchema = z.object({
  title: z.string().min(1),
  body: z.string().min(1),
  courseId: z.string().optional(),
  courseTitle: z.string().optional(),
  priority: z.enum(['normal', 'high']).optional(),
  audience: z.enum(['ALL', 'STUDENT', 'TEACHER']).optional(),
});

// Everyone signed in reads announcements; the list is filtered to what's
// relevant to their role/audience so students don't see teacher-only posts.
// BUGFIX: this used to filter strictly by audience === req.user.role, which
// is right for a *reading* feed but this same endpoint also backs
// AnnouncementComposer's "Your announcements" management list. A teacher's
// composer always posts with audience: 'STUDENT' (only admins get the
// audience picker) — so a teacher's own announcement, being STUDENT-only,
// never matched their own TEACHER role and disappeared from their own
// list the instant they posted it, even though it was created fine and
// students could see it. Always including whatever the requester authored
// fixes that without loosening what non-authors can see.
router.get('/', requireAuth, (req, res) => {
  const all = listAnnouncements();
  const visible = all.filter(
    (a) => a.audience === 'ALL' || a.audience === req.user.role || a.authorId === req.user.id
  );
  res.json(visible);
});

// Teacher/admin only — posting an announcement is a privileged action.
router.post('/', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const announcement = createAnnouncement({
    ...parsed.data,
    authorId: req.user.id,
    authorName: req.user.name,
    role: req.user.role,
  });

  // Live-broadcast so an open student dashboard updates without a refresh.
  const io = req.app.get('io');
  io?.emit('announcement:new', announcement);

  res.json(announcement);
});

router.delete('/:id', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const existing = getAnnouncement(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.user.role === 'TEACHER' && existing.authorId !== req.user.id) {
    return res.status(403).json({ error: 'Not your announcement' });
  }
  deleteAnnouncement(req.params.id);
  res.json({ ok: true });
});

export default router;
