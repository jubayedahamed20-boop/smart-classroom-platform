import { Router } from 'express';
import { getSession, getChecks, getOverrides } from '../db/store.js';

const router = Router();

function csvEscape(v) {
  return `"${String(v ?? '').replace(/"/g, '""')}"`;
}

router.get('/:id/export.csv', (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  const checks = getChecks(req.params.id);

  const header = 'name,status,faceDetected,identityMatch,matchDistance,earValue,checkedAt';
  const rows = checks.map((c) =>
    [c.name, c.status, c.faceDetected, c.identityMatch, c.matchDistance, c.earValue, c.checkedAt]
      .map(csvEscape)
      .join(',')
  );

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="${session.courseId}-attendance.csv"`);
  res.send([header, ...rows].join('\n'));
});

router.get('/:id/export.json', (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });

  res.setHeader('Content-Disposition', `attachment; filename="${session.courseId}-backup.json"`);
  res.json({
    session,
    checks: getChecks(req.params.id),
    overrides: getOverrides(req.params.id),
    exportedAt: new Date().toISOString(),
  });
});

export default router;
