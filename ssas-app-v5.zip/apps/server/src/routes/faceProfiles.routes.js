import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.middleware.js';
import { upsertFaceProfile, getFaceProfile } from '../db/store.js';

const router = Router();

const profileSchema = z.object({
  descriptor: z.array(z.number()).length(128),
  earBaseline: z.number().nullable().optional(),
  sampleCount: z.number().optional(),
});

// Saves the 128-float descriptor + EAR baseline captured client-side by
// faceEngine.runFaceRegistration() in the Lobby. Replaces
// localStorage.setItem('ssas_face_profiles', ...) from the original demo.
router.post('/me', requireAuth, (req, res) => {
  const parsed = profileSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const profile = upsertFaceProfile(req.user.id, parsed.data);
  res.json(profile);
});

router.get('/me', requireAuth, (req, res) => {
  const profile = getFaceProfile(req.user.id);
  if (!profile) return res.status(404).json({ error: 'No face profile on file' });
  res.json(profile);
});

export default router;
