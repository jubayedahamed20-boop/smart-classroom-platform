import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/rbac.middleware.js';
import {
  createSession, getSession, listSessions, updateSessionStatus, ensureDemoSession,
  joinSession, leaveSession, addCheck, getChecks, addOverride, getOverrides,
} from '../db/store.js';

const router = Router();

// Seeds a demo session on boot so the frontend has something to load
// against before login/setup screens exist (see MeetingRoute.jsx fallback).
ensureDemoSession();

const createSchema = z.object({
  courseId: z.string(),
  courseTitle: z.string(),
  section: z.string().optional(),
  checkIntervalSec: z.number().optional(),
  checkDurationSec: z.number().optional(),
  scheduledStart: z.string().optional(),
  roster: z.array(z.object({ id: z.string(), name: z.string(), studentId: z.string().optional() })).optional(),
});

// Anyone signed in can browse classes (student dashboard needs this to
// find classes it's on the roster for; teacher dashboard filters by
// teacherId). Small classroom app — listing everything is fine at scale.
router.get('/', requireAuth, (_req, res) => {
  res.json(listSessions());
});

// Teacher/admin only — creating a class session is a privileged action.
router.post('/', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const parsed = createSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const session = createSession({ ...parsed.data, teacherId: req.user.id, teacherName: req.user.name });
  res.json(session);
});

router.get('/:id', (req, res) => {
  const session = getSession(req.params.id);
  if (!session) return res.status(404).json({ error: 'Session not found' });
  res.json(session);
});

// Teacher starts class -> goes LIVE, students can join / auto-checks begin.
router.post('/:id/start', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const session = updateSessionStatus(req.params.id, 'LIVE');
  if (!session) return res.status(404).json({ error: 'Session not found' });
  const io = req.app.get('io');
  // Room-scoped emit reaches sockets already inside the meeting (Lobby/
  // MeetingRoute join `session:<id>` via webrtc.js's room:join). It does
  // NOT reach a student's dashboard, which connects to the socket but
  // never joins that room — so also broadcast globally. GET /sessions
  // already returns every session's status to any authenticated user
  // with no per-room access control, so this doesn't expose anything a
  // dashboard couldn't already fetch; it's just the push side of it.
  io?.to(`session:${req.params.id}`).emit('session:status', { id: session.id, status: session.status });
  io?.emit('session:status', { id: session.id, status: session.status });
  res.json(session);
});

router.post('/:id/end', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const session = updateSessionStatus(req.params.id, 'ENDED');
  if (!session) return res.status(404).json({ error: 'Session not found' });
  const io = req.app.get('io');
  io?.to(`session:${req.params.id}`).emit('session:status', { id: session.id, status: session.status });
  io?.emit('session:status', { id: session.id, status: session.status });
  res.json(session);
});

// NOTE: join/leave/checks/overrides are intentionally open (no requireAuth)
// for now because the frontend doesn't have a login screen wired up yet —
// see README "Build order". Add requireAuth back here once it does; the
// middleware is already in place and used above on session creation.
router.post('/:id/join', (req, res) => {
  const { userId = 'anon', name = 'You' } = req.body || {};
  const participant = joinSession(req.params.id, userId, name);
  res.json(participant);
});

router.post('/:id/leave', (req, res) => {
  const { userId = 'anon' } = req.body || {};
  const participant = leaveSession(req.params.id, userId);
  res.json(participant);
});

const checkSchema = z.object({
  name: z.string(),
  status: z.enum(['present', 'drowsy', 'absent', 'woke', 'mismatch', 'override']),
  faceDetected: z.boolean().optional(),
  identityMatch: z.boolean().nullable().optional(),
  matchDistance: z.number().nullable().optional(),
  earValue: z.number().nullable().optional(),
  checkedAt: z.string().optional(),
});

router.post('/:id/checks', (req, res) => {
  const parsed = checkSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  // Persistence only — the socket path (see sockets/index.js) handles the
  // real-time broadcast so this REST write doesn't double-emit to the room.
  const entry = addCheck(req.params.id, parsed.data);
  res.json(entry);
});

router.get('/:id/checks', (req, res) => {
  res.json(getChecks(req.params.id));
});

const overrideSchema = z.object({
  name: z.string(),
  fromStatus: z.string().nullable().optional(),
  toStatus: z.string(),
  reason: z.string().optional(),
  actor: z.string(),
  createdAt: z.string().optional(),
});

router.post('/:id/overrides', (req, res) => {
  const parsed = overrideSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const entry = addOverride(req.params.id, parsed.data);
  req.app.get('io')?.to(`session:${req.params.id}`).emit('attendance:override', entry);
  res.json(entry);
});

router.get('/:id/overrides', (req, res) => {
  res.json(getOverrides(req.params.id));
});

export default router;
