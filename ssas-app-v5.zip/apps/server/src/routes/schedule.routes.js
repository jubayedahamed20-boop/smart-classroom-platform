import { Router } from 'express';
import { z } from 'zod';
import { requireAuth } from '../middleware/auth.middleware.js';
import { requireRole } from '../middleware/rbac.middleware.js';
import {
  createScheduleSlot, listScheduleSlots, getScheduleSlot,
  updateScheduleSlot, deleteScheduleSlot, ensureDemoScheduleAndAnnouncements,
} from '../db/store.js';

const router = Router();

// Seeds demo timetable + announcement data on boot (see ensureDemoSession()
// in sessions.routes.js for the analogous pattern).
ensureDemoScheduleAndAnnouncements();

const slotSchema = z.object({
  courseId: z.string(),
  courseTitle: z.string(),
  section: z.string().optional(),
  dayOfWeek: z.number().min(0).max(6),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  endTime: z.string().regex(/^\d{2}:\d{2}$/),
  room: z.string().optional(),
  roster: z.array(z.object({ id: z.string(), name: z.string(), studentId: z.string().optional() })).optional(),
});

// Anyone signed in can read the full weekly timetable — student dashboard
// filters client-side to slots where they're on the roster, same pattern
// as GET /sessions.
router.get('/', requireAuth, (_req, res) => {
  res.json(listScheduleSlots());
});

// Teacher/admin only — defining a recurring weekly slot is a privileged action.
router.post('/', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const parsed = slotSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  const slot = createScheduleSlot({ ...parsed.data, teacherId: req.user.id, teacherName: req.user.name });
  res.json(slot);
});

router.put('/:id', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const existing = getScheduleSlot(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.user.role === 'TEACHER' && existing.teacherId !== req.user.id) {
    return res.status(403).json({ error: 'Not your class' });
  }
  const parsed = slotSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: parsed.error.flatten() });
  res.json(updateScheduleSlot(req.params.id, parsed.data));
});

router.delete('/:id', requireAuth, requireRole('TEACHER', 'ADMIN'), (req, res) => {
  const existing = getScheduleSlot(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Not found' });
  if (req.user.role === 'TEACHER' && existing.teacherId !== req.user.id) {
    return res.status(403).json({ error: 'Not your class' });
  }
  deleteScheduleSlot(req.params.id);
  res.json({ ok: true });
});

export default router;
