import { v4 as uuid } from 'uuid';

/**
 * In-memory store for local dev / demoing without Docker/Postgres running.
 * Every function signature here matches what a Prisma-backed version would
 * expose — swap the bodies for `prisma.user.create(...)` etc. per the
 * mapping in docs/architecture.md and nothing above this file (routes,
 * sockets) needs to change.
 *
 * State resets on server restart. Not for production use.
 */

const db = {
  users: new Map(),          // id -> user
  usersByEmail: new Map(),   // email -> id
  faceProfiles: new Map(),   // userId -> profile
  sessions: new Map(),       // id -> session { ...config, roster: [{id,name}] }
  participants: new Map(),   // sessionId -> Map(userId -> participant)
  checks: new Map(),         // sessionId -> [check, ...]
  overrides: new Map(),      // sessionId -> [override, ...]
  scheduleSlots: new Map(),  // id -> weekly recurring class slot
  announcements: new Map(),  // id -> announcement
};

// --- Users -------------------------------------------------------------
export function createUser({ email, passwordHash, name, role, studentId }) {
  const id = uuid();
  const user = { id, email, passwordHash, name, role, studentId: studentId || null, createdAt: new Date().toISOString() };
  db.users.set(id, user);
  db.usersByEmail.set(email.toLowerCase(), id);
  return user;
}

export function findUserByEmail(email) {
  const id = db.usersByEmail.get(email.toLowerCase());
  return id ? db.users.get(id) : null;
}

export function findUserById(id) {
  return db.users.get(id) || null;
}

export function updateUser(id, patch) {
  const user = db.users.get(id);
  if (!user) return null;
  Object.assign(user, patch);
  return user;
}

// --- Face profiles -------------------------------------------------------
export function upsertFaceProfile(userId, { descriptor, earBaseline, sampleCount }) {
  const profile = {
    id: db.faceProfiles.get(userId)?.id || uuid(),
    userId,
    descriptor,
    earBaseline: earBaseline ?? null,
    sampleCount: sampleCount || 0,
    updatedAt: new Date().toISOString(),
  };
  db.faceProfiles.set(userId, profile);
  return profile;
}

export function getFaceProfile(userId) {
  return db.faceProfiles.get(userId) || null;
}

// --- Sessions -------------------------------------------------------
export function createSession({ courseId, courseTitle, section, teacherId, teacherName, checkIntervalSec, checkDurationSec, roster, scheduledStart }) {
  const id = uuid();
  const session = {
    id,
    courseId,
    courseTitle,
    section: section || null,
    teacherId,
    teacherName: teacherName || null,
    status: 'SCHEDULED',
    checkIntervalSec: checkIntervalSec ?? 300,
    checkDurationSec: checkDurationSec ?? 15,
    roster: roster || [],           // [{ id, name, studentId, included }]
    scheduledStart: scheduledStart || new Date().toISOString(),
    actualStart: null,
    actualEnd: null,
  };
  db.sessions.set(id, session);
  db.participants.set(id, new Map());
  db.checks.set(id, []);
  db.overrides.set(id, []);
  return session;
}

export function getSession(id) {
  return db.sessions.get(id) || null;
}

// Small classroom app — listing all sessions is fine at this scale.
// Teacher/student "my classes" views filter this client-side by
// teacherId / roster membership.
export function listSessions() {
  return [...db.sessions.values()].sort(
    (a, b) => new Date(b.scheduledStart) - new Date(a.scheduledStart)
  );
}

export function updateSessionStatus(id, status) {
  const session = db.sessions.get(id);
  if (!session) return null;
  session.status = status;
  if (status === 'LIVE' && !session.actualStart) session.actualStart = new Date().toISOString();
  if (status === 'ENDED' && !session.actualEnd) session.actualEnd = new Date().toISOString();
  return session;
}

export function ensureDemoSession() {
  if (db.sessions.has('demo-session')) return db.sessions.get('demo-session');
  const session = {
    id: 'demo-session',
    courseId: 'CSE318',
    courseTitle: 'CSE318 · System Analysis & Design',
    section: 'Section 7 · Online',
    teacherId: null,
    status: 'LIVE',
    checkIntervalSec: 300,
    checkDurationSec: 15,
    roster: [
      { id: 'r1', name: 'Ashikur Rahman', studentId: '20244103400' },
      { id: 'r2', name: 'Saifur Rahman', studentId: '20244103401' },
      { id: 'r3', name: 'Ahsan Habib', studentId: '20244103402' },
      { id: 'r4', name: 'Nabila Kabir', studentId: '20244103403' },
    ],
    scheduledStart: new Date().toISOString(),
    actualStart: new Date().toISOString(),
    actualEnd: null,
  };
  db.sessions.set(session.id, session);
  db.participants.set(session.id, new Map());
  db.checks.set(session.id, []);
  db.overrides.set(session.id, []);
  return session;
}

// --- Participants -------------------------------------------------------
export function joinSession(sessionId, userId, name) {
  const map = db.participants.get(sessionId) || new Map();
  map.set(userId, { id: uuid(), sessionId, userId, name, joinedAt: new Date().toISOString(), leftAt: null });
  db.participants.set(sessionId, map);
  return map.get(userId);
}

export function leaveSession(sessionId, userId) {
  const map = db.participants.get(sessionId);
  const p = map?.get(userId);
  if (p) p.leftAt = new Date().toISOString();
  return p || null;
}

// --- Attendance checks -------------------------------------------------------
export function addCheck(sessionId, check) {
  const list = db.checks.get(sessionId) || [];
  const entry = { id: uuid(), sessionId, ...check, checkedAt: check.checkedAt || new Date().toISOString() };
  list.push(entry);
  db.checks.set(sessionId, list);
  return entry;
}

export function getChecks(sessionId) {
  return db.checks.get(sessionId) || [];
}

// --- Overrides -------------------------------------------------------
export function addOverride(sessionId, override) {
  const list = db.overrides.get(sessionId) || [];
  const entry = { id: uuid(), sessionId, ...override, createdAt: override.createdAt || new Date().toISOString() };
  list.push(entry);
  db.overrides.set(sessionId, list);
  return entry;
}

export function getOverrides(sessionId) {
  return db.overrides.get(sessionId) || [];
}

// --- Weekly schedule slots -------------------------------------------------------
// Recurring weekly class times, distinct from `sessions` (which are the
// actual live/scheduled/ended class instances). Teachers define the
// weekly pattern once; students see it as a timetable.
export function createScheduleSlot({ courseId, courseTitle, section, teacherId, teacherName, dayOfWeek, startTime, endTime, room, roster }) {
  const id = uuid();
  const slot = {
    id,
    courseId,
    courseTitle,
    section: section || null,
    teacherId,
    teacherName: teacherName || null,
    dayOfWeek,          // 0=Sun .. 6=Sat
    startTime,          // 'HH:MM' 24h
    endTime,            // 'HH:MM' 24h
    room: room || null,
    roster: roster || [], // [{ id, name, studentId }]
    createdAt: new Date().toISOString(),
  };
  db.scheduleSlots.set(id, slot);
  return slot;
}

export function listScheduleSlots() {
  return [...db.scheduleSlots.values()].sort(
    (a, b) => a.dayOfWeek - b.dayOfWeek || a.startTime.localeCompare(b.startTime)
  );
}

export function getScheduleSlot(id) {
  return db.scheduleSlots.get(id) || null;
}

export function updateScheduleSlot(id, patch) {
  const slot = db.scheduleSlots.get(id);
  if (!slot) return null;
  Object.assign(slot, patch);
  return slot;
}

export function deleteScheduleSlot(id) {
  return db.scheduleSlots.delete(id);
}

// --- Announcements -------------------------------------------------------
export function createAnnouncement({ title, body, authorId, authorName, role, courseId, courseTitle, priority, audience }) {
  const id = uuid();
  const announcement = {
    id,
    title,
    body,
    authorId,
    authorName: authorName || null,
    role: role || null,           // author's role at time of posting
    courseId: courseId || null,   // null = campus-wide
    courseTitle: courseTitle || null,
    priority: priority || 'normal', // 'normal' | 'high'
    audience: audience || 'ALL',    // 'ALL' | 'STUDENT' | 'TEACHER'
    createdAt: new Date().toISOString(),
  };
  db.announcements.set(id, announcement);
  return announcement;
}

export function listAnnouncements() {
  return [...db.announcements.values()].sort(
    (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
  );
}

export function getAnnouncement(id) {
  return db.announcements.get(id) || null;
}

export function deleteAnnouncement(id) {
  return db.announcements.delete(id);
}

// Seeds a few timetable slots + announcements so the student dashboard
// isn't empty before a teacher/admin has created any, mirroring
// ensureDemoSession() in sessions.routes.js.
export function ensureDemoScheduleAndAnnouncements() {
  if (db.scheduleSlots.size === 0) {
    createScheduleSlot({
      courseId: 'CSE318', courseTitle: 'CSE318 · System Analysis & Design', section: 'Section 7',
      teacherId: null, teacherName: 'Sumona Yeasmin', dayOfWeek: 1, startTime: '10:00', endTime: '11:20',
      room: 'Room 402', roster: [
        { id: 'r1', name: 'Ashikur Rahman', studentId: '20244103400' },
        { id: 'r2', name: 'Saifur Rahman', studentId: '20244103401' },
      ],
    });
    createScheduleSlot({
      courseId: 'CSE318', courseTitle: 'CSE318 · System Analysis & Design', section: 'Section 7',
      teacherId: null, teacherName: 'Sumona Yeasmin', dayOfWeek: 3, startTime: '10:00', endTime: '11:20',
      room: 'Room 402', roster: [
        { id: 'r1', name: 'Ashikur Rahman', studentId: '20244103400' },
        { id: 'r2', name: 'Saifur Rahman', studentId: '20244103401' },
      ],
    });
  }
  if (db.announcements.size === 0) {
    createAnnouncement({
      title: 'Welcome to SSAS',
      body: 'Face-ID attendance checks run automatically during live classes. Make sure your face profile is set up before your first session.',
      authorId: null, authorName: 'System', role: 'ADMIN', priority: 'normal', audience: 'ALL',
    });
  }
}

export default db;
