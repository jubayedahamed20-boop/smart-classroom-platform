import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { Server as SocketIOServer } from 'socket.io';

import authRoutes from './routes/auth.routes.js';
import faceProfileRoutes from './routes/faceProfiles.routes.js';
import sessionRoutes from './routes/sessions.routes.js';
import exportRoutes from './routes/export.routes.js';
import scheduleRoutes from './routes/schedule.routes.js';
import announcementRoutes from './routes/announcements.routes.js';
import { registerSocketHandlers } from './sockets/index.js';

const app = express();
const httpServer = createServer(app);

// BUGFIX: CORS_ORIGIN was a single hardcoded string ('http://localhost:5173'),
// so any request whose Origin header didn't match EXACTLY — e.g. opening the
// app from another device via http://<lan-ip>:5173, or from a phone — was
// silently blocked by the browser's CORS check before it ever reached these
// routes/sockets. That's what broke joining the classroom over "the other
// link". CORS_ORIGIN now accepts a comma-separated list, e.g.:
//   CORS_ORIGIN=https://localhost:5173,https://192.168.1.23:5173
const allowedOrigins = (process.env.CORS_ORIGIN || 'https://localhost:5173')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

// BUGFIX: even the comma-separated list above still failed for any device
// whose LAN IP wasn't the one exact address someone typed into CORS_ORIGIN
// — a phone almost never happens to match a hardcoded placeholder IP like
// 192.168.1.23, so joining from mobile hit this same CORS rejection again.
// Instead of requiring the exact IP up front, auto-allow any origin that's
// actually on a private network (the standard 192.168.x.x / 10.x.x.x /
// 172.16-31.x.x ranges) or localhost, on any port, over http or https.
// This is a dev-convenience rule, not a production one — it only matches
// private/local addresses, never a public origin, so it can't be used to
// bypass CORS from the open internet.
const PRIVATE_ORIGIN_RE =
  /^https?:\/\/(localhost|127\.0\.0\.1|192\.168\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})(:\d+)?$/;

const corsOptions = {
  origin(origin, callback) {
    // no Origin header (curl, server-to-server, some mobile webviews) — allow
    if (!origin || allowedOrigins.includes(origin) || PRIVATE_ORIGIN_RE.test(origin)) {
      return callback(null, true);
    }
    return callback(new Error(`CORS: origin ${origin} not in CORS_ORIGIN`));
  },
};

const io = new SocketIOServer(httpServer, { cors: corsOptions });

app.set('io', io); // so REST routes can emit socket events, e.g. sessions.routes.js checks

app.use(cors(corsOptions));
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.use('/api/auth', authRoutes);
app.use('/api/face-profiles', faceProfileRoutes);
app.use('/api/sessions', sessionRoutes);
app.use('/api/sessions', exportRoutes); // shares the /:id prefix, distinct sub-paths
app.use('/api/schedule', scheduleRoutes);
app.use('/api/announcements', announcementRoutes);

registerSocketHandlers(io);

const PORT = process.env.PORT || 4000;
httpServer.listen(PORT, () => {
  console.log(`SSAS server listening on http://localhost:${PORT}`);
  console.log(`Using in-memory store — see apps/server/src/db/store.js to swap for Postgres/Prisma.`);
});
