# SSAS — Smart Student Attendance System (multi-user)

Production rebuild of the original single-file client-only demo.

- **Architecture, DB schema, and setup commands:** [`docs/architecture.md`](docs/architecture.md)
- **Theme:** Zoom-style — white/sky-blue chrome (header, side panel, controls, admin,
  report) with dark video tiles in the meeting grid, matching the original demo's tokens.

## What's built so far

**Frontend (`apps/web`)** — Vite + React + Zustand + Tailwind
- ✅ Welcome page — public landing with Login/Sign up
- ✅ Login / Register — real JWT auth, routes each role to its own dashboard
- ✅ Student dashboard — 4 tabs: **Overview** (real-time live-class tracking via
  socket + polling, overall attendance %, attendance risk predictor), **Schedule**
  (weekly timetable with next-class countdown), **Announcements** (live-pushed feed),
  **Profile** (edit details, change password, face-ID setup status)
- ✅ Teacher dashboard — 3 tabs: **Classes** (unchanged — Add class, Start/Rejoin/End,
  per-class attendance with overrides + CSV export), **Schedule** (manage this
  teacher's own weekly timetable slots), **Announcements** (post to own courses or
  campus-wide, students-only audience)
- ✅ Admin dashboard — 3 tabs: **Live overview** (unchanged — attendance bars,
  flagged-students, override audit log, CSV/JSON export), **Schedule** (manage every
  teacher's weekly slots), **Announcements** (post with full audience control:
  everyone / students / teachers)
- ✅ Lobby — camera enable, name/role pulled from your account, live face-api.js
  registration (identity descriptor + EAR blink baseline), configurable check
  interval/duration, join form — now scoped to a real class via `/class/:sessionId/lobby`
- ✅ Meeting — GridTile grid, ControlBar, SidePanel (roster/checks tabs), MeetingHeader
  with live timer + next-check countdown
- ✅ **Live periodic face verification** (`useCheckScheduler.js`) — ported the original's
  runCheck()/classifyFrames() 1:1: every N minutes, runs face-api.js against your own
  video for N seconds, classifies present / drowsy (EAR) / mismatch (identity distance)
  / absent, logs it to the backend, and broadcasts it over the socket
- ✅ Report screen — per-student stats + CSV export
- ✅ `services/webrtc.js` — simple-peer mesh wrapper, signaled over Socket.io (per your
  choice of mesh over an SFU). Room join/leave and signal relay are live on both ends;
  wiring remote peer streams into GridTile-by-name is the one remaining connection —
  see "Known gaps" below.

**Backend (`apps/server`)** — Express + Socket.io, in-memory store for now
- ✅ JWT auth (`/api/auth/register`, `/login`, `/me`) + `requireRole()` RBAC middleware
- ✅ Face profile persistence (`/api/face-profiles/me`)
- ✅ Sessions: create (teacher/admin only, with `scheduledStart`), list, get, join,
  leave, start (→ LIVE), end (→ ENDED)
- ✅ Weekly schedule (`/api/schedule`) — recurring class-time slots, distinct from
  `sessions` (the actual live/ended instances); CRUD gated to the owning teacher/admin,
  readable by anyone signed in
- ✅ Announcements (`/api/announcements`) — role-filtered reads, teacher/admin-only
  posts, campus-wide or course-scoped, `normal`/`high` priority, live-broadcast over
  Socket.io on post (`announcement:new`)
- ✅ Profile edit (`PUT /api/auth/me`) + password change (`POST /api/auth/change-password`)
- ✅ Attendance checks: log + list, real-time broadcast over Socket.io
- ✅ Manual overrides: log + list, real-time broadcast + audit trail
- ✅ Server-side CSV/JSON export (`/api/sessions/:id/export.csv` / `.json`)
- ✅ Socket.io room presence + WebRTC signaling relay (`sockets/index.js`)
- ✅ `db/store.js` — in-memory, but shaped 1:1 against `prisma/schema.prisma` so swapping
  in real Postgres later means replacing this file's internals, not the routes/sockets

## Quick start

```bash
# Terminal 1 — backend
cd apps/server
npm install
cp .env.example .env
npm run dev              # http://localhost:4000

# Terminal 2 — frontend
cd apps/web
npm install
npm run dev              # http://localhost:5173
```

Visit `http://localhost:5173`, sign up as a Teacher, add a class, then sign up as a
Student with the same name/ID you put on the roster to see it appear on their
dashboard. Start the class as the teacher, join as the student, and the
Lobby → Meeting → Report flow runs end-to-end against that real session.

## Known gaps / next steps

1. **Auth isn't enforced on join/leave/checks/overrides yet** — the JWT auth system is
   fully wired into login/register/session-create/start/end, but those four endpoints
   are still intentionally open (no `requireAuth`) since the axios interceptor already
   attaches the token — flip `requireAuth` back on in `sessions.routes.js` once you want
   that locked down.
2. **WebRTC remote video** — `createMesh()` is built and the server relays signals, but
   `MeetingRoute` doesn't yet call it or map `peerId → roster name` into `GridTile`.
   Needs a small handshake (exchange name on `room:join`) to attach the right stream to
   the right tile.
3. **Swap in Postgres** — run `docker compose up -d postgres`, then
   `cd apps/server && npx prisma migrate dev`, then reimplement `db/store.js`'s
   functions using `@prisma/client` — same signatures, so nothing above it changes.
4. **Roster matching is by name/studentId string match** — a teacher adding a student
   to a roster needs to type the exact name (or studentId) the student registered
   with. A proper "invite by email" flow would be a nice follow-up.
