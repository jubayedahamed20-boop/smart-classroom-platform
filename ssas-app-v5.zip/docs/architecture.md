# SSAS — Architecture & Setup

Converting the single-file demo into a real multi-user system. Build order: **frontend
shell + Lobby first** (this delivery), then GridTile/Meeting/SidePanel/Admin, then the
Node/Express + Socket.io + WebRTC backend, then swap localStorage for Postgres.

## 1. Directory layout

```
ssas-app/
├── apps/
│   ├── web/                          # React + Vite frontend
│   │   ├── src/
│   │   │   ├── components/
│   │   │   │   ├── lobby/            # ← built in this pass
│   │   │   │   │   ├── LobbyPage.jsx
│   │   │   │   │   ├── CameraPreview.jsx
│   │   │   │   │   ├── RolePicker.jsx
│   │   │   │   │   ├── FaceIdSetup.jsx
│   │   │   │   │   └── JoinForm.jsx
│   │   │   │   ├── meeting/          # next pass: GridTile, ControlBar, MeetingHeader
│   │   │   │   ├── admin/            # next pass: AdminDashboard, FlagsTable, AuditLog
│   │   │   │   ├── report/           # next pass: ReportPage
│   │   │   │   ├── setup/            # next pass: SessionSetup, RosterEditor
│   │   │   │   └── shared/           # Avatar, StatusBadge, Pill, Button
│   │   │   ├── store/
│   │   │   │   ├── useSessionStore.js   # zustand: current user, role, join state
│   │   │   │   ├── useFaceStore.js      # zustand: model-load state, profile, EAR baseline
│   │   │   │   └── useMeetingStore.js   # zustand: roster, tiles, checks (next pass)
│   │   │   ├── services/
│   │   │   │   ├── api.js               # REST client (axios wrapper, JWT header)
│   │   │   │   ├── socket.js            # socket.io-client singleton
│   │   │   │   ├── webrtc.js            # simple-peer wrapper (next pass)
│   │   │   │   └── faceEngine.js        # face-api.js load/detect/EAR/descriptor math
│   │   │   ├── hooks/
│   │   │   │   └── useCamera.js         # getUserMedia lifecycle hook
│   │   │   ├── pages/
│   │   │   │   └── LobbyRoute.jsx
│   │   │   ├── App.jsx
│   │   │   └── main.jsx
│   │   ├── index.html
│   │   ├── package.json
│   │   ├── tailwind.config.js
│   │   └── vite.config.js
│   │
│   └── server/                       # Node/Express + Socket.io backend (next pass)
│       ├── src/
│       │   ├── routes/               # auth.routes.js, sessions.routes.js, ...
│       │   ├── controllers/
│       │   ├── models/               # Prisma client wrapper
│       │   ├── sockets/              # room join/leave, WebRTC signaling relay
│       │   ├── middleware/           # jwt.middleware.js, rbac.middleware.js
│       │   ├── db/                   # prisma client singleton
│       │   └── utils/
│       ├── prisma/
│       │   └── schema.prisma         # ← included in this pass
│       └── package.json
│
├── docker-compose.yml                 # postgres + redis (for socket.io adapter) + api + web
├── docs/
│   └── architecture.md               # this file
└── README.md
```

## 2. Database

PostgreSQL via Prisma (`apps/server/prisma/schema.prisma`, included in this delivery). Tables:

| Table | Replaces (old localStorage key) | Notes |
|---|---|---|
| `User` | — (didn't exist) | adds real auth; `role` enum drives RBAC |
| `FaceProfile` | `ssas_face_profiles` | descriptor as `Float[]`; move to `pgvector` + cosine index once roster > ~500 for fast nearest-neighbor identity match |
| `ClassSession` | `ssas_class_config` | one row per class meeting, not one global config |
| `SessionParticipant` | `roster` (the `included` flag) | join/leave timestamps replace the static "included" boolean |
| `AttendanceCheck` | `ssas_student_log` | one row per automated/manual check, queryable per session |
| `OverrideAudit` | `ssas_overrides` | unchanged in spirit, now with FK integrity + actor tracking |

## 3. Setup commands

```bash
# 0. Prereqs: Node 20+, Docker (for Postgres/Redis), pnpm
corepack enable && corepack prepare pnpm@latest --activate

# 1. Clone/scaffold
mkdir ssas-app && cd ssas-app
pnpm init -y

# 2. Frontend (this pass)
cd apps/web
pnpm create vite@latest . -- --template react
pnpm add zustand axios socket.io-client face-api.js simple-peer
pnpm add -D tailwindcss postcss autoprefixer
pnpm dlx tailwindcss init -p
pnpm dev            # http://localhost:5173

# 3. Backend (next pass)
cd ../server
pnpm init -y
pnpm add express socket.io cors dotenv jsonwebtoken bcrypt zod
pnpm add @prisma/client
pnpm add -D prisma nodemon
pnpm dlx prisma init          # writes prisma/schema.prisma (already provided here)
pnpm dlx prisma migrate dev --name init
pnpm dlx prisma generate

# 4. Infra (postgres + redis, for socket.io horizontal scaling)
docker compose up -d postgres redis

# 5. Env vars (apps/server/.env)
DATABASE_URL="postgresql://ssas:ssas@localhost:5432/ssas"
JWT_SECRET="change-me"
REDIS_URL="redis://localhost:6379"
```

## 4. What changes conceptually vs. the demo

- **Multi-user video**: the old file only ever had *one* real camera (yours); every
  other tile was simulated in JS. Socket.io now handles room presence + WebRTC
  signaling (offer/answer/ICE relay) so every participant's tile is a real peer
  connection (mesh via simple-peer for small classes; upgrade to an SFU like LiveKit
  once a section exceeds ~8–10 concurrent video streams).
- **Face recognition stays client-side by default**: `faceEngine.js` still runs
  face-api.js in the browser (no raw video frames need to leave the device) and only
  ships the *result* (status, EAR value, match distance) over the socket to the
  session log — same privacy posture as the original, now durable and multi-user.
  A server-side OpenCV/dlib path is available as an opt-in for institutions that want
  centralized verification instead of trusting the client.
- **Everything that touched `localStorage.setItem` becomes a REST call or a
  socket emit**, listed table-by-table above.
