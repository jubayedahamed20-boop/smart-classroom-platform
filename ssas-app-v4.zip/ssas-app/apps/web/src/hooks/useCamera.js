import { useCallback, useRef, useState } from 'react';

// Encapsulates the enable-camera flow from the original lobby's
// enableCamBtn handler, including the file:// vs http(s) error message.
export default function useCamera() {
  const [stream, setStream] = useState(null);
  const [error, setError] = useState(null);
  const [requesting, setRequesting] = useState(false);
  const videoRef = useRef(null);

  const enable = useCallback(async () => {
    setRequesting(true);
    setError(null);
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 480 }, height: { ideal: 360 }, facingMode: 'user' },
        audio: false,
      });
      setStream(s);
      if (videoRef.current) {
        const video = videoRef.current;
        video.srcObject = s;
        // BUGFIX: previously the promise resolved as soon as srcObject was
        // assigned, before the <video> element actually had a decoded frame
        // (readyState/videoWidth still 0 for a beat on many browsers). Any
        // face-api detection that started immediately after "camera enabled"
        // — e.g. clicking "Set up face ID" right away — ran against a blank
        // frame the whole time and always failed with "could not get a
        // clear look at your face", even in good lighting. Wait for the
        // stream to actually be playing with real dimensions first.
        await new Promise((resolve) => {
          if (video.readyState >= 2 && video.videoWidth > 0) {
            resolve();
            return;
          }
          const onReady = () => {
            if (video.videoWidth > 0) {
              video.removeEventListener('loadeddata', onReady);
              resolve();
            }
          };
          video.addEventListener('loadeddata', onReady);
          // Safety net in case the event never fires (some mobile browsers).
          setTimeout(resolve, 1500);
        });
        try {
          await video.play();
        } catch (_) {
          /* autoplay may already be running — ignore */
        }
      }
    } catch (e) {
      setError(
        `Camera access failed. Serve this app over http://localhost (not file://) and allow camera permission. (${e.message})`
      );
    } finally {
      setRequesting(false);
    }
  }, []);

  const disable = useCallback(() => {
    stream?.getTracks().forEach((t) => t.stop());
    setStream(null);
  }, [stream]);

  return { videoRef, stream, error, requesting, enable, disable };
}
