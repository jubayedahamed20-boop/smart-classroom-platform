import Avatar from '../shared/Avatar';
import StatusBadge from '../shared/StatusBadge';

export default function GridTile({ name, isYou, videoRef, stream, status = 'idle', micOn = true, camOn = true }) {
  return (
    <div className="relative bg-dark-tile rounded-xl overflow-hidden border border-dark-line aspect-video flex items-center justify-center">
      {isYou ? (
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className={`w-full h-full object-cover -scale-x-100 ${camOn ? 'block' : 'hidden'}`}
        />
      ) : stream ? (
        <video
          autoPlay
          playsInline
          className="w-full h-full object-cover"
          ref={(el) => {
            if (el && el.srcObject !== stream) el.srcObject = stream;
          }}
        />
      ) : null}
      {(!isYou && !stream) || (isYou && !camOn) ? <Avatar name={name} size={56} /> : null}

      <div className="absolute top-2 left-2">
        <StatusBadge status={status} />
      </div>

      <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between">
        <span className="text-white text-[12px] font-medium bg-black/40 px-2 py-0.5 rounded-md truncate max-w-[70%]">
          {name} {isYou ? '(you)' : ''}
        </span>
        {!micOn && (
          <span className="bg-black/40 text-white text-[11px] w-6 h-6 rounded-md flex items-center justify-center">
            🔇
          </span>
        )}
      </div>
    </div>
  );
}
