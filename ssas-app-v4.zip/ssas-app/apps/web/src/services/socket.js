import { io } from 'socket.io-client';

let socket = null;

// Lazily connects once, reused across the app (Meeting room joins, WebRTC
// signaling, live check-result broadcasts to the SidePanel/AdminDashboard).
export function getSocket() {
  if (!socket) {
    socket = io('/', {
      autoConnect: false,
      auth: { token: localStorage.getItem('ssas_jwt') },
    });
  }
  return socket;
}

export function connectSocket() {
  const s = getSocket();
  if (!s.connected) s.connect();
  return s;
}

export function disconnectSocket() {
  socket?.disconnect();
}
