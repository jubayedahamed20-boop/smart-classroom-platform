/**
 * Room presence + WebRTC signaling relay. The frontend's services/webrtc.js
 * (createMesh) emits 'room:join'/'room:leave'/'webrtc:signal' and listens
 * for 'webrtc:peer-joined'/'webrtc:peer-left' — this file is the other half
 * of that contract.
 *
 * Also relays 'attendance:check' emits from useCheckScheduler.js so a
 * teacher's SidePanel/AdminDashboard can update live without polling,
 * mirroring what the REST POST /sessions/:id/checks already persists.
 *
 * And relays 'chat:message' for the in-meeting chat box (ChatPanel.jsx) —
 * see the roomMembers map below for how "Everyone" vs. a direct message
 * to one person is resolved.
 */
export function registerSocketHandlers(io) {
  // sessionId -> Map(socketId -> name). Populated on 'room:join' (which
  // already fires for every participant, since createMesh's room:join is
  // required before the meeting grid works at all) and used to resolve
  // chat recipients by name without trusting the client's own claim of
  // who it is.
  const roomMembers = new Map();

  function memberMap(sessionId) {
    if (!roomMembers.has(sessionId)) roomMembers.set(sessionId, new Map());
    return roomMembers.get(sessionId);
  }

  function removeMember(sessionId, socketId) {
    const members = roomMembers.get(sessionId);
    if (!members) return;
    members.delete(socketId);
    if (members.size === 0) roomMembers.delete(sessionId);
  }

  io.on('connection', (socket) => {
    let currentRoom = null;
    let currentSessionId = null;

    socket.on('room:join', ({ sessionId, name }) => {
      currentRoom = `session:${sessionId}`;
      currentSessionId = sessionId;
      const room = io.sockets.adapter.rooms.get(currentRoom);
      const existingPeers = room ? Array.from(room) : [];

      socket.join(currentRoom);
      if (name) memberMap(sessionId).set(socket.id, name);

      // BUGFIX: this used to also tell each *existing* peer to initiate a
      // connection back to the newcomer (`io.to(peerId).emit('webrtc:peer-joined', ...)`).
      // The client always creates an initiator SimplePeer on
      // 'webrtc:peer-joined', so both sides ended up as initiators at once
      // — a WebRTC "glare" that made every offer collide and remote video
      // never connect. Only the newcomer should be told to initiate, once,
      // toward each peer already in the room; the existing peer's side of
      // the connection is created lazily (as a non-initiator) the moment
      // it receives that offer over 'webrtc:signal' — see webrtc.js.
      existingPeers.forEach((peerId) => {
        socket.emit('webrtc:peer-joined', { peerId });
      });
    });

    socket.on('room:leave', ({ sessionId }) => {
      const room = `session:${sessionId}`;
      socket.leave(room);
      removeMember(sessionId, socket.id);
      io.to(room).emit('webrtc:peer-left', { peerId: socket.id });
    });

    socket.on('webrtc:signal', ({ to, signal }) => {
      io.to(to).emit('webrtc:signal', { from: socket.id, signal });
    });

    // broadcast (not io.to) excludes the sender — they already applied their
    // own check locally in useCheckScheduler.js, so this only needs to reach
    // everyone else in the room (teacher's SidePanel, other students' rosters).
    socket.on('attendance:check', (payload) => {
      socket.broadcast.to(`session:${payload.sessionId}`).emit('attendance:update', payload);
    });

    // Chat: 'to' is either 'everyone' (room broadcast, sender excluded —
    // ChatPanel.jsx already appends the sender's own message locally on
    // send, same optimistic pattern as attendance:check above) or a
    // roster name (direct message, delivered only to socket(s) currently
    // registered under that name in this room).
    socket.on('chat:message', ({ sessionId, to, body }) => {
      if (!sessionId || !body || !body.trim()) return;
      const room = `session:${sessionId}`;
      const members = roomMembers.get(sessionId);
      const from = members?.get(socket.id) || 'Unknown';
      const entry = {
        id: `${socket.id}-${Date.now()}`,
        from,
        to: to || 'everyone',
        body: body.trim().slice(0, 2000),
        createdAt: new Date().toISOString(),
      };

      if (!to || to === 'everyone') {
        socket.broadcast.to(room).emit('chat:message', entry);
        return;
      }

      if (!members) return;
      members.forEach((memberName, socketId) => {
        if (memberName === to) io.to(socketId).emit('chat:message', entry);
      });
    });

    socket.on('disconnect', () => {
      if (currentRoom) io.to(currentRoom).emit('webrtc:peer-left', { peerId: socket.id });
      if (currentSessionId) removeMember(currentSessionId, socket.id);
    });
  });
}
